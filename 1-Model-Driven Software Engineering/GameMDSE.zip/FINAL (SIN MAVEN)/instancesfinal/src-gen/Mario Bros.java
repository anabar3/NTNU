import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Mario Bros {
    
    public static void main(String[] args) {
        try {
            new Mario Bros().run();
        } catch (IOException e) {
            System.out.println("Exception occurred, exiting!");
            e.printStackTrace();
        }
    }

    public Mario Bros() {
        initializeGame();
    }


	//Initialite the game with the objects
      private void initializeGame() {
objects.add(new GameObject("Mario"));
objects.add(new GameObject("Goomba"));
objects.add(new GameObject("Coin"));

        Background firstBackground = game.getBackgrounds().get(0);  // Get the first background
        
        background = new Background(
            firstBackground.getCoordinates(),
            firstBackground.getBackgroundSpeed(),
            firstBackground.isBackgroundMoving()
        );
		
    }
	
	private enum GameState {
	    MENU, PLAYING, PAUSED, GAME_OVER
	}
	private GameState currentState = GameState.MENU;
	//Update the game status
	private void updateGameState() {
	    switch (currentState) {
	        case MENU:
	            displayMenu();
	            break;
	        case PLAYING:
	            updateGame();
	            break;
	        case PAUSED:
	            displayPauseScreen();
	            break;
	        case GAME_OVER:
	            displayGameOverScreen();
	            break;
	    }
	}
	
	private void displayMenu() {
		//Add code for the menu
		}
	private void displayPauseScreen() {
			//Add code for the pause screen
			}
	private void displayGameOverScreen() {
			//Add code for the game over screen
			}
		
		

	
	private void updateGame() {
		//Update game
	    moveBackground();
	    checkCollisions();
	    moveGameObjects();
	    System.out.println("Game updated.");
	}
	
	private boolean isGameOver() {
	    //Add the logic for a game to be over
	}
	
	private void moveGameObjects() {
	    // Implement de movement of the gameobjects of the game.
	}
	
    public void keyPressed(KeyEvent e) {
    	// This is just and example, the actions are not defined
            int keyCode = e.getKeyCode();
            switch (keyCode) {
                case KeyEvent.VK_LEFT:
                    handleAction("moveLeft");
                    break;
                case KeyEvent.VK_RIGHT:
                    handleAction("moveRight");
                    break;
                case KeyEvent.VK_UP:
                    handleAction("jump");
                    break;
                case KeyEvent.VK_DOWN:
                    handleAction("duck");             
                    break;
                default:
                    System.out.println("Unhandled key: " + KeyEvent.getKeyText(keyCode));
            }
        }

    private void handleAction(String actionName) {
        Action action = findAction(actionName);
        if (action != null) {
            performAction(action);
        } else {
        }
    }

    private Action findAction(String actionName) {
        for (GameObject gameObject : game.getGameObjects()) {
            for (Action action : gameObject.getActions()) {
                if (actionName.equalsIgnoreCase(action.getName())) {
                    return new Action(action.getName(), action.getEffect());
                }
            }
        }
        return null;
    }

    private void performAction(Action action) {
        //Add your implementation for each action
    }

    private void moveBackground() {
        if (background.isBackgroundMoving()) {
            List<Integer> newCoordinates = new ArrayList<>();
            for (int coord : background.getCoordinates()) {
                newCoordinates.add(coord + background.getBackgroundSpeed());
            }
            background.setCoordinates(newCoordinates);
            System.out.println("Background moved to: " + newCoordinates);
        } else {
            System.out.println("Background is not moving.");
        }
    }
    
    private Background findBackground() {
        for (Background background : game.getBackgrounds()) {
            String size = background.getSize().toString();  // Converts list of integers to string representation
            String coordinates = background.getCoordinates().toString();  // Converts list of integers to string representation
            int backgroundSpeed = background.getBackgroundSpeed();
            boolean isBackgroundMoving = background.isBackgroundMoving();
    
            // Create a new Background object using the extracted properties
            return new Background(size, coordinates, backgroundSpeed, isBackgroundMoving);
        }
        return null;  // In case no background is found
    }
    

    private void checkCollisions() {
GameObject obj1 = findGameObjectByIdentifier("Mario");
GameObject obj2 = findGameObjectByIdentifier("Mario");
if (obj1 != null && obj2 != null && obj1 != obj2) {
    int result = checkCollisionBetweenObjects(obj1, obj2);
    if (result == true) {
        //Add code depending on the outcome of the colision
    }
} else {
    System.out.println("Error: One or both objects in the collision could not be found.");
}
GameObject obj1 = findGameObjectByIdentifier("Mario");
GameObject obj2 = findGameObjectByIdentifier("Goomba");
if (obj1 != null && obj2 != null && obj1 != obj2) {
    int result = checkCollisionBetweenObjects(obj1, obj2);
    if (result == true) {
        //Add code depending on the outcome of the colision
    }
} else {
    System.out.println("Error: One or both objects in the collision could not be found.");
}
GameObject obj1 = findGameObjectByIdentifier("Goomba");
GameObject obj2 = findGameObjectByIdentifier("Mario");
if (obj1 != null && obj2 != null && obj1 != obj2) {
    int result = checkCollisionBetweenObjects(obj1, obj2);
    if (result == true) {
        //Add code depending on the outcome of the colision
    }
} else {
    System.out.println("Error: One or both objects in the collision could not be found.");
}
GameObject obj1 = findGameObjectByIdentifier("Goomba");
GameObject obj2 = findGameObjectByIdentifier("Goomba");
if (obj1 != null && obj2 != null && obj1 != obj2) {
    int result = checkCollisionBetweenObjects(obj1, obj2);
    if (result == true) {
        //Add code depending on the outcome of the colision
    }
} else {
    System.out.println("Error: One or both objects in the collision could not be found.");
}
GameObject obj1 = findGameObjectByIdentifier("Mario");
GameObject obj2 = findGameObjectByIdentifier("Mario");
if (obj1 != null && obj2 != null && obj1 != obj2) {
    int result = checkCollisionBetweenObjects(obj1, obj2);
    if (result == true) {
        //Add code depending on the outcome of the colision
    }
} else {
    System.out.println("Error: One or both objects in the collision could not be found.");
}
GameObject obj1 = findGameObjectByIdentifier("Mario");
GameObject obj2 = findGameObjectByIdentifier("Coin");
if (obj1 != null && obj2 != null && obj1 != obj2) {
    int result = checkCollisionBetweenObjects(obj1, obj2);
    if (result == true) {
        //Add code depending on the outcome of the colision
    }
} else {
    System.out.println("Error: One or both objects in the collision could not be found.");
}
GameObject obj1 = findGameObjectByIdentifier("Coin");
GameObject obj2 = findGameObjectByIdentifier("Mario");
if (obj1 != null && obj2 != null && obj1 != obj2) {
    int result = checkCollisionBetweenObjects(obj1, obj2);
    if (result == true) {
        //Add code depending on the outcome of the colision
    }
} else {
    System.out.println("Error: One or both objects in the collision could not be found.");
}
GameObject obj1 = findGameObjectByIdentifier("Coin");
GameObject obj2 = findGameObjectByIdentifier("Coin");
if (obj1 != null && obj2 != null && obj1 != obj2) {
    int result = checkCollisionBetweenObjects(obj1, obj2);
    if (result == true) {
        //Add code depending on the outcome of the colision
    }
} else {
    System.out.println("Error: One or both objects in the collision could not be found.");
}
    }
    
    private boolean checkCollisionBetweenObjects(GameObject obj1, GameObject obj2) {
    	//Code for checking if there is a collision
        List<Integer> coordinates1 = obj1.getCoordinates();
        List<Integer> size1 = obj1.getSize();
    
        List<Integer> coordinates2 = obj2.getCoordinates(); // Lista de 3 valores (x, y, z)
        List<Integer> size2 = obj2.getSize(); // Lista de 3 valores (width, height, depth)
    
        if (coordinates1.size() == 3 && size1.size() == 3 && coordinates2.size() == 3 && size2.size() == 3) {
            boolean collisionX = coordinates1.get(0) < coordinates2.get(0) + size2.get(0) &&
                                 coordinates1.get(0) + size1.get(0) > coordinates2.get(0);
    
            boolean collisionY = coordinates1.get(1) < coordinates2.get(1) + size2.get(1) &&
                                 coordinates1.get(1) + size1.get(1) > coordinates2.get(1);
    
            boolean collisionZ = coordinates1.get(2) < coordinates2.get(2) + size2.get(2) &&
                                 coordinates1.get(2) + size1.get(2) > coordinates2.get(2);
    
            return collisionX && collisionY && collisionZ;
        } else {
            System.out.println("Error: Invalid coordinates or size for one or both objects.");
            return false;
        }
    }
    
    
    private GameObject findGameObjectByIdentifier(String identifier) {
        for (GameObject obj : objects) {
            if (obj.getName().equals(identifier)) {
                return obj;
            }
        }
        return null; 
    }
    
    public void playSound(String soundFilePath) {
    	//Use this function for playing a sound during the game.
            try {
                File soundFile = new File(soundFilePath);
                AudioInputStream audioStream = AudioSystem.getAudioInputStream(soundFile);
                Clip clip = AudioSystem.getClip();
                clip.open(audioStream);
                clip.start();
            } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
                System.out.println("Error reproducing the sound " + e.getMessage());
            }
        }

}
