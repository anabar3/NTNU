package no.ntnu.tdt4250.csdsl.conversion;

import org.eclipse.xtext.conversion.impl.AbstractValueConverter;
import org.eclipse.xtext.conversion.ValueConverterException;
import org.eclipse.xtext.nodemodel.INode;
import org.eclipse.xtext.util.Strings;

public class AnySimpleTypeValueConverter extends AbstractValueConverter<Object> {

	@Override
	public Object toValue(String string, INode node) throws ValueConverterException {
	    if (Strings.isEmpty(string)) {
	        return null;
	    }
	    string = string.trim();
	    // Remove surrounding quotes for strings
	    if (string.startsWith("\"") && string.endsWith("\"")) {
	        string = string.substring(1, string.length() - 1);
	    }
	    try {
	        // Try parsing as Boolean
	        if ("true".equalsIgnoreCase(string) || "false".equalsIgnoreCase(string)) {
	            return Boolean.parseBoolean(string);
	        }
	        // Try parsing as Integer
	        try {
	            return Integer.parseInt(string);
	        } catch (NumberFormatException ignored) {
	        }
	        // Try parsing as Float
	        try {
	            return Float.parseFloat(string);
	        } catch (NumberFormatException ignored) {
	        }
	        // Try parsing as Double
	        try {
	            return Double.parseDouble(string);
	        } catch (NumberFormatException ignored) {
	        }
	        // Return as String if no other matches
	        return string;
	    } catch (Exception e) {
	        throw new ValueConverterException("Cannot convert '" + string + "' to AnySimpleType", node, e);
	    }
	}


    @Override
    public String toString(Object value) {
        return value == null ? "" : value.toString();
    }
}
