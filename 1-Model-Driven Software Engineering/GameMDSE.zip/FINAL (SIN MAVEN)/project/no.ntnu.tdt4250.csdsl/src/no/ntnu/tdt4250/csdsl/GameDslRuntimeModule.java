package no.ntnu.tdt4250.csdsl;

import com.google.inject.Binder;
import org.eclipse.xtext.conversion.IValueConverter;
import no.ntnu.tdt4250.csdsl.conversion.AnySimpleTypeValueConverter;

public class GameDslRuntimeModule extends AbstractGameDslRuntimeModule {

    @Override
    public void configure(Binder binder) {
        super.configure(binder);
        // Bind IValueConverter to the AnySimpleTypeValueConverter
        binder.bind(IValueConverter.class).to(AnySimpleTypeValueConverter.class);
    }
}
