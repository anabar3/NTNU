package no.ntnu.tdt4250.csdsl.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import no.ntnu.tdt4250.csdsl.services.GameDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalGameDslParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_ID", "RULE_STRING", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Game'", "'{'", "'background'", "','", "'}'", "'objectType'", "'collisions'", "'Background'", "'coordinates'", "'('", "')'", "'size'", "'backgroundSpeed:'", "'backgroundMoving:'", "'Type'", "'interaction:'", "'characteristic'", "'gameObject'", "'GameObject'", "'sprite:'", "'isTakingDamage:'", "'amountOfDamage:'", "'damageDuration:'", "'velocity:'", "'directionDegrees'", "'durability:'", "'ability'", "'action'", "'Collisions'", "'hittedSpot:'", "'effect:'", "'effectValue:'", "'objID'", "'Ability'", "'duration:'", "'isBeingUsed:'", "'effect'", "'Action'", "'Effect'", "'range:'", "'-'", "'true'", "'false'", "'.'", "'E'", "'e'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_ID=4;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=5;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalGameDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalGameDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalGameDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalGameDsl.g"; }



     	private GameDslGrammarAccess grammarAccess;

        public InternalGameDslParser(TokenStream input, GameDslGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Game";
       	}

       	@Override
       	protected GameDslGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleGame"
    // InternalGameDsl.g:64:1: entryRuleGame returns [EObject current=null] : iv_ruleGame= ruleGame EOF ;
    public final EObject entryRuleGame() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGame = null;


        try {
            // InternalGameDsl.g:64:45: (iv_ruleGame= ruleGame EOF )
            // InternalGameDsl.g:65:2: iv_ruleGame= ruleGame EOF
            {
             newCompositeNode(grammarAccess.getGameRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGame=ruleGame();

            state._fsp--;

             current =iv_ruleGame; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGame"


    // $ANTLR start "ruleGame"
    // InternalGameDsl.g:71:1: ruleGame returns [EObject current=null] : ( () otherlv_1= 'Game' ( (lv_name_2_0= ruleEString ) ) ( (lv_description_3_0= ruleEString ) ) otherlv_4= '{' (otherlv_5= 'background' otherlv_6= '{' ( (lv_background_7_0= ruleBackground ) ) (otherlv_8= ',' ( (lv_background_9_0= ruleBackground ) ) )* otherlv_10= '}' )? (otherlv_11= 'objectType' otherlv_12= '{' ( (lv_objectType_13_0= ruleObjectType ) ) (otherlv_14= ',' ( (lv_objectType_15_0= ruleObjectType ) ) )* otherlv_16= '}' )? (otherlv_17= 'collisions' otherlv_18= '{' ( (lv_collisions_19_0= ruleCollisions ) ) (otherlv_20= ',' ( (lv_collisions_21_0= ruleCollisions ) ) )* otherlv_22= '}' )? otherlv_23= '}' ) ;
    public final EObject ruleGame() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_18=null;
        Token otherlv_20=null;
        Token otherlv_22=null;
        Token otherlv_23=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        AntlrDatatypeRuleToken lv_description_3_0 = null;

        EObject lv_background_7_0 = null;

        EObject lv_background_9_0 = null;

        EObject lv_objectType_13_0 = null;

        EObject lv_objectType_15_0 = null;

        EObject lv_collisions_19_0 = null;

        EObject lv_collisions_21_0 = null;



        	enterRule();

        try {
            // InternalGameDsl.g:77:2: ( ( () otherlv_1= 'Game' ( (lv_name_2_0= ruleEString ) ) ( (lv_description_3_0= ruleEString ) ) otherlv_4= '{' (otherlv_5= 'background' otherlv_6= '{' ( (lv_background_7_0= ruleBackground ) ) (otherlv_8= ',' ( (lv_background_9_0= ruleBackground ) ) )* otherlv_10= '}' )? (otherlv_11= 'objectType' otherlv_12= '{' ( (lv_objectType_13_0= ruleObjectType ) ) (otherlv_14= ',' ( (lv_objectType_15_0= ruleObjectType ) ) )* otherlv_16= '}' )? (otherlv_17= 'collisions' otherlv_18= '{' ( (lv_collisions_19_0= ruleCollisions ) ) (otherlv_20= ',' ( (lv_collisions_21_0= ruleCollisions ) ) )* otherlv_22= '}' )? otherlv_23= '}' ) )
            // InternalGameDsl.g:78:2: ( () otherlv_1= 'Game' ( (lv_name_2_0= ruleEString ) ) ( (lv_description_3_0= ruleEString ) ) otherlv_4= '{' (otherlv_5= 'background' otherlv_6= '{' ( (lv_background_7_0= ruleBackground ) ) (otherlv_8= ',' ( (lv_background_9_0= ruleBackground ) ) )* otherlv_10= '}' )? (otherlv_11= 'objectType' otherlv_12= '{' ( (lv_objectType_13_0= ruleObjectType ) ) (otherlv_14= ',' ( (lv_objectType_15_0= ruleObjectType ) ) )* otherlv_16= '}' )? (otherlv_17= 'collisions' otherlv_18= '{' ( (lv_collisions_19_0= ruleCollisions ) ) (otherlv_20= ',' ( (lv_collisions_21_0= ruleCollisions ) ) )* otherlv_22= '}' )? otherlv_23= '}' )
            {
            // InternalGameDsl.g:78:2: ( () otherlv_1= 'Game' ( (lv_name_2_0= ruleEString ) ) ( (lv_description_3_0= ruleEString ) ) otherlv_4= '{' (otherlv_5= 'background' otherlv_6= '{' ( (lv_background_7_0= ruleBackground ) ) (otherlv_8= ',' ( (lv_background_9_0= ruleBackground ) ) )* otherlv_10= '}' )? (otherlv_11= 'objectType' otherlv_12= '{' ( (lv_objectType_13_0= ruleObjectType ) ) (otherlv_14= ',' ( (lv_objectType_15_0= ruleObjectType ) ) )* otherlv_16= '}' )? (otherlv_17= 'collisions' otherlv_18= '{' ( (lv_collisions_19_0= ruleCollisions ) ) (otherlv_20= ',' ( (lv_collisions_21_0= ruleCollisions ) ) )* otherlv_22= '}' )? otherlv_23= '}' )
            // InternalGameDsl.g:79:3: () otherlv_1= 'Game' ( (lv_name_2_0= ruleEString ) ) ( (lv_description_3_0= ruleEString ) ) otherlv_4= '{' (otherlv_5= 'background' otherlv_6= '{' ( (lv_background_7_0= ruleBackground ) ) (otherlv_8= ',' ( (lv_background_9_0= ruleBackground ) ) )* otherlv_10= '}' )? (otherlv_11= 'objectType' otherlv_12= '{' ( (lv_objectType_13_0= ruleObjectType ) ) (otherlv_14= ',' ( (lv_objectType_15_0= ruleObjectType ) ) )* otherlv_16= '}' )? (otherlv_17= 'collisions' otherlv_18= '{' ( (lv_collisions_19_0= ruleCollisions ) ) (otherlv_20= ',' ( (lv_collisions_21_0= ruleCollisions ) ) )* otherlv_22= '}' )? otherlv_23= '}'
            {
            // InternalGameDsl.g:79:3: ()
            // InternalGameDsl.g:80:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getGameAccess().getGameAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getGameAccess().getGameKeyword_1());
            		
            // InternalGameDsl.g:90:3: ( (lv_name_2_0= ruleEString ) )
            // InternalGameDsl.g:91:4: (lv_name_2_0= ruleEString )
            {
            // InternalGameDsl.g:91:4: (lv_name_2_0= ruleEString )
            // InternalGameDsl.g:92:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getGameAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_3);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGameRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGameDsl.g:109:3: ( (lv_description_3_0= ruleEString ) )
            // InternalGameDsl.g:110:4: (lv_description_3_0= ruleEString )
            {
            // InternalGameDsl.g:110:4: (lv_description_3_0= ruleEString )
            // InternalGameDsl.g:111:5: lv_description_3_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getGameAccess().getDescriptionEStringParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_4);
            lv_description_3_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGameRule());
            					}
            					set(
            						current,
            						"description",
            						lv_description_3_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,12,FOLLOW_5); 

            			newLeafNode(otherlv_4, grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_4());
            		
            // InternalGameDsl.g:132:3: (otherlv_5= 'background' otherlv_6= '{' ( (lv_background_7_0= ruleBackground ) ) (otherlv_8= ',' ( (lv_background_9_0= ruleBackground ) ) )* otherlv_10= '}' )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==13) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalGameDsl.g:133:4: otherlv_5= 'background' otherlv_6= '{' ( (lv_background_7_0= ruleBackground ) ) (otherlv_8= ',' ( (lv_background_9_0= ruleBackground ) ) )* otherlv_10= '}'
                    {
                    otherlv_5=(Token)match(input,13,FOLLOW_4); 

                    				newLeafNode(otherlv_5, grammarAccess.getGameAccess().getBackgroundKeyword_5_0());
                    			
                    otherlv_6=(Token)match(input,12,FOLLOW_6); 

                    				newLeafNode(otherlv_6, grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_5_1());
                    			
                    // InternalGameDsl.g:141:4: ( (lv_background_7_0= ruleBackground ) )
                    // InternalGameDsl.g:142:5: (lv_background_7_0= ruleBackground )
                    {
                    // InternalGameDsl.g:142:5: (lv_background_7_0= ruleBackground )
                    // InternalGameDsl.g:143:6: lv_background_7_0= ruleBackground
                    {

                    						newCompositeNode(grammarAccess.getGameAccess().getBackgroundBackgroundParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_background_7_0=ruleBackground();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGameRule());
                    						}
                    						add(
                    							current,
                    							"background",
                    							lv_background_7_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.Background");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGameDsl.g:160:4: (otherlv_8= ',' ( (lv_background_9_0= ruleBackground ) ) )*
                    loop1:
                    do {
                        int alt1=2;
                        int LA1_0 = input.LA(1);

                        if ( (LA1_0==14) ) {
                            alt1=1;
                        }


                        switch (alt1) {
                    	case 1 :
                    	    // InternalGameDsl.g:161:5: otherlv_8= ',' ( (lv_background_9_0= ruleBackground ) )
                    	    {
                    	    otherlv_8=(Token)match(input,14,FOLLOW_6); 

                    	    					newLeafNode(otherlv_8, grammarAccess.getGameAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalGameDsl.g:165:5: ( (lv_background_9_0= ruleBackground ) )
                    	    // InternalGameDsl.g:166:6: (lv_background_9_0= ruleBackground )
                    	    {
                    	    // InternalGameDsl.g:166:6: (lv_background_9_0= ruleBackground )
                    	    // InternalGameDsl.g:167:7: lv_background_9_0= ruleBackground
                    	    {

                    	    							newCompositeNode(grammarAccess.getGameAccess().getBackgroundBackgroundParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_background_9_0=ruleBackground();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getGameRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"background",
                    	    								lv_background_9_0,
                    	    								"no.ntnu.tdt4250.csdsl.GameDsl.Background");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop1;
                        }
                    } while (true);

                    otherlv_10=(Token)match(input,15,FOLLOW_8); 

                    				newLeafNode(otherlv_10, grammarAccess.getGameAccess().getRightCurlyBracketKeyword_5_4());
                    			

                    }
                    break;

            }

            // InternalGameDsl.g:190:3: (otherlv_11= 'objectType' otherlv_12= '{' ( (lv_objectType_13_0= ruleObjectType ) ) (otherlv_14= ',' ( (lv_objectType_15_0= ruleObjectType ) ) )* otherlv_16= '}' )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==16) ) {
                alt4=1;
            }
            switch (alt4) {
                case 1 :
                    // InternalGameDsl.g:191:4: otherlv_11= 'objectType' otherlv_12= '{' ( (lv_objectType_13_0= ruleObjectType ) ) (otherlv_14= ',' ( (lv_objectType_15_0= ruleObjectType ) ) )* otherlv_16= '}'
                    {
                    otherlv_11=(Token)match(input,16,FOLLOW_4); 

                    				newLeafNode(otherlv_11, grammarAccess.getGameAccess().getObjectTypeKeyword_6_0());
                    			
                    otherlv_12=(Token)match(input,12,FOLLOW_9); 

                    				newLeafNode(otherlv_12, grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_6_1());
                    			
                    // InternalGameDsl.g:199:4: ( (lv_objectType_13_0= ruleObjectType ) )
                    // InternalGameDsl.g:200:5: (lv_objectType_13_0= ruleObjectType )
                    {
                    // InternalGameDsl.g:200:5: (lv_objectType_13_0= ruleObjectType )
                    // InternalGameDsl.g:201:6: lv_objectType_13_0= ruleObjectType
                    {

                    						newCompositeNode(grammarAccess.getGameAccess().getObjectTypeObjectTypeParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_objectType_13_0=ruleObjectType();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGameRule());
                    						}
                    						add(
                    							current,
                    							"objectType",
                    							lv_objectType_13_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.ObjectType");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGameDsl.g:218:4: (otherlv_14= ',' ( (lv_objectType_15_0= ruleObjectType ) ) )*
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( (LA3_0==14) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // InternalGameDsl.g:219:5: otherlv_14= ',' ( (lv_objectType_15_0= ruleObjectType ) )
                    	    {
                    	    otherlv_14=(Token)match(input,14,FOLLOW_9); 

                    	    					newLeafNode(otherlv_14, grammarAccess.getGameAccess().getCommaKeyword_6_3_0());
                    	    				
                    	    // InternalGameDsl.g:223:5: ( (lv_objectType_15_0= ruleObjectType ) )
                    	    // InternalGameDsl.g:224:6: (lv_objectType_15_0= ruleObjectType )
                    	    {
                    	    // InternalGameDsl.g:224:6: (lv_objectType_15_0= ruleObjectType )
                    	    // InternalGameDsl.g:225:7: lv_objectType_15_0= ruleObjectType
                    	    {

                    	    							newCompositeNode(grammarAccess.getGameAccess().getObjectTypeObjectTypeParserRuleCall_6_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_objectType_15_0=ruleObjectType();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getGameRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"objectType",
                    	    								lv_objectType_15_0,
                    	    								"no.ntnu.tdt4250.csdsl.GameDsl.ObjectType");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop3;
                        }
                    } while (true);

                    otherlv_16=(Token)match(input,15,FOLLOW_10); 

                    				newLeafNode(otherlv_16, grammarAccess.getGameAccess().getRightCurlyBracketKeyword_6_4());
                    			

                    }
                    break;

            }

            // InternalGameDsl.g:248:3: (otherlv_17= 'collisions' otherlv_18= '{' ( (lv_collisions_19_0= ruleCollisions ) ) (otherlv_20= ',' ( (lv_collisions_21_0= ruleCollisions ) ) )* otherlv_22= '}' )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==17) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalGameDsl.g:249:4: otherlv_17= 'collisions' otherlv_18= '{' ( (lv_collisions_19_0= ruleCollisions ) ) (otherlv_20= ',' ( (lv_collisions_21_0= ruleCollisions ) ) )* otherlv_22= '}'
                    {
                    otherlv_17=(Token)match(input,17,FOLLOW_4); 

                    				newLeafNode(otherlv_17, grammarAccess.getGameAccess().getCollisionsKeyword_7_0());
                    			
                    otherlv_18=(Token)match(input,12,FOLLOW_11); 

                    				newLeafNode(otherlv_18, grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_7_1());
                    			
                    // InternalGameDsl.g:257:4: ( (lv_collisions_19_0= ruleCollisions ) )
                    // InternalGameDsl.g:258:5: (lv_collisions_19_0= ruleCollisions )
                    {
                    // InternalGameDsl.g:258:5: (lv_collisions_19_0= ruleCollisions )
                    // InternalGameDsl.g:259:6: lv_collisions_19_0= ruleCollisions
                    {

                    						newCompositeNode(grammarAccess.getGameAccess().getCollisionsCollisionsParserRuleCall_7_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_collisions_19_0=ruleCollisions();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGameRule());
                    						}
                    						add(
                    							current,
                    							"collisions",
                    							lv_collisions_19_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.Collisions");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGameDsl.g:276:4: (otherlv_20= ',' ( (lv_collisions_21_0= ruleCollisions ) ) )*
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( (LA5_0==14) ) {
                            alt5=1;
                        }


                        switch (alt5) {
                    	case 1 :
                    	    // InternalGameDsl.g:277:5: otherlv_20= ',' ( (lv_collisions_21_0= ruleCollisions ) )
                    	    {
                    	    otherlv_20=(Token)match(input,14,FOLLOW_11); 

                    	    					newLeafNode(otherlv_20, grammarAccess.getGameAccess().getCommaKeyword_7_3_0());
                    	    				
                    	    // InternalGameDsl.g:281:5: ( (lv_collisions_21_0= ruleCollisions ) )
                    	    // InternalGameDsl.g:282:6: (lv_collisions_21_0= ruleCollisions )
                    	    {
                    	    // InternalGameDsl.g:282:6: (lv_collisions_21_0= ruleCollisions )
                    	    // InternalGameDsl.g:283:7: lv_collisions_21_0= ruleCollisions
                    	    {

                    	    							newCompositeNode(grammarAccess.getGameAccess().getCollisionsCollisionsParserRuleCall_7_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_collisions_21_0=ruleCollisions();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getGameRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"collisions",
                    	    								lv_collisions_21_0,
                    	    								"no.ntnu.tdt4250.csdsl.GameDsl.Collisions");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop5;
                        }
                    } while (true);

                    otherlv_22=(Token)match(input,15,FOLLOW_12); 

                    				newLeafNode(otherlv_22, grammarAccess.getGameAccess().getRightCurlyBracketKeyword_7_4());
                    			

                    }
                    break;

            }

            otherlv_23=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_23, grammarAccess.getGameAccess().getRightCurlyBracketKeyword_8());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGame"


    // $ANTLR start "entryRuleBackground"
    // InternalGameDsl.g:314:1: entryRuleBackground returns [EObject current=null] : iv_ruleBackground= ruleBackground EOF ;
    public final EObject entryRuleBackground() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleBackground = null;


        try {
            // InternalGameDsl.g:314:51: (iv_ruleBackground= ruleBackground EOF )
            // InternalGameDsl.g:315:2: iv_ruleBackground= ruleBackground EOF
            {
             newCompositeNode(grammarAccess.getBackgroundRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleBackground=ruleBackground();

            state._fsp--;

             current =iv_ruleBackground; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleBackground"


    // $ANTLR start "ruleBackground"
    // InternalGameDsl.g:321:1: ruleBackground returns [EObject current=null] : (otherlv_0= 'Background' ( (lv_identifier_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coordinates' otherlv_4= '(' ( (lv_coordinates_5_0= ruleEInt ) ) (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )* otherlv_8= ')' otherlv_9= 'size' otherlv_10= '(' ( (lv_size_11_0= ruleEInt ) ) (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )* otherlv_14= ')' (otherlv_15= 'backgroundSpeed:' ( (lv_backgroundSpeed_16_0= ruleEInt ) ) )? (otherlv_17= 'backgroundMoving:' ( (lv_backgroundMoving_18_0= ruleEBoolean ) ) )? otherlv_19= '}' ) ;
    public final EObject ruleBackground() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        AntlrDatatypeRuleToken lv_identifier_1_0 = null;

        AntlrDatatypeRuleToken lv_coordinates_5_0 = null;

        AntlrDatatypeRuleToken lv_coordinates_7_0 = null;

        AntlrDatatypeRuleToken lv_size_11_0 = null;

        AntlrDatatypeRuleToken lv_size_13_0 = null;

        AntlrDatatypeRuleToken lv_backgroundSpeed_16_0 = null;

        AntlrDatatypeRuleToken lv_backgroundMoving_18_0 = null;



        	enterRule();

        try {
            // InternalGameDsl.g:327:2: ( (otherlv_0= 'Background' ( (lv_identifier_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coordinates' otherlv_4= '(' ( (lv_coordinates_5_0= ruleEInt ) ) (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )* otherlv_8= ')' otherlv_9= 'size' otherlv_10= '(' ( (lv_size_11_0= ruleEInt ) ) (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )* otherlv_14= ')' (otherlv_15= 'backgroundSpeed:' ( (lv_backgroundSpeed_16_0= ruleEInt ) ) )? (otherlv_17= 'backgroundMoving:' ( (lv_backgroundMoving_18_0= ruleEBoolean ) ) )? otherlv_19= '}' ) )
            // InternalGameDsl.g:328:2: (otherlv_0= 'Background' ( (lv_identifier_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coordinates' otherlv_4= '(' ( (lv_coordinates_5_0= ruleEInt ) ) (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )* otherlv_8= ')' otherlv_9= 'size' otherlv_10= '(' ( (lv_size_11_0= ruleEInt ) ) (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )* otherlv_14= ')' (otherlv_15= 'backgroundSpeed:' ( (lv_backgroundSpeed_16_0= ruleEInt ) ) )? (otherlv_17= 'backgroundMoving:' ( (lv_backgroundMoving_18_0= ruleEBoolean ) ) )? otherlv_19= '}' )
            {
            // InternalGameDsl.g:328:2: (otherlv_0= 'Background' ( (lv_identifier_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coordinates' otherlv_4= '(' ( (lv_coordinates_5_0= ruleEInt ) ) (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )* otherlv_8= ')' otherlv_9= 'size' otherlv_10= '(' ( (lv_size_11_0= ruleEInt ) ) (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )* otherlv_14= ')' (otherlv_15= 'backgroundSpeed:' ( (lv_backgroundSpeed_16_0= ruleEInt ) ) )? (otherlv_17= 'backgroundMoving:' ( (lv_backgroundMoving_18_0= ruleEBoolean ) ) )? otherlv_19= '}' )
            // InternalGameDsl.g:329:3: otherlv_0= 'Background' ( (lv_identifier_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coordinates' otherlv_4= '(' ( (lv_coordinates_5_0= ruleEInt ) ) (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )* otherlv_8= ')' otherlv_9= 'size' otherlv_10= '(' ( (lv_size_11_0= ruleEInt ) ) (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )* otherlv_14= ')' (otherlv_15= 'backgroundSpeed:' ( (lv_backgroundSpeed_16_0= ruleEInt ) ) )? (otherlv_17= 'backgroundMoving:' ( (lv_backgroundMoving_18_0= ruleEBoolean ) ) )? otherlv_19= '}'
            {
            otherlv_0=(Token)match(input,18,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getBackgroundAccess().getBackgroundKeyword_0());
            		
            // InternalGameDsl.g:333:3: ( (lv_identifier_1_0= ruleEString ) )
            // InternalGameDsl.g:334:4: (lv_identifier_1_0= ruleEString )
            {
            // InternalGameDsl.g:334:4: (lv_identifier_1_0= ruleEString )
            // InternalGameDsl.g:335:5: lv_identifier_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getBackgroundAccess().getIdentifierEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_4);
            lv_identifier_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getBackgroundRule());
            					}
            					set(
            						current,
            						"identifier",
            						lv_identifier_1_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_13); 

            			newLeafNode(otherlv_2, grammarAccess.getBackgroundAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,19,FOLLOW_14); 

            			newLeafNode(otherlv_3, grammarAccess.getBackgroundAccess().getCoordinatesKeyword_3());
            		
            otherlv_4=(Token)match(input,20,FOLLOW_15); 

            			newLeafNode(otherlv_4, grammarAccess.getBackgroundAccess().getLeftParenthesisKeyword_4());
            		
            // InternalGameDsl.g:364:3: ( (lv_coordinates_5_0= ruleEInt ) )
            // InternalGameDsl.g:365:4: (lv_coordinates_5_0= ruleEInt )
            {
            // InternalGameDsl.g:365:4: (lv_coordinates_5_0= ruleEInt )
            // InternalGameDsl.g:366:5: lv_coordinates_5_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getBackgroundAccess().getCoordinatesEIntParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_16);
            lv_coordinates_5_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getBackgroundRule());
            					}
            					add(
            						current,
            						"coordinates",
            						lv_coordinates_5_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGameDsl.g:383:3: (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0==14) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // InternalGameDsl.g:384:4: otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) )
            	    {
            	    otherlv_6=(Token)match(input,14,FOLLOW_15); 

            	    				newLeafNode(otherlv_6, grammarAccess.getBackgroundAccess().getCommaKeyword_6_0());
            	    			
            	    // InternalGameDsl.g:388:4: ( (lv_coordinates_7_0= ruleEInt ) )
            	    // InternalGameDsl.g:389:5: (lv_coordinates_7_0= ruleEInt )
            	    {
            	    // InternalGameDsl.g:389:5: (lv_coordinates_7_0= ruleEInt )
            	    // InternalGameDsl.g:390:6: lv_coordinates_7_0= ruleEInt
            	    {

            	    						newCompositeNode(grammarAccess.getBackgroundAccess().getCoordinatesEIntParserRuleCall_6_1_0());
            	    					
            	    pushFollow(FOLLOW_16);
            	    lv_coordinates_7_0=ruleEInt();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getBackgroundRule());
            	    						}
            	    						add(
            	    							current,
            	    							"coordinates",
            	    							lv_coordinates_7_0,
            	    							"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            otherlv_8=(Token)match(input,21,FOLLOW_17); 

            			newLeafNode(otherlv_8, grammarAccess.getBackgroundAccess().getRightParenthesisKeyword_7());
            		
            otherlv_9=(Token)match(input,22,FOLLOW_14); 

            			newLeafNode(otherlv_9, grammarAccess.getBackgroundAccess().getSizeKeyword_8());
            		
            otherlv_10=(Token)match(input,20,FOLLOW_15); 

            			newLeafNode(otherlv_10, grammarAccess.getBackgroundAccess().getLeftParenthesisKeyword_9());
            		
            // InternalGameDsl.g:420:3: ( (lv_size_11_0= ruleEInt ) )
            // InternalGameDsl.g:421:4: (lv_size_11_0= ruleEInt )
            {
            // InternalGameDsl.g:421:4: (lv_size_11_0= ruleEInt )
            // InternalGameDsl.g:422:5: lv_size_11_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getBackgroundAccess().getSizeEIntParserRuleCall_10_0());
            				
            pushFollow(FOLLOW_16);
            lv_size_11_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getBackgroundRule());
            					}
            					add(
            						current,
            						"size",
            						lv_size_11_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGameDsl.g:439:3: (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )*
            loop8:
            do {
                int alt8=2;
                int LA8_0 = input.LA(1);

                if ( (LA8_0==14) ) {
                    alt8=1;
                }


                switch (alt8) {
            	case 1 :
            	    // InternalGameDsl.g:440:4: otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) )
            	    {
            	    otherlv_12=(Token)match(input,14,FOLLOW_15); 

            	    				newLeafNode(otherlv_12, grammarAccess.getBackgroundAccess().getCommaKeyword_11_0());
            	    			
            	    // InternalGameDsl.g:444:4: ( (lv_size_13_0= ruleEInt ) )
            	    // InternalGameDsl.g:445:5: (lv_size_13_0= ruleEInt )
            	    {
            	    // InternalGameDsl.g:445:5: (lv_size_13_0= ruleEInt )
            	    // InternalGameDsl.g:446:6: lv_size_13_0= ruleEInt
            	    {

            	    						newCompositeNode(grammarAccess.getBackgroundAccess().getSizeEIntParserRuleCall_11_1_0());
            	    					
            	    pushFollow(FOLLOW_16);
            	    lv_size_13_0=ruleEInt();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getBackgroundRule());
            	    						}
            	    						add(
            	    							current,
            	    							"size",
            	    							lv_size_13_0,
            	    							"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop8;
                }
            } while (true);

            otherlv_14=(Token)match(input,21,FOLLOW_18); 

            			newLeafNode(otherlv_14, grammarAccess.getBackgroundAccess().getRightParenthesisKeyword_12());
            		
            // InternalGameDsl.g:468:3: (otherlv_15= 'backgroundSpeed:' ( (lv_backgroundSpeed_16_0= ruleEInt ) ) )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==23) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // InternalGameDsl.g:469:4: otherlv_15= 'backgroundSpeed:' ( (lv_backgroundSpeed_16_0= ruleEInt ) )
                    {
                    otherlv_15=(Token)match(input,23,FOLLOW_15); 

                    				newLeafNode(otherlv_15, grammarAccess.getBackgroundAccess().getBackgroundSpeedKeyword_13_0());
                    			
                    // InternalGameDsl.g:473:4: ( (lv_backgroundSpeed_16_0= ruleEInt ) )
                    // InternalGameDsl.g:474:5: (lv_backgroundSpeed_16_0= ruleEInt )
                    {
                    // InternalGameDsl.g:474:5: (lv_backgroundSpeed_16_0= ruleEInt )
                    // InternalGameDsl.g:475:6: lv_backgroundSpeed_16_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getBackgroundAccess().getBackgroundSpeedEIntParserRuleCall_13_1_0());
                    					
                    pushFollow(FOLLOW_19);
                    lv_backgroundSpeed_16_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBackgroundRule());
                    						}
                    						set(
                    							current,
                    							"backgroundSpeed",
                    							lv_backgroundSpeed_16_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGameDsl.g:493:3: (otherlv_17= 'backgroundMoving:' ( (lv_backgroundMoving_18_0= ruleEBoolean ) ) )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==24) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalGameDsl.g:494:4: otherlv_17= 'backgroundMoving:' ( (lv_backgroundMoving_18_0= ruleEBoolean ) )
                    {
                    otherlv_17=(Token)match(input,24,FOLLOW_20); 

                    				newLeafNode(otherlv_17, grammarAccess.getBackgroundAccess().getBackgroundMovingKeyword_14_0());
                    			
                    // InternalGameDsl.g:498:4: ( (lv_backgroundMoving_18_0= ruleEBoolean ) )
                    // InternalGameDsl.g:499:5: (lv_backgroundMoving_18_0= ruleEBoolean )
                    {
                    // InternalGameDsl.g:499:5: (lv_backgroundMoving_18_0= ruleEBoolean )
                    // InternalGameDsl.g:500:6: lv_backgroundMoving_18_0= ruleEBoolean
                    {

                    						newCompositeNode(grammarAccess.getBackgroundAccess().getBackgroundMovingEBooleanParserRuleCall_14_1_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_backgroundMoving_18_0=ruleEBoolean();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getBackgroundRule());
                    						}
                    						set(
                    							current,
                    							"backgroundMoving",
                    							lv_backgroundMoving_18_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EBoolean");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_19=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_19, grammarAccess.getBackgroundAccess().getRightCurlyBracketKeyword_15());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBackground"


    // $ANTLR start "entryRuleObjectType"
    // InternalGameDsl.g:526:1: entryRuleObjectType returns [EObject current=null] : iv_ruleObjectType= ruleObjectType EOF ;
    public final EObject entryRuleObjectType() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleObjectType = null;


        try {
            // InternalGameDsl.g:526:51: (iv_ruleObjectType= ruleObjectType EOF )
            // InternalGameDsl.g:527:2: iv_ruleObjectType= ruleObjectType EOF
            {
             newCompositeNode(grammarAccess.getObjectTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleObjectType=ruleObjectType();

            state._fsp--;

             current =iv_ruleObjectType; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleObjectType"


    // $ANTLR start "ruleObjectType"
    // InternalGameDsl.g:533:1: ruleObjectType returns [EObject current=null] : ( () otherlv_1= 'Type' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'interaction:' ( (lv_interaction_5_0= ruleEString ) ) )? (otherlv_6= 'characteristic' otherlv_7= '(' ( (lv_characteristic_8_0= ruleAnySimpleType ) ) (otherlv_9= ',' ( (lv_characteristic_10_0= ruleAnySimpleType ) ) )* otherlv_11= ')' )? (otherlv_12= 'gameObject' otherlv_13= '{' ( (lv_gameobject_14_0= ruleGameObject ) ) (otherlv_15= ',' ( (lv_gameobject_16_0= ruleGameObject ) ) )* otherlv_17= '}' )? otherlv_18= '}' ) ;
    public final EObject ruleObjectType() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token otherlv_15=null;
        Token otherlv_17=null;
        Token otherlv_18=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        AntlrDatatypeRuleToken lv_interaction_5_0 = null;

        AntlrDatatypeRuleToken lv_characteristic_8_0 = null;

        AntlrDatatypeRuleToken lv_characteristic_10_0 = null;

        EObject lv_gameobject_14_0 = null;

        EObject lv_gameobject_16_0 = null;



        	enterRule();

        try {
            // InternalGameDsl.g:539:2: ( ( () otherlv_1= 'Type' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'interaction:' ( (lv_interaction_5_0= ruleEString ) ) )? (otherlv_6= 'characteristic' otherlv_7= '(' ( (lv_characteristic_8_0= ruleAnySimpleType ) ) (otherlv_9= ',' ( (lv_characteristic_10_0= ruleAnySimpleType ) ) )* otherlv_11= ')' )? (otherlv_12= 'gameObject' otherlv_13= '{' ( (lv_gameobject_14_0= ruleGameObject ) ) (otherlv_15= ',' ( (lv_gameobject_16_0= ruleGameObject ) ) )* otherlv_17= '}' )? otherlv_18= '}' ) )
            // InternalGameDsl.g:540:2: ( () otherlv_1= 'Type' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'interaction:' ( (lv_interaction_5_0= ruleEString ) ) )? (otherlv_6= 'characteristic' otherlv_7= '(' ( (lv_characteristic_8_0= ruleAnySimpleType ) ) (otherlv_9= ',' ( (lv_characteristic_10_0= ruleAnySimpleType ) ) )* otherlv_11= ')' )? (otherlv_12= 'gameObject' otherlv_13= '{' ( (lv_gameobject_14_0= ruleGameObject ) ) (otherlv_15= ',' ( (lv_gameobject_16_0= ruleGameObject ) ) )* otherlv_17= '}' )? otherlv_18= '}' )
            {
            // InternalGameDsl.g:540:2: ( () otherlv_1= 'Type' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'interaction:' ( (lv_interaction_5_0= ruleEString ) ) )? (otherlv_6= 'characteristic' otherlv_7= '(' ( (lv_characteristic_8_0= ruleAnySimpleType ) ) (otherlv_9= ',' ( (lv_characteristic_10_0= ruleAnySimpleType ) ) )* otherlv_11= ')' )? (otherlv_12= 'gameObject' otherlv_13= '{' ( (lv_gameobject_14_0= ruleGameObject ) ) (otherlv_15= ',' ( (lv_gameobject_16_0= ruleGameObject ) ) )* otherlv_17= '}' )? otherlv_18= '}' )
            // InternalGameDsl.g:541:3: () otherlv_1= 'Type' ( (lv_name_2_0= ruleEString ) ) otherlv_3= '{' (otherlv_4= 'interaction:' ( (lv_interaction_5_0= ruleEString ) ) )? (otherlv_6= 'characteristic' otherlv_7= '(' ( (lv_characteristic_8_0= ruleAnySimpleType ) ) (otherlv_9= ',' ( (lv_characteristic_10_0= ruleAnySimpleType ) ) )* otherlv_11= ')' )? (otherlv_12= 'gameObject' otherlv_13= '{' ( (lv_gameobject_14_0= ruleGameObject ) ) (otherlv_15= ',' ( (lv_gameobject_16_0= ruleGameObject ) ) )* otherlv_17= '}' )? otherlv_18= '}'
            {
            // InternalGameDsl.g:541:3: ()
            // InternalGameDsl.g:542:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getObjectTypeAccess().getObjectTypeAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,25,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getObjectTypeAccess().getTypeKeyword_1());
            		
            // InternalGameDsl.g:552:3: ( (lv_name_2_0= ruleEString ) )
            // InternalGameDsl.g:553:4: (lv_name_2_0= ruleEString )
            {
            // InternalGameDsl.g:553:4: (lv_name_2_0= ruleEString )
            // InternalGameDsl.g:554:5: lv_name_2_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getObjectTypeAccess().getNameEStringParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_2_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getObjectTypeRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,12,FOLLOW_21); 

            			newLeafNode(otherlv_3, grammarAccess.getObjectTypeAccess().getLeftCurlyBracketKeyword_3());
            		
            // InternalGameDsl.g:575:3: (otherlv_4= 'interaction:' ( (lv_interaction_5_0= ruleEString ) ) )?
            int alt11=2;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==26) ) {
                alt11=1;
            }
            switch (alt11) {
                case 1 :
                    // InternalGameDsl.g:576:4: otherlv_4= 'interaction:' ( (lv_interaction_5_0= ruleEString ) )
                    {
                    otherlv_4=(Token)match(input,26,FOLLOW_3); 

                    				newLeafNode(otherlv_4, grammarAccess.getObjectTypeAccess().getInteractionKeyword_4_0());
                    			
                    // InternalGameDsl.g:580:4: ( (lv_interaction_5_0= ruleEString ) )
                    // InternalGameDsl.g:581:5: (lv_interaction_5_0= ruleEString )
                    {
                    // InternalGameDsl.g:581:5: (lv_interaction_5_0= ruleEString )
                    // InternalGameDsl.g:582:6: lv_interaction_5_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getObjectTypeAccess().getInteractionEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_22);
                    lv_interaction_5_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getObjectTypeRule());
                    						}
                    						set(
                    							current,
                    							"interaction",
                    							lv_interaction_5_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGameDsl.g:600:3: (otherlv_6= 'characteristic' otherlv_7= '(' ( (lv_characteristic_8_0= ruleAnySimpleType ) ) (otherlv_9= ',' ( (lv_characteristic_10_0= ruleAnySimpleType ) ) )* otherlv_11= ')' )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==27) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalGameDsl.g:601:4: otherlv_6= 'characteristic' otherlv_7= '(' ( (lv_characteristic_8_0= ruleAnySimpleType ) ) (otherlv_9= ',' ( (lv_characteristic_10_0= ruleAnySimpleType ) ) )* otherlv_11= ')'
                    {
                    otherlv_6=(Token)match(input,27,FOLLOW_14); 

                    				newLeafNode(otherlv_6, grammarAccess.getObjectTypeAccess().getCharacteristicKeyword_5_0());
                    			
                    otherlv_7=(Token)match(input,20,FOLLOW_23); 

                    				newLeafNode(otherlv_7, grammarAccess.getObjectTypeAccess().getLeftParenthesisKeyword_5_1());
                    			
                    // InternalGameDsl.g:609:4: ( (lv_characteristic_8_0= ruleAnySimpleType ) )
                    // InternalGameDsl.g:610:5: (lv_characteristic_8_0= ruleAnySimpleType )
                    {
                    // InternalGameDsl.g:610:5: (lv_characteristic_8_0= ruleAnySimpleType )
                    // InternalGameDsl.g:611:6: lv_characteristic_8_0= ruleAnySimpleType
                    {

                    						newCompositeNode(grammarAccess.getObjectTypeAccess().getCharacteristicAnySimpleTypeParserRuleCall_5_2_0());
                    					
                    pushFollow(FOLLOW_16);
                    lv_characteristic_8_0=ruleAnySimpleType();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getObjectTypeRule());
                    						}
                    						add(
                    							current,
                    							"characteristic",
                    							lv_characteristic_8_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.AnySimpleType");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGameDsl.g:628:4: (otherlv_9= ',' ( (lv_characteristic_10_0= ruleAnySimpleType ) ) )*
                    loop12:
                    do {
                        int alt12=2;
                        int LA12_0 = input.LA(1);

                        if ( (LA12_0==14) ) {
                            alt12=1;
                        }


                        switch (alt12) {
                    	case 1 :
                    	    // InternalGameDsl.g:629:5: otherlv_9= ',' ( (lv_characteristic_10_0= ruleAnySimpleType ) )
                    	    {
                    	    otherlv_9=(Token)match(input,14,FOLLOW_23); 

                    	    					newLeafNode(otherlv_9, grammarAccess.getObjectTypeAccess().getCommaKeyword_5_3_0());
                    	    				
                    	    // InternalGameDsl.g:633:5: ( (lv_characteristic_10_0= ruleAnySimpleType ) )
                    	    // InternalGameDsl.g:634:6: (lv_characteristic_10_0= ruleAnySimpleType )
                    	    {
                    	    // InternalGameDsl.g:634:6: (lv_characteristic_10_0= ruleAnySimpleType )
                    	    // InternalGameDsl.g:635:7: lv_characteristic_10_0= ruleAnySimpleType
                    	    {

                    	    							newCompositeNode(grammarAccess.getObjectTypeAccess().getCharacteristicAnySimpleTypeParserRuleCall_5_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_16);
                    	    lv_characteristic_10_0=ruleAnySimpleType();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getObjectTypeRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"characteristic",
                    	    								lv_characteristic_10_0,
                    	    								"no.ntnu.tdt4250.csdsl.GameDsl.AnySimpleType");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop12;
                        }
                    } while (true);

                    otherlv_11=(Token)match(input,21,FOLLOW_24); 

                    				newLeafNode(otherlv_11, grammarAccess.getObjectTypeAccess().getRightParenthesisKeyword_5_4());
                    			

                    }
                    break;

            }

            // InternalGameDsl.g:658:3: (otherlv_12= 'gameObject' otherlv_13= '{' ( (lv_gameobject_14_0= ruleGameObject ) ) (otherlv_15= ',' ( (lv_gameobject_16_0= ruleGameObject ) ) )* otherlv_17= '}' )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==28) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalGameDsl.g:659:4: otherlv_12= 'gameObject' otherlv_13= '{' ( (lv_gameobject_14_0= ruleGameObject ) ) (otherlv_15= ',' ( (lv_gameobject_16_0= ruleGameObject ) ) )* otherlv_17= '}'
                    {
                    otherlv_12=(Token)match(input,28,FOLLOW_4); 

                    				newLeafNode(otherlv_12, grammarAccess.getObjectTypeAccess().getGameObjectKeyword_6_0());
                    			
                    otherlv_13=(Token)match(input,12,FOLLOW_25); 

                    				newLeafNode(otherlv_13, grammarAccess.getObjectTypeAccess().getLeftCurlyBracketKeyword_6_1());
                    			
                    // InternalGameDsl.g:667:4: ( (lv_gameobject_14_0= ruleGameObject ) )
                    // InternalGameDsl.g:668:5: (lv_gameobject_14_0= ruleGameObject )
                    {
                    // InternalGameDsl.g:668:5: (lv_gameobject_14_0= ruleGameObject )
                    // InternalGameDsl.g:669:6: lv_gameobject_14_0= ruleGameObject
                    {

                    						newCompositeNode(grammarAccess.getObjectTypeAccess().getGameobjectGameObjectParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_gameobject_14_0=ruleGameObject();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getObjectTypeRule());
                    						}
                    						add(
                    							current,
                    							"gameobject",
                    							lv_gameobject_14_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.GameObject");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGameDsl.g:686:4: (otherlv_15= ',' ( (lv_gameobject_16_0= ruleGameObject ) ) )*
                    loop14:
                    do {
                        int alt14=2;
                        int LA14_0 = input.LA(1);

                        if ( (LA14_0==14) ) {
                            alt14=1;
                        }


                        switch (alt14) {
                    	case 1 :
                    	    // InternalGameDsl.g:687:5: otherlv_15= ',' ( (lv_gameobject_16_0= ruleGameObject ) )
                    	    {
                    	    otherlv_15=(Token)match(input,14,FOLLOW_25); 

                    	    					newLeafNode(otherlv_15, grammarAccess.getObjectTypeAccess().getCommaKeyword_6_3_0());
                    	    				
                    	    // InternalGameDsl.g:691:5: ( (lv_gameobject_16_0= ruleGameObject ) )
                    	    // InternalGameDsl.g:692:6: (lv_gameobject_16_0= ruleGameObject )
                    	    {
                    	    // InternalGameDsl.g:692:6: (lv_gameobject_16_0= ruleGameObject )
                    	    // InternalGameDsl.g:693:7: lv_gameobject_16_0= ruleGameObject
                    	    {

                    	    							newCompositeNode(grammarAccess.getObjectTypeAccess().getGameobjectGameObjectParserRuleCall_6_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_gameobject_16_0=ruleGameObject();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getObjectTypeRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"gameobject",
                    	    								lv_gameobject_16_0,
                    	    								"no.ntnu.tdt4250.csdsl.GameDsl.GameObject");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop14;
                        }
                    } while (true);

                    otherlv_17=(Token)match(input,15,FOLLOW_12); 

                    				newLeafNode(otherlv_17, grammarAccess.getObjectTypeAccess().getRightCurlyBracketKeyword_6_4());
                    			

                    }
                    break;

            }

            otherlv_18=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_18, grammarAccess.getObjectTypeAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleObjectType"


    // $ANTLR start "entryRuleGameObject"
    // InternalGameDsl.g:724:1: entryRuleGameObject returns [EObject current=null] : iv_ruleGameObject= ruleGameObject EOF ;
    public final EObject entryRuleGameObject() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGameObject = null;


        try {
            // InternalGameDsl.g:724:51: (iv_ruleGameObject= ruleGameObject EOF )
            // InternalGameDsl.g:725:2: iv_ruleGameObject= ruleGameObject EOF
            {
             newCompositeNode(grammarAccess.getGameObjectRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGameObject=ruleGameObject();

            state._fsp--;

             current =iv_ruleGameObject; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGameObject"


    // $ANTLR start "ruleGameObject"
    // InternalGameDsl.g:731:1: ruleGameObject returns [EObject current=null] : (otherlv_0= 'GameObject' ( (lv_identifier_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coordinates' otherlv_4= '(' ( (lv_coordinates_5_0= ruleEInt ) ) (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )* otherlv_8= ')' otherlv_9= 'size' otherlv_10= '(' ( (lv_size_11_0= ruleEInt ) ) (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )* otherlv_14= ')' otherlv_15= 'sprite:' ( (lv_sprite_16_0= ruleEString ) ) (otherlv_17= 'isTakingDamage:' ( (lv_isTakingDamage_18_0= ruleEBoolean ) ) )? (otherlv_19= 'amountOfDamage:' ( (lv_amountOfDamage_20_0= ruleEFloat ) ) )? (otherlv_21= 'damageDuration:' ( (lv_damageDuration_22_0= ruleEInt ) ) )? otherlv_23= 'velocity:' ( (lv_velocity_24_0= ruleEFloat ) ) otherlv_25= 'directionDegrees' otherlv_26= '(' ( (lv_directionDegrees_27_0= ruleEDouble ) ) (otherlv_28= ',' ( (lv_directionDegrees_29_0= ruleEDouble ) ) )* otherlv_30= ')' (otherlv_31= 'durability:' ( (lv_durability_32_0= ruleEInt ) ) )? (otherlv_33= 'ability' otherlv_34= '{' ( (lv_ability_35_0= ruleAbility ) ) (otherlv_36= ',' ( (lv_ability_37_0= ruleAbility ) ) )* otherlv_38= '}' )? (otherlv_39= 'action' otherlv_40= '{' ( (lv_action_41_0= ruleAction ) ) (otherlv_42= ',' ( (lv_action_43_0= ruleAction ) ) )* otherlv_44= '}' )? otherlv_45= '}' ) ;
    public final EObject ruleGameObject() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        Token otherlv_21=null;
        Token otherlv_23=null;
        Token otherlv_25=null;
        Token otherlv_26=null;
        Token otherlv_28=null;
        Token otherlv_30=null;
        Token otherlv_31=null;
        Token otherlv_33=null;
        Token otherlv_34=null;
        Token otherlv_36=null;
        Token otherlv_38=null;
        Token otherlv_39=null;
        Token otherlv_40=null;
        Token otherlv_42=null;
        Token otherlv_44=null;
        Token otherlv_45=null;
        AntlrDatatypeRuleToken lv_identifier_1_0 = null;

        AntlrDatatypeRuleToken lv_coordinates_5_0 = null;

        AntlrDatatypeRuleToken lv_coordinates_7_0 = null;

        AntlrDatatypeRuleToken lv_size_11_0 = null;

        AntlrDatatypeRuleToken lv_size_13_0 = null;

        AntlrDatatypeRuleToken lv_sprite_16_0 = null;

        AntlrDatatypeRuleToken lv_isTakingDamage_18_0 = null;

        AntlrDatatypeRuleToken lv_amountOfDamage_20_0 = null;

        AntlrDatatypeRuleToken lv_damageDuration_22_0 = null;

        AntlrDatatypeRuleToken lv_velocity_24_0 = null;

        AntlrDatatypeRuleToken lv_directionDegrees_27_0 = null;

        AntlrDatatypeRuleToken lv_directionDegrees_29_0 = null;

        AntlrDatatypeRuleToken lv_durability_32_0 = null;

        EObject lv_ability_35_0 = null;

        EObject lv_ability_37_0 = null;

        EObject lv_action_41_0 = null;

        EObject lv_action_43_0 = null;



        	enterRule();

        try {
            // InternalGameDsl.g:737:2: ( (otherlv_0= 'GameObject' ( (lv_identifier_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coordinates' otherlv_4= '(' ( (lv_coordinates_5_0= ruleEInt ) ) (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )* otherlv_8= ')' otherlv_9= 'size' otherlv_10= '(' ( (lv_size_11_0= ruleEInt ) ) (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )* otherlv_14= ')' otherlv_15= 'sprite:' ( (lv_sprite_16_0= ruleEString ) ) (otherlv_17= 'isTakingDamage:' ( (lv_isTakingDamage_18_0= ruleEBoolean ) ) )? (otherlv_19= 'amountOfDamage:' ( (lv_amountOfDamage_20_0= ruleEFloat ) ) )? (otherlv_21= 'damageDuration:' ( (lv_damageDuration_22_0= ruleEInt ) ) )? otherlv_23= 'velocity:' ( (lv_velocity_24_0= ruleEFloat ) ) otherlv_25= 'directionDegrees' otherlv_26= '(' ( (lv_directionDegrees_27_0= ruleEDouble ) ) (otherlv_28= ',' ( (lv_directionDegrees_29_0= ruleEDouble ) ) )* otherlv_30= ')' (otherlv_31= 'durability:' ( (lv_durability_32_0= ruleEInt ) ) )? (otherlv_33= 'ability' otherlv_34= '{' ( (lv_ability_35_0= ruleAbility ) ) (otherlv_36= ',' ( (lv_ability_37_0= ruleAbility ) ) )* otherlv_38= '}' )? (otherlv_39= 'action' otherlv_40= '{' ( (lv_action_41_0= ruleAction ) ) (otherlv_42= ',' ( (lv_action_43_0= ruleAction ) ) )* otherlv_44= '}' )? otherlv_45= '}' ) )
            // InternalGameDsl.g:738:2: (otherlv_0= 'GameObject' ( (lv_identifier_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coordinates' otherlv_4= '(' ( (lv_coordinates_5_0= ruleEInt ) ) (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )* otherlv_8= ')' otherlv_9= 'size' otherlv_10= '(' ( (lv_size_11_0= ruleEInt ) ) (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )* otherlv_14= ')' otherlv_15= 'sprite:' ( (lv_sprite_16_0= ruleEString ) ) (otherlv_17= 'isTakingDamage:' ( (lv_isTakingDamage_18_0= ruleEBoolean ) ) )? (otherlv_19= 'amountOfDamage:' ( (lv_amountOfDamage_20_0= ruleEFloat ) ) )? (otherlv_21= 'damageDuration:' ( (lv_damageDuration_22_0= ruleEInt ) ) )? otherlv_23= 'velocity:' ( (lv_velocity_24_0= ruleEFloat ) ) otherlv_25= 'directionDegrees' otherlv_26= '(' ( (lv_directionDegrees_27_0= ruleEDouble ) ) (otherlv_28= ',' ( (lv_directionDegrees_29_0= ruleEDouble ) ) )* otherlv_30= ')' (otherlv_31= 'durability:' ( (lv_durability_32_0= ruleEInt ) ) )? (otherlv_33= 'ability' otherlv_34= '{' ( (lv_ability_35_0= ruleAbility ) ) (otherlv_36= ',' ( (lv_ability_37_0= ruleAbility ) ) )* otherlv_38= '}' )? (otherlv_39= 'action' otherlv_40= '{' ( (lv_action_41_0= ruleAction ) ) (otherlv_42= ',' ( (lv_action_43_0= ruleAction ) ) )* otherlv_44= '}' )? otherlv_45= '}' )
            {
            // InternalGameDsl.g:738:2: (otherlv_0= 'GameObject' ( (lv_identifier_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coordinates' otherlv_4= '(' ( (lv_coordinates_5_0= ruleEInt ) ) (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )* otherlv_8= ')' otherlv_9= 'size' otherlv_10= '(' ( (lv_size_11_0= ruleEInt ) ) (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )* otherlv_14= ')' otherlv_15= 'sprite:' ( (lv_sprite_16_0= ruleEString ) ) (otherlv_17= 'isTakingDamage:' ( (lv_isTakingDamage_18_0= ruleEBoolean ) ) )? (otherlv_19= 'amountOfDamage:' ( (lv_amountOfDamage_20_0= ruleEFloat ) ) )? (otherlv_21= 'damageDuration:' ( (lv_damageDuration_22_0= ruleEInt ) ) )? otherlv_23= 'velocity:' ( (lv_velocity_24_0= ruleEFloat ) ) otherlv_25= 'directionDegrees' otherlv_26= '(' ( (lv_directionDegrees_27_0= ruleEDouble ) ) (otherlv_28= ',' ( (lv_directionDegrees_29_0= ruleEDouble ) ) )* otherlv_30= ')' (otherlv_31= 'durability:' ( (lv_durability_32_0= ruleEInt ) ) )? (otherlv_33= 'ability' otherlv_34= '{' ( (lv_ability_35_0= ruleAbility ) ) (otherlv_36= ',' ( (lv_ability_37_0= ruleAbility ) ) )* otherlv_38= '}' )? (otherlv_39= 'action' otherlv_40= '{' ( (lv_action_41_0= ruleAction ) ) (otherlv_42= ',' ( (lv_action_43_0= ruleAction ) ) )* otherlv_44= '}' )? otherlv_45= '}' )
            // InternalGameDsl.g:739:3: otherlv_0= 'GameObject' ( (lv_identifier_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'coordinates' otherlv_4= '(' ( (lv_coordinates_5_0= ruleEInt ) ) (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )* otherlv_8= ')' otherlv_9= 'size' otherlv_10= '(' ( (lv_size_11_0= ruleEInt ) ) (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )* otherlv_14= ')' otherlv_15= 'sprite:' ( (lv_sprite_16_0= ruleEString ) ) (otherlv_17= 'isTakingDamage:' ( (lv_isTakingDamage_18_0= ruleEBoolean ) ) )? (otherlv_19= 'amountOfDamage:' ( (lv_amountOfDamage_20_0= ruleEFloat ) ) )? (otherlv_21= 'damageDuration:' ( (lv_damageDuration_22_0= ruleEInt ) ) )? otherlv_23= 'velocity:' ( (lv_velocity_24_0= ruleEFloat ) ) otherlv_25= 'directionDegrees' otherlv_26= '(' ( (lv_directionDegrees_27_0= ruleEDouble ) ) (otherlv_28= ',' ( (lv_directionDegrees_29_0= ruleEDouble ) ) )* otherlv_30= ')' (otherlv_31= 'durability:' ( (lv_durability_32_0= ruleEInt ) ) )? (otherlv_33= 'ability' otherlv_34= '{' ( (lv_ability_35_0= ruleAbility ) ) (otherlv_36= ',' ( (lv_ability_37_0= ruleAbility ) ) )* otherlv_38= '}' )? (otherlv_39= 'action' otherlv_40= '{' ( (lv_action_41_0= ruleAction ) ) (otherlv_42= ',' ( (lv_action_43_0= ruleAction ) ) )* otherlv_44= '}' )? otherlv_45= '}'
            {
            otherlv_0=(Token)match(input,29,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getGameObjectAccess().getGameObjectKeyword_0());
            		
            // InternalGameDsl.g:743:3: ( (lv_identifier_1_0= ruleEString ) )
            // InternalGameDsl.g:744:4: (lv_identifier_1_0= ruleEString )
            {
            // InternalGameDsl.g:744:4: (lv_identifier_1_0= ruleEString )
            // InternalGameDsl.g:745:5: lv_identifier_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getGameObjectAccess().getIdentifierEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_4);
            lv_identifier_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGameObjectRule());
            					}
            					set(
            						current,
            						"identifier",
            						lv_identifier_1_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_13); 

            			newLeafNode(otherlv_2, grammarAccess.getGameObjectAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,19,FOLLOW_14); 

            			newLeafNode(otherlv_3, grammarAccess.getGameObjectAccess().getCoordinatesKeyword_3());
            		
            otherlv_4=(Token)match(input,20,FOLLOW_15); 

            			newLeafNode(otherlv_4, grammarAccess.getGameObjectAccess().getLeftParenthesisKeyword_4());
            		
            // InternalGameDsl.g:774:3: ( (lv_coordinates_5_0= ruleEInt ) )
            // InternalGameDsl.g:775:4: (lv_coordinates_5_0= ruleEInt )
            {
            // InternalGameDsl.g:775:4: (lv_coordinates_5_0= ruleEInt )
            // InternalGameDsl.g:776:5: lv_coordinates_5_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getGameObjectAccess().getCoordinatesEIntParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_16);
            lv_coordinates_5_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGameObjectRule());
            					}
            					add(
            						current,
            						"coordinates",
            						lv_coordinates_5_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGameDsl.g:793:3: (otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) ) )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( (LA16_0==14) ) {
                    alt16=1;
                }


                switch (alt16) {
            	case 1 :
            	    // InternalGameDsl.g:794:4: otherlv_6= ',' ( (lv_coordinates_7_0= ruleEInt ) )
            	    {
            	    otherlv_6=(Token)match(input,14,FOLLOW_15); 

            	    				newLeafNode(otherlv_6, grammarAccess.getGameObjectAccess().getCommaKeyword_6_0());
            	    			
            	    // InternalGameDsl.g:798:4: ( (lv_coordinates_7_0= ruleEInt ) )
            	    // InternalGameDsl.g:799:5: (lv_coordinates_7_0= ruleEInt )
            	    {
            	    // InternalGameDsl.g:799:5: (lv_coordinates_7_0= ruleEInt )
            	    // InternalGameDsl.g:800:6: lv_coordinates_7_0= ruleEInt
            	    {

            	    						newCompositeNode(grammarAccess.getGameObjectAccess().getCoordinatesEIntParserRuleCall_6_1_0());
            	    					
            	    pushFollow(FOLLOW_16);
            	    lv_coordinates_7_0=ruleEInt();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getGameObjectRule());
            	    						}
            	    						add(
            	    							current,
            	    							"coordinates",
            	    							lv_coordinates_7_0,
            	    							"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);

            otherlv_8=(Token)match(input,21,FOLLOW_17); 

            			newLeafNode(otherlv_8, grammarAccess.getGameObjectAccess().getRightParenthesisKeyword_7());
            		
            otherlv_9=(Token)match(input,22,FOLLOW_14); 

            			newLeafNode(otherlv_9, grammarAccess.getGameObjectAccess().getSizeKeyword_8());
            		
            otherlv_10=(Token)match(input,20,FOLLOW_15); 

            			newLeafNode(otherlv_10, grammarAccess.getGameObjectAccess().getLeftParenthesisKeyword_9());
            		
            // InternalGameDsl.g:830:3: ( (lv_size_11_0= ruleEInt ) )
            // InternalGameDsl.g:831:4: (lv_size_11_0= ruleEInt )
            {
            // InternalGameDsl.g:831:4: (lv_size_11_0= ruleEInt )
            // InternalGameDsl.g:832:5: lv_size_11_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getGameObjectAccess().getSizeEIntParserRuleCall_10_0());
            				
            pushFollow(FOLLOW_16);
            lv_size_11_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGameObjectRule());
            					}
            					add(
            						current,
            						"size",
            						lv_size_11_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGameDsl.g:849:3: (otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) ) )*
            loop17:
            do {
                int alt17=2;
                int LA17_0 = input.LA(1);

                if ( (LA17_0==14) ) {
                    alt17=1;
                }


                switch (alt17) {
            	case 1 :
            	    // InternalGameDsl.g:850:4: otherlv_12= ',' ( (lv_size_13_0= ruleEInt ) )
            	    {
            	    otherlv_12=(Token)match(input,14,FOLLOW_15); 

            	    				newLeafNode(otherlv_12, grammarAccess.getGameObjectAccess().getCommaKeyword_11_0());
            	    			
            	    // InternalGameDsl.g:854:4: ( (lv_size_13_0= ruleEInt ) )
            	    // InternalGameDsl.g:855:5: (lv_size_13_0= ruleEInt )
            	    {
            	    // InternalGameDsl.g:855:5: (lv_size_13_0= ruleEInt )
            	    // InternalGameDsl.g:856:6: lv_size_13_0= ruleEInt
            	    {

            	    						newCompositeNode(grammarAccess.getGameObjectAccess().getSizeEIntParserRuleCall_11_1_0());
            	    					
            	    pushFollow(FOLLOW_16);
            	    lv_size_13_0=ruleEInt();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getGameObjectRule());
            	    						}
            	    						add(
            	    							current,
            	    							"size",
            	    							lv_size_13_0,
            	    							"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop17;
                }
            } while (true);

            otherlv_14=(Token)match(input,21,FOLLOW_26); 

            			newLeafNode(otherlv_14, grammarAccess.getGameObjectAccess().getRightParenthesisKeyword_12());
            		
            otherlv_15=(Token)match(input,30,FOLLOW_3); 

            			newLeafNode(otherlv_15, grammarAccess.getGameObjectAccess().getSpriteKeyword_13());
            		
            // InternalGameDsl.g:882:3: ( (lv_sprite_16_0= ruleEString ) )
            // InternalGameDsl.g:883:4: (lv_sprite_16_0= ruleEString )
            {
            // InternalGameDsl.g:883:4: (lv_sprite_16_0= ruleEString )
            // InternalGameDsl.g:884:5: lv_sprite_16_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getGameObjectAccess().getSpriteEStringParserRuleCall_14_0());
            				
            pushFollow(FOLLOW_27);
            lv_sprite_16_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGameObjectRule());
            					}
            					set(
            						current,
            						"sprite",
            						lv_sprite_16_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGameDsl.g:901:3: (otherlv_17= 'isTakingDamage:' ( (lv_isTakingDamage_18_0= ruleEBoolean ) ) )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==31) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalGameDsl.g:902:4: otherlv_17= 'isTakingDamage:' ( (lv_isTakingDamage_18_0= ruleEBoolean ) )
                    {
                    otherlv_17=(Token)match(input,31,FOLLOW_20); 

                    				newLeafNode(otherlv_17, grammarAccess.getGameObjectAccess().getIsTakingDamageKeyword_15_0());
                    			
                    // InternalGameDsl.g:906:4: ( (lv_isTakingDamage_18_0= ruleEBoolean ) )
                    // InternalGameDsl.g:907:5: (lv_isTakingDamage_18_0= ruleEBoolean )
                    {
                    // InternalGameDsl.g:907:5: (lv_isTakingDamage_18_0= ruleEBoolean )
                    // InternalGameDsl.g:908:6: lv_isTakingDamage_18_0= ruleEBoolean
                    {

                    						newCompositeNode(grammarAccess.getGameObjectAccess().getIsTakingDamageEBooleanParserRuleCall_15_1_0());
                    					
                    pushFollow(FOLLOW_28);
                    lv_isTakingDamage_18_0=ruleEBoolean();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGameObjectRule());
                    						}
                    						set(
                    							current,
                    							"isTakingDamage",
                    							lv_isTakingDamage_18_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EBoolean");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGameDsl.g:926:3: (otherlv_19= 'amountOfDamage:' ( (lv_amountOfDamage_20_0= ruleEFloat ) ) )?
            int alt19=2;
            int LA19_0 = input.LA(1);

            if ( (LA19_0==32) ) {
                alt19=1;
            }
            switch (alt19) {
                case 1 :
                    // InternalGameDsl.g:927:4: otherlv_19= 'amountOfDamage:' ( (lv_amountOfDamage_20_0= ruleEFloat ) )
                    {
                    otherlv_19=(Token)match(input,32,FOLLOW_29); 

                    				newLeafNode(otherlv_19, grammarAccess.getGameObjectAccess().getAmountOfDamageKeyword_16_0());
                    			
                    // InternalGameDsl.g:931:4: ( (lv_amountOfDamage_20_0= ruleEFloat ) )
                    // InternalGameDsl.g:932:5: (lv_amountOfDamage_20_0= ruleEFloat )
                    {
                    // InternalGameDsl.g:932:5: (lv_amountOfDamage_20_0= ruleEFloat )
                    // InternalGameDsl.g:933:6: lv_amountOfDamage_20_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getGameObjectAccess().getAmountOfDamageEFloatParserRuleCall_16_1_0());
                    					
                    pushFollow(FOLLOW_30);
                    lv_amountOfDamage_20_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGameObjectRule());
                    						}
                    						set(
                    							current,
                    							"amountOfDamage",
                    							lv_amountOfDamage_20_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGameDsl.g:951:3: (otherlv_21= 'damageDuration:' ( (lv_damageDuration_22_0= ruleEInt ) ) )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==33) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalGameDsl.g:952:4: otherlv_21= 'damageDuration:' ( (lv_damageDuration_22_0= ruleEInt ) )
                    {
                    otherlv_21=(Token)match(input,33,FOLLOW_15); 

                    				newLeafNode(otherlv_21, grammarAccess.getGameObjectAccess().getDamageDurationKeyword_17_0());
                    			
                    // InternalGameDsl.g:956:4: ( (lv_damageDuration_22_0= ruleEInt ) )
                    // InternalGameDsl.g:957:5: (lv_damageDuration_22_0= ruleEInt )
                    {
                    // InternalGameDsl.g:957:5: (lv_damageDuration_22_0= ruleEInt )
                    // InternalGameDsl.g:958:6: lv_damageDuration_22_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getGameObjectAccess().getDamageDurationEIntParserRuleCall_17_1_0());
                    					
                    pushFollow(FOLLOW_31);
                    lv_damageDuration_22_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGameObjectRule());
                    						}
                    						set(
                    							current,
                    							"damageDuration",
                    							lv_damageDuration_22_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_23=(Token)match(input,34,FOLLOW_29); 

            			newLeafNode(otherlv_23, grammarAccess.getGameObjectAccess().getVelocityKeyword_18());
            		
            // InternalGameDsl.g:980:3: ( (lv_velocity_24_0= ruleEFloat ) )
            // InternalGameDsl.g:981:4: (lv_velocity_24_0= ruleEFloat )
            {
            // InternalGameDsl.g:981:4: (lv_velocity_24_0= ruleEFloat )
            // InternalGameDsl.g:982:5: lv_velocity_24_0= ruleEFloat
            {

            					newCompositeNode(grammarAccess.getGameObjectAccess().getVelocityEFloatParserRuleCall_19_0());
            				
            pushFollow(FOLLOW_32);
            lv_velocity_24_0=ruleEFloat();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGameObjectRule());
            					}
            					set(
            						current,
            						"velocity",
            						lv_velocity_24_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EFloat");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_25=(Token)match(input,35,FOLLOW_14); 

            			newLeafNode(otherlv_25, grammarAccess.getGameObjectAccess().getDirectionDegreesKeyword_20());
            		
            otherlv_26=(Token)match(input,20,FOLLOW_29); 

            			newLeafNode(otherlv_26, grammarAccess.getGameObjectAccess().getLeftParenthesisKeyword_21());
            		
            // InternalGameDsl.g:1007:3: ( (lv_directionDegrees_27_0= ruleEDouble ) )
            // InternalGameDsl.g:1008:4: (lv_directionDegrees_27_0= ruleEDouble )
            {
            // InternalGameDsl.g:1008:4: (lv_directionDegrees_27_0= ruleEDouble )
            // InternalGameDsl.g:1009:5: lv_directionDegrees_27_0= ruleEDouble
            {

            					newCompositeNode(grammarAccess.getGameObjectAccess().getDirectionDegreesEDoubleParserRuleCall_22_0());
            				
            pushFollow(FOLLOW_16);
            lv_directionDegrees_27_0=ruleEDouble();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getGameObjectRule());
            					}
            					add(
            						current,
            						"directionDegrees",
            						lv_directionDegrees_27_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EDouble");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGameDsl.g:1026:3: (otherlv_28= ',' ( (lv_directionDegrees_29_0= ruleEDouble ) ) )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==14) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalGameDsl.g:1027:4: otherlv_28= ',' ( (lv_directionDegrees_29_0= ruleEDouble ) )
            	    {
            	    otherlv_28=(Token)match(input,14,FOLLOW_29); 

            	    				newLeafNode(otherlv_28, grammarAccess.getGameObjectAccess().getCommaKeyword_23_0());
            	    			
            	    // InternalGameDsl.g:1031:4: ( (lv_directionDegrees_29_0= ruleEDouble ) )
            	    // InternalGameDsl.g:1032:5: (lv_directionDegrees_29_0= ruleEDouble )
            	    {
            	    // InternalGameDsl.g:1032:5: (lv_directionDegrees_29_0= ruleEDouble )
            	    // InternalGameDsl.g:1033:6: lv_directionDegrees_29_0= ruleEDouble
            	    {

            	    						newCompositeNode(grammarAccess.getGameObjectAccess().getDirectionDegreesEDoubleParserRuleCall_23_1_0());
            	    					
            	    pushFollow(FOLLOW_16);
            	    lv_directionDegrees_29_0=ruleEDouble();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getGameObjectRule());
            	    						}
            	    						add(
            	    							current,
            	    							"directionDegrees",
            	    							lv_directionDegrees_29_0,
            	    							"no.ntnu.tdt4250.csdsl.GameDsl.EDouble");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

            otherlv_30=(Token)match(input,21,FOLLOW_33); 

            			newLeafNode(otherlv_30, grammarAccess.getGameObjectAccess().getRightParenthesisKeyword_24());
            		
            // InternalGameDsl.g:1055:3: (otherlv_31= 'durability:' ( (lv_durability_32_0= ruleEInt ) ) )?
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==36) ) {
                alt22=1;
            }
            switch (alt22) {
                case 1 :
                    // InternalGameDsl.g:1056:4: otherlv_31= 'durability:' ( (lv_durability_32_0= ruleEInt ) )
                    {
                    otherlv_31=(Token)match(input,36,FOLLOW_15); 

                    				newLeafNode(otherlv_31, grammarAccess.getGameObjectAccess().getDurabilityKeyword_25_0());
                    			
                    // InternalGameDsl.g:1060:4: ( (lv_durability_32_0= ruleEInt ) )
                    // InternalGameDsl.g:1061:5: (lv_durability_32_0= ruleEInt )
                    {
                    // InternalGameDsl.g:1061:5: (lv_durability_32_0= ruleEInt )
                    // InternalGameDsl.g:1062:6: lv_durability_32_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getGameObjectAccess().getDurabilityEIntParserRuleCall_25_1_0());
                    					
                    pushFollow(FOLLOW_34);
                    lv_durability_32_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGameObjectRule());
                    						}
                    						set(
                    							current,
                    							"durability",
                    							lv_durability_32_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGameDsl.g:1080:3: (otherlv_33= 'ability' otherlv_34= '{' ( (lv_ability_35_0= ruleAbility ) ) (otherlv_36= ',' ( (lv_ability_37_0= ruleAbility ) ) )* otherlv_38= '}' )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==37) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalGameDsl.g:1081:4: otherlv_33= 'ability' otherlv_34= '{' ( (lv_ability_35_0= ruleAbility ) ) (otherlv_36= ',' ( (lv_ability_37_0= ruleAbility ) ) )* otherlv_38= '}'
                    {
                    otherlv_33=(Token)match(input,37,FOLLOW_4); 

                    				newLeafNode(otherlv_33, grammarAccess.getGameObjectAccess().getAbilityKeyword_26_0());
                    			
                    otherlv_34=(Token)match(input,12,FOLLOW_35); 

                    				newLeafNode(otherlv_34, grammarAccess.getGameObjectAccess().getLeftCurlyBracketKeyword_26_1());
                    			
                    // InternalGameDsl.g:1089:4: ( (lv_ability_35_0= ruleAbility ) )
                    // InternalGameDsl.g:1090:5: (lv_ability_35_0= ruleAbility )
                    {
                    // InternalGameDsl.g:1090:5: (lv_ability_35_0= ruleAbility )
                    // InternalGameDsl.g:1091:6: lv_ability_35_0= ruleAbility
                    {

                    						newCompositeNode(grammarAccess.getGameObjectAccess().getAbilityAbilityParserRuleCall_26_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_ability_35_0=ruleAbility();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGameObjectRule());
                    						}
                    						add(
                    							current,
                    							"ability",
                    							lv_ability_35_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.Ability");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGameDsl.g:1108:4: (otherlv_36= ',' ( (lv_ability_37_0= ruleAbility ) ) )*
                    loop23:
                    do {
                        int alt23=2;
                        int LA23_0 = input.LA(1);

                        if ( (LA23_0==14) ) {
                            alt23=1;
                        }


                        switch (alt23) {
                    	case 1 :
                    	    // InternalGameDsl.g:1109:5: otherlv_36= ',' ( (lv_ability_37_0= ruleAbility ) )
                    	    {
                    	    otherlv_36=(Token)match(input,14,FOLLOW_35); 

                    	    					newLeafNode(otherlv_36, grammarAccess.getGameObjectAccess().getCommaKeyword_26_3_0());
                    	    				
                    	    // InternalGameDsl.g:1113:5: ( (lv_ability_37_0= ruleAbility ) )
                    	    // InternalGameDsl.g:1114:6: (lv_ability_37_0= ruleAbility )
                    	    {
                    	    // InternalGameDsl.g:1114:6: (lv_ability_37_0= ruleAbility )
                    	    // InternalGameDsl.g:1115:7: lv_ability_37_0= ruleAbility
                    	    {

                    	    							newCompositeNode(grammarAccess.getGameObjectAccess().getAbilityAbilityParserRuleCall_26_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_ability_37_0=ruleAbility();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getGameObjectRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"ability",
                    	    								lv_ability_37_0,
                    	    								"no.ntnu.tdt4250.csdsl.GameDsl.Ability");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop23;
                        }
                    } while (true);

                    otherlv_38=(Token)match(input,15,FOLLOW_36); 

                    				newLeafNode(otherlv_38, grammarAccess.getGameObjectAccess().getRightCurlyBracketKeyword_26_4());
                    			

                    }
                    break;

            }

            // InternalGameDsl.g:1138:3: (otherlv_39= 'action' otherlv_40= '{' ( (lv_action_41_0= ruleAction ) ) (otherlv_42= ',' ( (lv_action_43_0= ruleAction ) ) )* otherlv_44= '}' )?
            int alt26=2;
            int LA26_0 = input.LA(1);

            if ( (LA26_0==38) ) {
                alt26=1;
            }
            switch (alt26) {
                case 1 :
                    // InternalGameDsl.g:1139:4: otherlv_39= 'action' otherlv_40= '{' ( (lv_action_41_0= ruleAction ) ) (otherlv_42= ',' ( (lv_action_43_0= ruleAction ) ) )* otherlv_44= '}'
                    {
                    otherlv_39=(Token)match(input,38,FOLLOW_4); 

                    				newLeafNode(otherlv_39, grammarAccess.getGameObjectAccess().getActionKeyword_27_0());
                    			
                    otherlv_40=(Token)match(input,12,FOLLOW_37); 

                    				newLeafNode(otherlv_40, grammarAccess.getGameObjectAccess().getLeftCurlyBracketKeyword_27_1());
                    			
                    // InternalGameDsl.g:1147:4: ( (lv_action_41_0= ruleAction ) )
                    // InternalGameDsl.g:1148:5: (lv_action_41_0= ruleAction )
                    {
                    // InternalGameDsl.g:1148:5: (lv_action_41_0= ruleAction )
                    // InternalGameDsl.g:1149:6: lv_action_41_0= ruleAction
                    {

                    						newCompositeNode(grammarAccess.getGameObjectAccess().getActionActionParserRuleCall_27_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_action_41_0=ruleAction();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getGameObjectRule());
                    						}
                    						add(
                    							current,
                    							"action",
                    							lv_action_41_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.Action");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGameDsl.g:1166:4: (otherlv_42= ',' ( (lv_action_43_0= ruleAction ) ) )*
                    loop25:
                    do {
                        int alt25=2;
                        int LA25_0 = input.LA(1);

                        if ( (LA25_0==14) ) {
                            alt25=1;
                        }


                        switch (alt25) {
                    	case 1 :
                    	    // InternalGameDsl.g:1167:5: otherlv_42= ',' ( (lv_action_43_0= ruleAction ) )
                    	    {
                    	    otherlv_42=(Token)match(input,14,FOLLOW_37); 

                    	    					newLeafNode(otherlv_42, grammarAccess.getGameObjectAccess().getCommaKeyword_27_3_0());
                    	    				
                    	    // InternalGameDsl.g:1171:5: ( (lv_action_43_0= ruleAction ) )
                    	    // InternalGameDsl.g:1172:6: (lv_action_43_0= ruleAction )
                    	    {
                    	    // InternalGameDsl.g:1172:6: (lv_action_43_0= ruleAction )
                    	    // InternalGameDsl.g:1173:7: lv_action_43_0= ruleAction
                    	    {

                    	    							newCompositeNode(grammarAccess.getGameObjectAccess().getActionActionParserRuleCall_27_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_action_43_0=ruleAction();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getGameObjectRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"action",
                    	    								lv_action_43_0,
                    	    								"no.ntnu.tdt4250.csdsl.GameDsl.Action");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop25;
                        }
                    } while (true);

                    otherlv_44=(Token)match(input,15,FOLLOW_12); 

                    				newLeafNode(otherlv_44, grammarAccess.getGameObjectAccess().getRightCurlyBracketKeyword_27_4());
                    			

                    }
                    break;

            }

            otherlv_45=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_45, grammarAccess.getGameObjectAccess().getRightCurlyBracketKeyword_28());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGameObject"


    // $ANTLR start "entryRuleCollisions"
    // InternalGameDsl.g:1204:1: entryRuleCollisions returns [EObject current=null] : iv_ruleCollisions= ruleCollisions EOF ;
    public final EObject entryRuleCollisions() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleCollisions = null;


        try {
            // InternalGameDsl.g:1204:51: (iv_ruleCollisions= ruleCollisions EOF )
            // InternalGameDsl.g:1205:2: iv_ruleCollisions= ruleCollisions EOF
            {
             newCompositeNode(grammarAccess.getCollisionsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleCollisions=ruleCollisions();

            state._fsp--;

             current =iv_ruleCollisions; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleCollisions"


    // $ANTLR start "ruleCollisions"
    // InternalGameDsl.g:1211:1: ruleCollisions returns [EObject current=null] : ( () otherlv_1= 'Collisions' otherlv_2= '{' (otherlv_3= 'hittedSpot:' ( (lv_hittedSpot_4_0= ruleEString ) ) )? (otherlv_5= 'effect:' ( (lv_effect_6_0= ruleEString ) ) )? (otherlv_7= 'effectValue:' ( (lv_effectValue_8_0= ruleEFloat ) ) )? (otherlv_9= 'objID' otherlv_10= '{' ( (lv_objID_11_0= ruleEString ) ) (otherlv_12= ',' ( (lv_objID_13_0= ruleEString ) ) )* otherlv_14= '}' )? otherlv_15= '}' ) ;
    public final EObject ruleCollisions() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_9=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_14=null;
        Token otherlv_15=null;
        AntlrDatatypeRuleToken lv_hittedSpot_4_0 = null;

        AntlrDatatypeRuleToken lv_effect_6_0 = null;

        AntlrDatatypeRuleToken lv_effectValue_8_0 = null;

        AntlrDatatypeRuleToken lv_objID_11_0 = null;

        AntlrDatatypeRuleToken lv_objID_13_0 = null;



        	enterRule();

        try {
            // InternalGameDsl.g:1217:2: ( ( () otherlv_1= 'Collisions' otherlv_2= '{' (otherlv_3= 'hittedSpot:' ( (lv_hittedSpot_4_0= ruleEString ) ) )? (otherlv_5= 'effect:' ( (lv_effect_6_0= ruleEString ) ) )? (otherlv_7= 'effectValue:' ( (lv_effectValue_8_0= ruleEFloat ) ) )? (otherlv_9= 'objID' otherlv_10= '{' ( (lv_objID_11_0= ruleEString ) ) (otherlv_12= ',' ( (lv_objID_13_0= ruleEString ) ) )* otherlv_14= '}' )? otherlv_15= '}' ) )
            // InternalGameDsl.g:1218:2: ( () otherlv_1= 'Collisions' otherlv_2= '{' (otherlv_3= 'hittedSpot:' ( (lv_hittedSpot_4_0= ruleEString ) ) )? (otherlv_5= 'effect:' ( (lv_effect_6_0= ruleEString ) ) )? (otherlv_7= 'effectValue:' ( (lv_effectValue_8_0= ruleEFloat ) ) )? (otherlv_9= 'objID' otherlv_10= '{' ( (lv_objID_11_0= ruleEString ) ) (otherlv_12= ',' ( (lv_objID_13_0= ruleEString ) ) )* otherlv_14= '}' )? otherlv_15= '}' )
            {
            // InternalGameDsl.g:1218:2: ( () otherlv_1= 'Collisions' otherlv_2= '{' (otherlv_3= 'hittedSpot:' ( (lv_hittedSpot_4_0= ruleEString ) ) )? (otherlv_5= 'effect:' ( (lv_effect_6_0= ruleEString ) ) )? (otherlv_7= 'effectValue:' ( (lv_effectValue_8_0= ruleEFloat ) ) )? (otherlv_9= 'objID' otherlv_10= '{' ( (lv_objID_11_0= ruleEString ) ) (otherlv_12= ',' ( (lv_objID_13_0= ruleEString ) ) )* otherlv_14= '}' )? otherlv_15= '}' )
            // InternalGameDsl.g:1219:3: () otherlv_1= 'Collisions' otherlv_2= '{' (otherlv_3= 'hittedSpot:' ( (lv_hittedSpot_4_0= ruleEString ) ) )? (otherlv_5= 'effect:' ( (lv_effect_6_0= ruleEString ) ) )? (otherlv_7= 'effectValue:' ( (lv_effectValue_8_0= ruleEFloat ) ) )? (otherlv_9= 'objID' otherlv_10= '{' ( (lv_objID_11_0= ruleEString ) ) (otherlv_12= ',' ( (lv_objID_13_0= ruleEString ) ) )* otherlv_14= '}' )? otherlv_15= '}'
            {
            // InternalGameDsl.g:1219:3: ()
            // InternalGameDsl.g:1220:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getCollisionsAccess().getCollisionsAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,39,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getCollisionsAccess().getCollisionsKeyword_1());
            		
            otherlv_2=(Token)match(input,12,FOLLOW_38); 

            			newLeafNode(otherlv_2, grammarAccess.getCollisionsAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalGameDsl.g:1234:3: (otherlv_3= 'hittedSpot:' ( (lv_hittedSpot_4_0= ruleEString ) ) )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==40) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalGameDsl.g:1235:4: otherlv_3= 'hittedSpot:' ( (lv_hittedSpot_4_0= ruleEString ) )
                    {
                    otherlv_3=(Token)match(input,40,FOLLOW_3); 

                    				newLeafNode(otherlv_3, grammarAccess.getCollisionsAccess().getHittedSpotKeyword_3_0());
                    			
                    // InternalGameDsl.g:1239:4: ( (lv_hittedSpot_4_0= ruleEString ) )
                    // InternalGameDsl.g:1240:5: (lv_hittedSpot_4_0= ruleEString )
                    {
                    // InternalGameDsl.g:1240:5: (lv_hittedSpot_4_0= ruleEString )
                    // InternalGameDsl.g:1241:6: lv_hittedSpot_4_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getCollisionsAccess().getHittedSpotEStringParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_39);
                    lv_hittedSpot_4_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCollisionsRule());
                    						}
                    						set(
                    							current,
                    							"hittedSpot",
                    							lv_hittedSpot_4_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGameDsl.g:1259:3: (otherlv_5= 'effect:' ( (lv_effect_6_0= ruleEString ) ) )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==41) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalGameDsl.g:1260:4: otherlv_5= 'effect:' ( (lv_effect_6_0= ruleEString ) )
                    {
                    otherlv_5=(Token)match(input,41,FOLLOW_3); 

                    				newLeafNode(otherlv_5, grammarAccess.getCollisionsAccess().getEffectKeyword_4_0());
                    			
                    // InternalGameDsl.g:1264:4: ( (lv_effect_6_0= ruleEString ) )
                    // InternalGameDsl.g:1265:5: (lv_effect_6_0= ruleEString )
                    {
                    // InternalGameDsl.g:1265:5: (lv_effect_6_0= ruleEString )
                    // InternalGameDsl.g:1266:6: lv_effect_6_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getCollisionsAccess().getEffectEStringParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_40);
                    lv_effect_6_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCollisionsRule());
                    						}
                    						set(
                    							current,
                    							"effect",
                    							lv_effect_6_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGameDsl.g:1284:3: (otherlv_7= 'effectValue:' ( (lv_effectValue_8_0= ruleEFloat ) ) )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==42) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalGameDsl.g:1285:4: otherlv_7= 'effectValue:' ( (lv_effectValue_8_0= ruleEFloat ) )
                    {
                    otherlv_7=(Token)match(input,42,FOLLOW_29); 

                    				newLeafNode(otherlv_7, grammarAccess.getCollisionsAccess().getEffectValueKeyword_5_0());
                    			
                    // InternalGameDsl.g:1289:4: ( (lv_effectValue_8_0= ruleEFloat ) )
                    // InternalGameDsl.g:1290:5: (lv_effectValue_8_0= ruleEFloat )
                    {
                    // InternalGameDsl.g:1290:5: (lv_effectValue_8_0= ruleEFloat )
                    // InternalGameDsl.g:1291:6: lv_effectValue_8_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getCollisionsAccess().getEffectValueEFloatParserRuleCall_5_1_0());
                    					
                    pushFollow(FOLLOW_41);
                    lv_effectValue_8_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCollisionsRule());
                    						}
                    						set(
                    							current,
                    							"effectValue",
                    							lv_effectValue_8_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGameDsl.g:1309:3: (otherlv_9= 'objID' otherlv_10= '{' ( (lv_objID_11_0= ruleEString ) ) (otherlv_12= ',' ( (lv_objID_13_0= ruleEString ) ) )* otherlv_14= '}' )?
            int alt31=2;
            int LA31_0 = input.LA(1);

            if ( (LA31_0==43) ) {
                alt31=1;
            }
            switch (alt31) {
                case 1 :
                    // InternalGameDsl.g:1310:4: otherlv_9= 'objID' otherlv_10= '{' ( (lv_objID_11_0= ruleEString ) ) (otherlv_12= ',' ( (lv_objID_13_0= ruleEString ) ) )* otherlv_14= '}'
                    {
                    otherlv_9=(Token)match(input,43,FOLLOW_4); 

                    				newLeafNode(otherlv_9, grammarAccess.getCollisionsAccess().getObjIDKeyword_6_0());
                    			
                    otherlv_10=(Token)match(input,12,FOLLOW_3); 

                    				newLeafNode(otherlv_10, grammarAccess.getCollisionsAccess().getLeftCurlyBracketKeyword_6_1());
                    			
                    // InternalGameDsl.g:1318:4: ( (lv_objID_11_0= ruleEString ) )
                    // InternalGameDsl.g:1319:5: (lv_objID_11_0= ruleEString )
                    {
                    // InternalGameDsl.g:1319:5: (lv_objID_11_0= ruleEString )
                    // InternalGameDsl.g:1320:6: lv_objID_11_0= ruleEString
                    {

                    						newCompositeNode(grammarAccess.getCollisionsAccess().getObjIDEStringParserRuleCall_6_2_0());
                    					
                    pushFollow(FOLLOW_7);
                    lv_objID_11_0=ruleEString();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getCollisionsRule());
                    						}
                    						add(
                    							current,
                    							"objID",
                    							lv_objID_11_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EString");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }

                    // InternalGameDsl.g:1337:4: (otherlv_12= ',' ( (lv_objID_13_0= ruleEString ) ) )*
                    loop30:
                    do {
                        int alt30=2;
                        int LA30_0 = input.LA(1);

                        if ( (LA30_0==14) ) {
                            alt30=1;
                        }


                        switch (alt30) {
                    	case 1 :
                    	    // InternalGameDsl.g:1338:5: otherlv_12= ',' ( (lv_objID_13_0= ruleEString ) )
                    	    {
                    	    otherlv_12=(Token)match(input,14,FOLLOW_3); 

                    	    					newLeafNode(otherlv_12, grammarAccess.getCollisionsAccess().getCommaKeyword_6_3_0());
                    	    				
                    	    // InternalGameDsl.g:1342:5: ( (lv_objID_13_0= ruleEString ) )
                    	    // InternalGameDsl.g:1343:6: (lv_objID_13_0= ruleEString )
                    	    {
                    	    // InternalGameDsl.g:1343:6: (lv_objID_13_0= ruleEString )
                    	    // InternalGameDsl.g:1344:7: lv_objID_13_0= ruleEString
                    	    {

                    	    							newCompositeNode(grammarAccess.getCollisionsAccess().getObjIDEStringParserRuleCall_6_3_1_0());
                    	    						
                    	    pushFollow(FOLLOW_7);
                    	    lv_objID_13_0=ruleEString();

                    	    state._fsp--;


                    	    							if (current==null) {
                    	    								current = createModelElementForParent(grammarAccess.getCollisionsRule());
                    	    							}
                    	    							add(
                    	    								current,
                    	    								"objID",
                    	    								lv_objID_13_0,
                    	    								"no.ntnu.tdt4250.csdsl.GameDsl.EString");
                    	    							afterParserOrEnumRuleCall();
                    	    						

                    	    }


                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop30;
                        }
                    } while (true);

                    otherlv_14=(Token)match(input,15,FOLLOW_12); 

                    				newLeafNode(otherlv_14, grammarAccess.getCollisionsAccess().getRightCurlyBracketKeyword_6_4());
                    			

                    }
                    break;

            }

            otherlv_15=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_15, grammarAccess.getCollisionsAccess().getRightCurlyBracketKeyword_7());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleCollisions"


    // $ANTLR start "entryRuleAbility"
    // InternalGameDsl.g:1375:1: entryRuleAbility returns [EObject current=null] : iv_ruleAbility= ruleAbility EOF ;
    public final EObject entryRuleAbility() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAbility = null;


        try {
            // InternalGameDsl.g:1375:48: (iv_ruleAbility= ruleAbility EOF )
            // InternalGameDsl.g:1376:2: iv_ruleAbility= ruleAbility EOF
            {
             newCompositeNode(grammarAccess.getAbilityRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAbility=ruleAbility();

            state._fsp--;

             current =iv_ruleAbility; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAbility"


    // $ANTLR start "ruleAbility"
    // InternalGameDsl.g:1382:1: ruleAbility returns [EObject current=null] : (otherlv_0= 'Ability' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'duration:' ( (lv_duration_4_0= ruleEInt ) ) )? otherlv_5= 'isBeingUsed:' ( (lv_isBeingUsed_6_0= ruleEBoolean ) ) otherlv_7= 'effect' otherlv_8= '{' ( (lv_effect_9_0= ruleEffect ) ) (otherlv_10= ',' ( (lv_effect_11_0= ruleEffect ) ) )* otherlv_12= '}' otherlv_13= '}' ) ;
    public final EObject ruleAbility() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        AntlrDatatypeRuleToken lv_duration_4_0 = null;

        AntlrDatatypeRuleToken lv_isBeingUsed_6_0 = null;

        EObject lv_effect_9_0 = null;

        EObject lv_effect_11_0 = null;



        	enterRule();

        try {
            // InternalGameDsl.g:1388:2: ( (otherlv_0= 'Ability' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'duration:' ( (lv_duration_4_0= ruleEInt ) ) )? otherlv_5= 'isBeingUsed:' ( (lv_isBeingUsed_6_0= ruleEBoolean ) ) otherlv_7= 'effect' otherlv_8= '{' ( (lv_effect_9_0= ruleEffect ) ) (otherlv_10= ',' ( (lv_effect_11_0= ruleEffect ) ) )* otherlv_12= '}' otherlv_13= '}' ) )
            // InternalGameDsl.g:1389:2: (otherlv_0= 'Ability' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'duration:' ( (lv_duration_4_0= ruleEInt ) ) )? otherlv_5= 'isBeingUsed:' ( (lv_isBeingUsed_6_0= ruleEBoolean ) ) otherlv_7= 'effect' otherlv_8= '{' ( (lv_effect_9_0= ruleEffect ) ) (otherlv_10= ',' ( (lv_effect_11_0= ruleEffect ) ) )* otherlv_12= '}' otherlv_13= '}' )
            {
            // InternalGameDsl.g:1389:2: (otherlv_0= 'Ability' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'duration:' ( (lv_duration_4_0= ruleEInt ) ) )? otherlv_5= 'isBeingUsed:' ( (lv_isBeingUsed_6_0= ruleEBoolean ) ) otherlv_7= 'effect' otherlv_8= '{' ( (lv_effect_9_0= ruleEffect ) ) (otherlv_10= ',' ( (lv_effect_11_0= ruleEffect ) ) )* otherlv_12= '}' otherlv_13= '}' )
            // InternalGameDsl.g:1390:3: otherlv_0= 'Ability' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' (otherlv_3= 'duration:' ( (lv_duration_4_0= ruleEInt ) ) )? otherlv_5= 'isBeingUsed:' ( (lv_isBeingUsed_6_0= ruleEBoolean ) ) otherlv_7= 'effect' otherlv_8= '{' ( (lv_effect_9_0= ruleEffect ) ) (otherlv_10= ',' ( (lv_effect_11_0= ruleEffect ) ) )* otherlv_12= '}' otherlv_13= '}'
            {
            otherlv_0=(Token)match(input,44,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getAbilityAccess().getAbilityKeyword_0());
            		
            // InternalGameDsl.g:1394:3: ( (lv_name_1_0= ruleEString ) )
            // InternalGameDsl.g:1395:4: (lv_name_1_0= ruleEString )
            {
            // InternalGameDsl.g:1395:4: (lv_name_1_0= ruleEString )
            // InternalGameDsl.g:1396:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getAbilityAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAbilityRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_42); 

            			newLeafNode(otherlv_2, grammarAccess.getAbilityAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalGameDsl.g:1417:3: (otherlv_3= 'duration:' ( (lv_duration_4_0= ruleEInt ) ) )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==45) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalGameDsl.g:1418:4: otherlv_3= 'duration:' ( (lv_duration_4_0= ruleEInt ) )
                    {
                    otherlv_3=(Token)match(input,45,FOLLOW_15); 

                    				newLeafNode(otherlv_3, grammarAccess.getAbilityAccess().getDurationKeyword_3_0());
                    			
                    // InternalGameDsl.g:1422:4: ( (lv_duration_4_0= ruleEInt ) )
                    // InternalGameDsl.g:1423:5: (lv_duration_4_0= ruleEInt )
                    {
                    // InternalGameDsl.g:1423:5: (lv_duration_4_0= ruleEInt )
                    // InternalGameDsl.g:1424:6: lv_duration_4_0= ruleEInt
                    {

                    						newCompositeNode(grammarAccess.getAbilityAccess().getDurationEIntParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_43);
                    lv_duration_4_0=ruleEInt();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getAbilityRule());
                    						}
                    						set(
                    							current,
                    							"duration",
                    							lv_duration_4_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EInt");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_5=(Token)match(input,46,FOLLOW_20); 

            			newLeafNode(otherlv_5, grammarAccess.getAbilityAccess().getIsBeingUsedKeyword_4());
            		
            // InternalGameDsl.g:1446:3: ( (lv_isBeingUsed_6_0= ruleEBoolean ) )
            // InternalGameDsl.g:1447:4: (lv_isBeingUsed_6_0= ruleEBoolean )
            {
            // InternalGameDsl.g:1447:4: (lv_isBeingUsed_6_0= ruleEBoolean )
            // InternalGameDsl.g:1448:5: lv_isBeingUsed_6_0= ruleEBoolean
            {

            					newCompositeNode(grammarAccess.getAbilityAccess().getIsBeingUsedEBooleanParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_44);
            lv_isBeingUsed_6_0=ruleEBoolean();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAbilityRule());
            					}
            					set(
            						current,
            						"isBeingUsed",
            						lv_isBeingUsed_6_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EBoolean");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_7=(Token)match(input,47,FOLLOW_4); 

            			newLeafNode(otherlv_7, grammarAccess.getAbilityAccess().getEffectKeyword_6());
            		
            otherlv_8=(Token)match(input,12,FOLLOW_45); 

            			newLeafNode(otherlv_8, grammarAccess.getAbilityAccess().getLeftCurlyBracketKeyword_7());
            		
            // InternalGameDsl.g:1473:3: ( (lv_effect_9_0= ruleEffect ) )
            // InternalGameDsl.g:1474:4: (lv_effect_9_0= ruleEffect )
            {
            // InternalGameDsl.g:1474:4: (lv_effect_9_0= ruleEffect )
            // InternalGameDsl.g:1475:5: lv_effect_9_0= ruleEffect
            {

            					newCompositeNode(grammarAccess.getAbilityAccess().getEffectEffectParserRuleCall_8_0());
            				
            pushFollow(FOLLOW_7);
            lv_effect_9_0=ruleEffect();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getAbilityRule());
            					}
            					add(
            						current,
            						"effect",
            						lv_effect_9_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.Effect");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalGameDsl.g:1492:3: (otherlv_10= ',' ( (lv_effect_11_0= ruleEffect ) ) )*
            loop33:
            do {
                int alt33=2;
                int LA33_0 = input.LA(1);

                if ( (LA33_0==14) ) {
                    alt33=1;
                }


                switch (alt33) {
            	case 1 :
            	    // InternalGameDsl.g:1493:4: otherlv_10= ',' ( (lv_effect_11_0= ruleEffect ) )
            	    {
            	    otherlv_10=(Token)match(input,14,FOLLOW_45); 

            	    				newLeafNode(otherlv_10, grammarAccess.getAbilityAccess().getCommaKeyword_9_0());
            	    			
            	    // InternalGameDsl.g:1497:4: ( (lv_effect_11_0= ruleEffect ) )
            	    // InternalGameDsl.g:1498:5: (lv_effect_11_0= ruleEffect )
            	    {
            	    // InternalGameDsl.g:1498:5: (lv_effect_11_0= ruleEffect )
            	    // InternalGameDsl.g:1499:6: lv_effect_11_0= ruleEffect
            	    {

            	    						newCompositeNode(grammarAccess.getAbilityAccess().getEffectEffectParserRuleCall_9_1_0());
            	    					
            	    pushFollow(FOLLOW_7);
            	    lv_effect_11_0=ruleEffect();

            	    state._fsp--;


            	    						if (current==null) {
            	    							current = createModelElementForParent(grammarAccess.getAbilityRule());
            	    						}
            	    						add(
            	    							current,
            	    							"effect",
            	    							lv_effect_11_0,
            	    							"no.ntnu.tdt4250.csdsl.GameDsl.Effect");
            	    						afterParserOrEnumRuleCall();
            	    					

            	    }


            	    }


            	    }
            	    break;

            	default :
            	    break loop33;
                }
            } while (true);

            otherlv_12=(Token)match(input,15,FOLLOW_12); 

            			newLeafNode(otherlv_12, grammarAccess.getAbilityAccess().getRightCurlyBracketKeyword_10());
            		
            otherlv_13=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_13, grammarAccess.getAbilityAccess().getRightCurlyBracketKeyword_11());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAbility"


    // $ANTLR start "entryRuleAction"
    // InternalGameDsl.g:1529:1: entryRuleAction returns [EObject current=null] : iv_ruleAction= ruleAction EOF ;
    public final EObject entryRuleAction() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleAction = null;


        try {
            // InternalGameDsl.g:1529:47: (iv_ruleAction= ruleAction EOF )
            // InternalGameDsl.g:1530:2: iv_ruleAction= ruleAction EOF
            {
             newCompositeNode(grammarAccess.getActionRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAction=ruleAction();

            state._fsp--;

             current =iv_ruleAction; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAction"


    // $ANTLR start "ruleAction"
    // InternalGameDsl.g:1536:1: ruleAction returns [EObject current=null] : (otherlv_0= 'Action' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'effect:' ( (lv_effect_4_0= ruleEString ) ) otherlv_5= '}' ) ;
    public final EObject ruleAction() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;

        AntlrDatatypeRuleToken lv_effect_4_0 = null;



        	enterRule();

        try {
            // InternalGameDsl.g:1542:2: ( (otherlv_0= 'Action' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'effect:' ( (lv_effect_4_0= ruleEString ) ) otherlv_5= '}' ) )
            // InternalGameDsl.g:1543:2: (otherlv_0= 'Action' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'effect:' ( (lv_effect_4_0= ruleEString ) ) otherlv_5= '}' )
            {
            // InternalGameDsl.g:1543:2: (otherlv_0= 'Action' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'effect:' ( (lv_effect_4_0= ruleEString ) ) otherlv_5= '}' )
            // InternalGameDsl.g:1544:3: otherlv_0= 'Action' ( (lv_name_1_0= ruleEString ) ) otherlv_2= '{' otherlv_3= 'effect:' ( (lv_effect_4_0= ruleEString ) ) otherlv_5= '}'
            {
            otherlv_0=(Token)match(input,48,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getActionAccess().getActionKeyword_0());
            		
            // InternalGameDsl.g:1548:3: ( (lv_name_1_0= ruleEString ) )
            // InternalGameDsl.g:1549:4: (lv_name_1_0= ruleEString )
            {
            // InternalGameDsl.g:1549:4: (lv_name_1_0= ruleEString )
            // InternalGameDsl.g:1550:5: lv_name_1_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getActionAccess().getNameEStringParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_4);
            lv_name_1_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getActionRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_46); 

            			newLeafNode(otherlv_2, grammarAccess.getActionAccess().getLeftCurlyBracketKeyword_2());
            		
            otherlv_3=(Token)match(input,41,FOLLOW_3); 

            			newLeafNode(otherlv_3, grammarAccess.getActionAccess().getEffectKeyword_3());
            		
            // InternalGameDsl.g:1575:3: ( (lv_effect_4_0= ruleEString ) )
            // InternalGameDsl.g:1576:4: (lv_effect_4_0= ruleEString )
            {
            // InternalGameDsl.g:1576:4: (lv_effect_4_0= ruleEString )
            // InternalGameDsl.g:1577:5: lv_effect_4_0= ruleEString
            {

            					newCompositeNode(grammarAccess.getActionAccess().getEffectEStringParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_12);
            lv_effect_4_0=ruleEString();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getActionRule());
            					}
            					set(
            						current,
            						"effect",
            						lv_effect_4_0,
            						"no.ntnu.tdt4250.csdsl.GameDsl.EString");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_5=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_5, grammarAccess.getActionAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAction"


    // $ANTLR start "entryRuleEffect"
    // InternalGameDsl.g:1602:1: entryRuleEffect returns [EObject current=null] : iv_ruleEffect= ruleEffect EOF ;
    public final EObject entryRuleEffect() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleEffect = null;


        try {
            // InternalGameDsl.g:1602:47: (iv_ruleEffect= ruleEffect EOF )
            // InternalGameDsl.g:1603:2: iv_ruleEffect= ruleEffect EOF
            {
             newCompositeNode(grammarAccess.getEffectRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEffect=ruleEffect();

            state._fsp--;

             current =iv_ruleEffect; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEffect"


    // $ANTLR start "ruleEffect"
    // InternalGameDsl.g:1609:1: ruleEffect returns [EObject current=null] : (otherlv_0= 'Effect' ( (lv_identifier_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'velocity:' ( (lv_velocity_4_0= ruleEFloat ) ) )? (otherlv_5= 'range:' ( (lv_range_6_0= ruleEFloat ) ) )? otherlv_7= '}' ) ;
    public final EObject ruleEffect() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_identifier_1_0=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        AntlrDatatypeRuleToken lv_velocity_4_0 = null;

        AntlrDatatypeRuleToken lv_range_6_0 = null;



        	enterRule();

        try {
            // InternalGameDsl.g:1615:2: ( (otherlv_0= 'Effect' ( (lv_identifier_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'velocity:' ( (lv_velocity_4_0= ruleEFloat ) ) )? (otherlv_5= 'range:' ( (lv_range_6_0= ruleEFloat ) ) )? otherlv_7= '}' ) )
            // InternalGameDsl.g:1616:2: (otherlv_0= 'Effect' ( (lv_identifier_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'velocity:' ( (lv_velocity_4_0= ruleEFloat ) ) )? (otherlv_5= 'range:' ( (lv_range_6_0= ruleEFloat ) ) )? otherlv_7= '}' )
            {
            // InternalGameDsl.g:1616:2: (otherlv_0= 'Effect' ( (lv_identifier_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'velocity:' ( (lv_velocity_4_0= ruleEFloat ) ) )? (otherlv_5= 'range:' ( (lv_range_6_0= ruleEFloat ) ) )? otherlv_7= '}' )
            // InternalGameDsl.g:1617:3: otherlv_0= 'Effect' ( (lv_identifier_1_0= RULE_ID ) ) otherlv_2= '{' (otherlv_3= 'velocity:' ( (lv_velocity_4_0= ruleEFloat ) ) )? (otherlv_5= 'range:' ( (lv_range_6_0= ruleEFloat ) ) )? otherlv_7= '}'
            {
            otherlv_0=(Token)match(input,49,FOLLOW_47); 

            			newLeafNode(otherlv_0, grammarAccess.getEffectAccess().getEffectKeyword_0());
            		
            // InternalGameDsl.g:1621:3: ( (lv_identifier_1_0= RULE_ID ) )
            // InternalGameDsl.g:1622:4: (lv_identifier_1_0= RULE_ID )
            {
            // InternalGameDsl.g:1622:4: (lv_identifier_1_0= RULE_ID )
            // InternalGameDsl.g:1623:5: lv_identifier_1_0= RULE_ID
            {
            lv_identifier_1_0=(Token)match(input,RULE_ID,FOLLOW_4); 

            					newLeafNode(lv_identifier_1_0, grammarAccess.getEffectAccess().getIdentifierIDTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getEffectRule());
            					}
            					setWithLastConsumed(
            						current,
            						"identifier",
            						lv_identifier_1_0,
            						"org.eclipse.xtext.common.Terminals.ID");
            				

            }


            }

            otherlv_2=(Token)match(input,12,FOLLOW_48); 

            			newLeafNode(otherlv_2, grammarAccess.getEffectAccess().getLeftCurlyBracketKeyword_2());
            		
            // InternalGameDsl.g:1643:3: (otherlv_3= 'velocity:' ( (lv_velocity_4_0= ruleEFloat ) ) )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==34) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalGameDsl.g:1644:4: otherlv_3= 'velocity:' ( (lv_velocity_4_0= ruleEFloat ) )
                    {
                    otherlv_3=(Token)match(input,34,FOLLOW_29); 

                    				newLeafNode(otherlv_3, grammarAccess.getEffectAccess().getVelocityKeyword_3_0());
                    			
                    // InternalGameDsl.g:1648:4: ( (lv_velocity_4_0= ruleEFloat ) )
                    // InternalGameDsl.g:1649:5: (lv_velocity_4_0= ruleEFloat )
                    {
                    // InternalGameDsl.g:1649:5: (lv_velocity_4_0= ruleEFloat )
                    // InternalGameDsl.g:1650:6: lv_velocity_4_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getEffectAccess().getVelocityEFloatParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_49);
                    lv_velocity_4_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getEffectRule());
                    						}
                    						set(
                    							current,
                    							"velocity",
                    							lv_velocity_4_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            // InternalGameDsl.g:1668:3: (otherlv_5= 'range:' ( (lv_range_6_0= ruleEFloat ) ) )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==50) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalGameDsl.g:1669:4: otherlv_5= 'range:' ( (lv_range_6_0= ruleEFloat ) )
                    {
                    otherlv_5=(Token)match(input,50,FOLLOW_29); 

                    				newLeafNode(otherlv_5, grammarAccess.getEffectAccess().getRangeKeyword_4_0());
                    			
                    // InternalGameDsl.g:1673:4: ( (lv_range_6_0= ruleEFloat ) )
                    // InternalGameDsl.g:1674:5: (lv_range_6_0= ruleEFloat )
                    {
                    // InternalGameDsl.g:1674:5: (lv_range_6_0= ruleEFloat )
                    // InternalGameDsl.g:1675:6: lv_range_6_0= ruleEFloat
                    {

                    						newCompositeNode(grammarAccess.getEffectAccess().getRangeEFloatParserRuleCall_4_1_0());
                    					
                    pushFollow(FOLLOW_12);
                    lv_range_6_0=ruleEFloat();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getEffectRule());
                    						}
                    						set(
                    							current,
                    							"range",
                    							lv_range_6_0,
                    							"no.ntnu.tdt4250.csdsl.GameDsl.EFloat");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_7=(Token)match(input,15,FOLLOW_2); 

            			newLeafNode(otherlv_7, grammarAccess.getEffectAccess().getRightCurlyBracketKeyword_5());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEffect"


    // $ANTLR start "entryRuleAnySimpleType"
    // InternalGameDsl.g:1701:1: entryRuleAnySimpleType returns [String current=null] : iv_ruleAnySimpleType= ruleAnySimpleType EOF ;
    public final String entryRuleAnySimpleType() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleAnySimpleType = null;


        try {
            // InternalGameDsl.g:1701:53: (iv_ruleAnySimpleType= ruleAnySimpleType EOF )
            // InternalGameDsl.g:1702:2: iv_ruleAnySimpleType= ruleAnySimpleType EOF
            {
             newCompositeNode(grammarAccess.getAnySimpleTypeRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleAnySimpleType=ruleAnySimpleType();

            state._fsp--;

             current =iv_ruleAnySimpleType.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleAnySimpleType"


    // $ANTLR start "ruleAnySimpleType"
    // InternalGameDsl.g:1708:1: ruleAnySimpleType returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_EBoolean_1= ruleEBoolean | this_EFloat_2= ruleEFloat | this_EInt_3= ruleEInt ) ;
    public final AntlrDatatypeRuleToken ruleAnySimpleType() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        AntlrDatatypeRuleToken this_EBoolean_1 = null;

        AntlrDatatypeRuleToken this_EFloat_2 = null;

        AntlrDatatypeRuleToken this_EInt_3 = null;



        	enterRule();

        try {
            // InternalGameDsl.g:1714:2: ( (this_STRING_0= RULE_STRING | this_EBoolean_1= ruleEBoolean | this_EFloat_2= ruleEFloat | this_EInt_3= ruleEInt ) )
            // InternalGameDsl.g:1715:2: (this_STRING_0= RULE_STRING | this_EBoolean_1= ruleEBoolean | this_EFloat_2= ruleEFloat | this_EInt_3= ruleEInt )
            {
            // InternalGameDsl.g:1715:2: (this_STRING_0= RULE_STRING | this_EBoolean_1= ruleEBoolean | this_EFloat_2= ruleEFloat | this_EInt_3= ruleEInt )
            int alt36=4;
            switch ( input.LA(1) ) {
            case RULE_STRING:
                {
                alt36=1;
                }
                break;
            case 52:
            case 53:
                {
                alt36=2;
                }
                break;
            case 51:
                {
                int LA36_3 = input.LA(2);

                if ( (LA36_3==RULE_INT) ) {
                    int LA36_4 = input.LA(3);

                    if ( (LA36_4==54) ) {
                        alt36=3;
                    }
                    else if ( (LA36_4==EOF||LA36_4==14||LA36_4==21) ) {
                        alt36=4;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 36, 4, input);

                        throw nvae;
                    }
                }
                else if ( (LA36_3==54) ) {
                    alt36=3;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 36, 3, input);

                    throw nvae;
                }
                }
                break;
            case RULE_INT:
                {
                int LA36_4 = input.LA(2);

                if ( (LA36_4==54) ) {
                    alt36=3;
                }
                else if ( (LA36_4==EOF||LA36_4==14||LA36_4==21) ) {
                    alt36=4;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 36, 4, input);

                    throw nvae;
                }
                }
                break;
            case 54:
                {
                alt36=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 36, 0, input);

                throw nvae;
            }

            switch (alt36) {
                case 1 :
                    // InternalGameDsl.g:1716:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getAnySimpleTypeAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalGameDsl.g:1724:3: this_EBoolean_1= ruleEBoolean
                    {

                    			newCompositeNode(grammarAccess.getAnySimpleTypeAccess().getEBooleanParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_EBoolean_1=ruleEBoolean();

                    state._fsp--;


                    			current.merge(this_EBoolean_1);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalGameDsl.g:1735:3: this_EFloat_2= ruleEFloat
                    {

                    			newCompositeNode(grammarAccess.getAnySimpleTypeAccess().getEFloatParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_EFloat_2=ruleEFloat();

                    state._fsp--;


                    			current.merge(this_EFloat_2);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalGameDsl.g:1746:3: this_EInt_3= ruleEInt
                    {

                    			newCompositeNode(grammarAccess.getAnySimpleTypeAccess().getEIntParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_EInt_3=ruleEInt();

                    state._fsp--;


                    			current.merge(this_EInt_3);
                    		

                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleAnySimpleType"


    // $ANTLR start "entryRuleEInt"
    // InternalGameDsl.g:1760:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalGameDsl.g:1760:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalGameDsl.g:1761:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalGameDsl.g:1767:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? this_INT_1= RULE_INT ) ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;


        	enterRule();

        try {
            // InternalGameDsl.g:1773:2: ( ( (kw= '-' )? this_INT_1= RULE_INT ) )
            // InternalGameDsl.g:1774:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            {
            // InternalGameDsl.g:1774:2: ( (kw= '-' )? this_INT_1= RULE_INT )
            // InternalGameDsl.g:1775:3: (kw= '-' )? this_INT_1= RULE_INT
            {
            // InternalGameDsl.g:1775:3: (kw= '-' )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==51) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalGameDsl.g:1776:4: kw= '-'
                    {
                    kw=(Token)match(input,51,FOLLOW_50); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEIntAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            this_INT_1=(Token)match(input,RULE_INT,FOLLOW_2); 

            			current.merge(this_INT_1);
            		

            			newLeafNode(this_INT_1, grammarAccess.getEIntAccess().getINTTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleEBoolean"
    // InternalGameDsl.g:1793:1: entryRuleEBoolean returns [String current=null] : iv_ruleEBoolean= ruleEBoolean EOF ;
    public final String entryRuleEBoolean() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEBoolean = null;


        try {
            // InternalGameDsl.g:1793:48: (iv_ruleEBoolean= ruleEBoolean EOF )
            // InternalGameDsl.g:1794:2: iv_ruleEBoolean= ruleEBoolean EOF
            {
             newCompositeNode(grammarAccess.getEBooleanRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEBoolean=ruleEBoolean();

            state._fsp--;

             current =iv_ruleEBoolean.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEBoolean"


    // $ANTLR start "ruleEBoolean"
    // InternalGameDsl.g:1800:1: ruleEBoolean returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= 'true' | kw= 'false' ) ;
    public final AntlrDatatypeRuleToken ruleEBoolean() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalGameDsl.g:1806:2: ( (kw= 'true' | kw= 'false' ) )
            // InternalGameDsl.g:1807:2: (kw= 'true' | kw= 'false' )
            {
            // InternalGameDsl.g:1807:2: (kw= 'true' | kw= 'false' )
            int alt38=2;
            int LA38_0 = input.LA(1);

            if ( (LA38_0==52) ) {
                alt38=1;
            }
            else if ( (LA38_0==53) ) {
                alt38=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 38, 0, input);

                throw nvae;
            }
            switch (alt38) {
                case 1 :
                    // InternalGameDsl.g:1808:3: kw= 'true'
                    {
                    kw=(Token)match(input,52,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getEBooleanAccess().getTrueKeyword_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalGameDsl.g:1814:3: kw= 'false'
                    {
                    kw=(Token)match(input,53,FOLLOW_2); 

                    			current.merge(kw);
                    			newLeafNode(kw, grammarAccess.getEBooleanAccess().getFalseKeyword_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEBoolean"


    // $ANTLR start "entryRuleEFloat"
    // InternalGameDsl.g:1823:1: entryRuleEFloat returns [String current=null] : iv_ruleEFloat= ruleEFloat EOF ;
    public final String entryRuleEFloat() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEFloat = null;


        try {
            // InternalGameDsl.g:1823:46: (iv_ruleEFloat= ruleEFloat EOF )
            // InternalGameDsl.g:1824:2: iv_ruleEFloat= ruleEFloat EOF
            {
             newCompositeNode(grammarAccess.getEFloatRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEFloat=ruleEFloat();

            state._fsp--;

             current =iv_ruleEFloat.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEFloat"


    // $ANTLR start "ruleEFloat"
    // InternalGameDsl.g:1830:1: ruleEFloat returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) ;
    public final AntlrDatatypeRuleToken ruleEFloat() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;
        Token this_INT_3=null;
        Token this_INT_7=null;


        	enterRule();

        try {
            // InternalGameDsl.g:1836:2: ( ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) )
            // InternalGameDsl.g:1837:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            {
            // InternalGameDsl.g:1837:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            // InternalGameDsl.g:1838:3: (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            {
            // InternalGameDsl.g:1838:3: (kw= '-' )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==51) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalGameDsl.g:1839:4: kw= '-'
                    {
                    kw=(Token)match(input,51,FOLLOW_51); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEFloatAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            // InternalGameDsl.g:1845:3: (this_INT_1= RULE_INT )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==RULE_INT) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalGameDsl.g:1846:4: this_INT_1= RULE_INT
                    {
                    this_INT_1=(Token)match(input,RULE_INT,FOLLOW_52); 

                    				current.merge(this_INT_1);
                    			

                    				newLeafNode(this_INT_1, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_1());
                    			

                    }
                    break;

            }

            kw=(Token)match(input,54,FOLLOW_50); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getEFloatAccess().getFullStopKeyword_2());
            		
            this_INT_3=(Token)match(input,RULE_INT,FOLLOW_53); 

            			current.merge(this_INT_3);
            		

            			newLeafNode(this_INT_3, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_3());
            		
            // InternalGameDsl.g:1866:3: ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( ((LA43_0>=55 && LA43_0<=56)) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalGameDsl.g:1867:4: (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT
                    {
                    // InternalGameDsl.g:1867:4: (kw= 'E' | kw= 'e' )
                    int alt41=2;
                    int LA41_0 = input.LA(1);

                    if ( (LA41_0==55) ) {
                        alt41=1;
                    }
                    else if ( (LA41_0==56) ) {
                        alt41=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 41, 0, input);

                        throw nvae;
                    }
                    switch (alt41) {
                        case 1 :
                            // InternalGameDsl.g:1868:5: kw= 'E'
                            {
                            kw=(Token)match(input,55,FOLLOW_15); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getEKeyword_4_0_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalGameDsl.g:1874:5: kw= 'e'
                            {
                            kw=(Token)match(input,56,FOLLOW_15); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getEKeyword_4_0_1());
                            				

                            }
                            break;

                    }

                    // InternalGameDsl.g:1880:4: (kw= '-' )?
                    int alt42=2;
                    int LA42_0 = input.LA(1);

                    if ( (LA42_0==51) ) {
                        alt42=1;
                    }
                    switch (alt42) {
                        case 1 :
                            // InternalGameDsl.g:1881:5: kw= '-'
                            {
                            kw=(Token)match(input,51,FOLLOW_50); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEFloatAccess().getHyphenMinusKeyword_4_1());
                            				

                            }
                            break;

                    }

                    this_INT_7=(Token)match(input,RULE_INT,FOLLOW_2); 

                    				current.merge(this_INT_7);
                    			

                    				newLeafNode(this_INT_7, grammarAccess.getEFloatAccess().getINTTerminalRuleCall_4_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEFloat"


    // $ANTLR start "entryRuleEDouble"
    // InternalGameDsl.g:1899:1: entryRuleEDouble returns [String current=null] : iv_ruleEDouble= ruleEDouble EOF ;
    public final String entryRuleEDouble() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEDouble = null;


        try {
            // InternalGameDsl.g:1899:47: (iv_ruleEDouble= ruleEDouble EOF )
            // InternalGameDsl.g:1900:2: iv_ruleEDouble= ruleEDouble EOF
            {
             newCompositeNode(grammarAccess.getEDoubleRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEDouble=ruleEDouble();

            state._fsp--;

             current =iv_ruleEDouble.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEDouble"


    // $ANTLR start "ruleEDouble"
    // InternalGameDsl.g:1906:1: ruleEDouble returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) ;
    public final AntlrDatatypeRuleToken ruleEDouble() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_INT_1=null;
        Token this_INT_3=null;
        Token this_INT_7=null;


        	enterRule();

        try {
            // InternalGameDsl.g:1912:2: ( ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? ) )
            // InternalGameDsl.g:1913:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            {
            // InternalGameDsl.g:1913:2: ( (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )? )
            // InternalGameDsl.g:1914:3: (kw= '-' )? (this_INT_1= RULE_INT )? kw= '.' this_INT_3= RULE_INT ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            {
            // InternalGameDsl.g:1914:3: (kw= '-' )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( (LA44_0==51) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalGameDsl.g:1915:4: kw= '-'
                    {
                    kw=(Token)match(input,51,FOLLOW_51); 

                    				current.merge(kw);
                    				newLeafNode(kw, grammarAccess.getEDoubleAccess().getHyphenMinusKeyword_0());
                    			

                    }
                    break;

            }

            // InternalGameDsl.g:1921:3: (this_INT_1= RULE_INT )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==RULE_INT) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalGameDsl.g:1922:4: this_INT_1= RULE_INT
                    {
                    this_INT_1=(Token)match(input,RULE_INT,FOLLOW_52); 

                    				current.merge(this_INT_1);
                    			

                    				newLeafNode(this_INT_1, grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_1());
                    			

                    }
                    break;

            }

            kw=(Token)match(input,54,FOLLOW_50); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getEDoubleAccess().getFullStopKeyword_2());
            		
            this_INT_3=(Token)match(input,RULE_INT,FOLLOW_53); 

            			current.merge(this_INT_3);
            		

            			newLeafNode(this_INT_3, grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_3());
            		
            // InternalGameDsl.g:1942:3: ( (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( ((LA48_0>=55 && LA48_0<=56)) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalGameDsl.g:1943:4: (kw= 'E' | kw= 'e' ) (kw= '-' )? this_INT_7= RULE_INT
                    {
                    // InternalGameDsl.g:1943:4: (kw= 'E' | kw= 'e' )
                    int alt46=2;
                    int LA46_0 = input.LA(1);

                    if ( (LA46_0==55) ) {
                        alt46=1;
                    }
                    else if ( (LA46_0==56) ) {
                        alt46=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 46, 0, input);

                        throw nvae;
                    }
                    switch (alt46) {
                        case 1 :
                            // InternalGameDsl.g:1944:5: kw= 'E'
                            {
                            kw=(Token)match(input,55,FOLLOW_15); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEDoubleAccess().getEKeyword_4_0_0());
                            				

                            }
                            break;
                        case 2 :
                            // InternalGameDsl.g:1950:5: kw= 'e'
                            {
                            kw=(Token)match(input,56,FOLLOW_15); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEDoubleAccess().getEKeyword_4_0_1());
                            				

                            }
                            break;

                    }

                    // InternalGameDsl.g:1956:4: (kw= '-' )?
                    int alt47=2;
                    int LA47_0 = input.LA(1);

                    if ( (LA47_0==51) ) {
                        alt47=1;
                    }
                    switch (alt47) {
                        case 1 :
                            // InternalGameDsl.g:1957:5: kw= '-'
                            {
                            kw=(Token)match(input,51,FOLLOW_50); 

                            					current.merge(kw);
                            					newLeafNode(kw, grammarAccess.getEDoubleAccess().getHyphenMinusKeyword_4_1());
                            				

                            }
                            break;

                    }

                    this_INT_7=(Token)match(input,RULE_INT,FOLLOW_2); 

                    				current.merge(this_INT_7);
                    			

                    				newLeafNode(this_INT_7, grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_4_2());
                    			

                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEDouble"


    // $ANTLR start "entryRuleEString"
    // InternalGameDsl.g:1975:1: entryRuleEString returns [String current=null] : iv_ruleEString= ruleEString EOF ;
    public final String entryRuleEString() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEString = null;


        try {
            // InternalGameDsl.g:1975:47: (iv_ruleEString= ruleEString EOF )
            // InternalGameDsl.g:1976:2: iv_ruleEString= ruleEString EOF
            {
             newCompositeNode(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEString=ruleEString();

            state._fsp--;

             current =iv_ruleEString.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalGameDsl.g:1982:1: ruleEString returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) ;
    public final AntlrDatatypeRuleToken ruleEString() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_STRING_0=null;
        Token this_ID_1=null;


        	enterRule();

        try {
            // InternalGameDsl.g:1988:2: ( (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID ) )
            // InternalGameDsl.g:1989:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            {
            // InternalGameDsl.g:1989:2: (this_STRING_0= RULE_STRING | this_ID_1= RULE_ID )
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==RULE_STRING) ) {
                alt49=1;
            }
            else if ( (LA49_0==RULE_ID) ) {
                alt49=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 49, 0, input);

                throw nvae;
            }
            switch (alt49) {
                case 1 :
                    // InternalGameDsl.g:1990:3: this_STRING_0= RULE_STRING
                    {
                    this_STRING_0=(Token)match(input,RULE_STRING,FOLLOW_2); 

                    			current.merge(this_STRING_0);
                    		

                    			newLeafNode(this_STRING_0, grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0());
                    		

                    }
                    break;
                case 2 :
                    // InternalGameDsl.g:1998:3: this_ID_1= RULE_ID
                    {
                    this_ID_1=(Token)match(input,RULE_ID,FOLLOW_2); 

                    			current.merge(this_ID_1);
                    		

                    			newLeafNode(this_ID_1, grammarAccess.getEStringAccess().getIDTerminalRuleCall_1());
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEString"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x000000000003A000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000038000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000028000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0008000000000040L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000204000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000001808000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000001008000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0030000000000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x000000001C008000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000018008000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0078000000000060L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000010008000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000040000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000780000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000000700000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0048000000000040L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000000600000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000007000008000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000006000008000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000100000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0000004000008000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x00000F0000008000L});
    public static final BitSet FOLLOW_39 = new BitSet(new long[]{0x00000E0000008000L});
    public static final BitSet FOLLOW_40 = new BitSet(new long[]{0x00000C0000008000L});
    public static final BitSet FOLLOW_41 = new BitSet(new long[]{0x0000080000008000L});
    public static final BitSet FOLLOW_42 = new BitSet(new long[]{0x0000600000000000L});
    public static final BitSet FOLLOW_43 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_44 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_45 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_46 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_47 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_48 = new BitSet(new long[]{0x0004000400008000L});
    public static final BitSet FOLLOW_49 = new BitSet(new long[]{0x0004000000008000L});
    public static final BitSet FOLLOW_50 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_51 = new BitSet(new long[]{0x0040000000000040L});
    public static final BitSet FOLLOW_52 = new BitSet(new long[]{0x0040000000000000L});
    public static final BitSet FOLLOW_53 = new BitSet(new long[]{0x0180000000000002L});

}