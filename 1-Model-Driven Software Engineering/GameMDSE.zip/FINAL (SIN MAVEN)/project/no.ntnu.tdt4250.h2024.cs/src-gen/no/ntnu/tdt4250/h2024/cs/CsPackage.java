/**
 */
package no.ntnu.tdt4250.h2024.cs;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see no.ntnu.tdt4250.h2024.cs.CsFactory
 * @model kind="package"
 * @generated
 */
public interface CsPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "cs";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.ntnu.tdt4250/cs";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "cs";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	CsPackage eINSTANCE = no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl.init();

	/**
	 * The meta object id for the '{@link no.ntnu.tdt4250.h2024.cs.impl.BackgroundImpl <em>Background</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see no.ntnu.tdt4250.h2024.cs.impl.BackgroundImpl
	 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getBackground()
	 * @generated
	 */
	int BACKGROUND = 0;

	/**
	 * The feature id for the '<em><b>Coordinates</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BACKGROUND__COORDINATES = 0;

	/**
	 * The feature id for the '<em><b>Background Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BACKGROUND__BACKGROUND_SPEED = 1;

	/**
	 * The feature id for the '<em><b>Background Moving</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BACKGROUND__BACKGROUND_MOVING = 2;

	/**
	 * The feature id for the '<em><b>Size</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BACKGROUND__SIZE = 3;

	/**
	 * The feature id for the '<em><b>Identifier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BACKGROUND__IDENTIFIER = 4;

	/**
	 * The number of structural features of the '<em>Background</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BACKGROUND_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Background</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BACKGROUND_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link no.ntnu.tdt4250.h2024.cs.impl.CollisionsImpl <em>Collisions</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see no.ntnu.tdt4250.h2024.cs.impl.CollisionsImpl
	 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getCollisions()
	 * @generated
	 */
	int COLLISIONS = 1;

	/**
	 * The feature id for the '<em><b>Hitted Spot</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLISIONS__HITTED_SPOT = 0;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLISIONS__EFFECT = 1;

	/**
	 * The feature id for the '<em><b>Effect Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLISIONS__EFFECT_VALUE = 2;

	/**
	 * The feature id for the '<em><b>Obj ID</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLISIONS__OBJ_ID = 3;

	/**
	 * The number of structural features of the '<em>Collisions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLISIONS_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Collisions</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int COLLISIONS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link no.ntnu.tdt4250.h2024.cs.impl.GameImpl <em>Game</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see no.ntnu.tdt4250.h2024.cs.impl.GameImpl
	 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getGame()
	 * @generated
	 */
	int GAME = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__NAME = 0;

	/**
	 * The feature id for the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__DESCRIPTION = 1;

	/**
	 * The feature id for the '<em><b>Background</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__BACKGROUND = 2;

	/**
	 * The feature id for the '<em><b>Object Type</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__OBJECT_TYPE = 3;

	/**
	 * The feature id for the '<em><b>Collisions</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__COLLISIONS = 4;

	/**
	 * The feature id for the '<em><b>Has Lost</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME__HAS_LOST = 5;

	/**
	 * The number of structural features of the '<em>Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Game</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl <em>Game Object</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl
	 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getGameObject()
	 * @generated
	 */
	int GAME_OBJECT = 3;

	/**
	 * The feature id for the '<em><b>Coordinates</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__COORDINATES = 0;

	/**
	 * The feature id for the '<em><b>Sprite</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__SPRITE = 1;

	/**
	 * The feature id for the '<em><b>Size</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__SIZE = 2;

	/**
	 * The feature id for the '<em><b>Is Taking Damage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__IS_TAKING_DAMAGE = 3;

	/**
	 * The feature id for the '<em><b>Amount Of Damage</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__AMOUNT_OF_DAMAGE = 4;

	/**
	 * The feature id for the '<em><b>Damage Duration</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__DAMAGE_DURATION = 5;

	/**
	 * The feature id for the '<em><b>Velocity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__VELOCITY = 6;

	/**
	 * The feature id for the '<em><b>Direction Degrees</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__DIRECTION_DEGREES = 7;

	/**
	 * The feature id for the '<em><b>Ability</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__ABILITY = 8;

	/**
	 * The feature id for the '<em><b>Identifier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__IDENTIFIER = 9;

	/**
	 * The feature id for the '<em><b>Action</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__ACTION = 10;

	/**
	 * The feature id for the '<em><b>Durability</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT__DURABILITY = 11;

	/**
	 * The number of structural features of the '<em>Game Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT_FEATURE_COUNT = 12;

	/**
	 * The number of operations of the '<em>Game Object</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GAME_OBJECT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link no.ntnu.tdt4250.h2024.cs.impl.AbilityImpl <em>Ability</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see no.ntnu.tdt4250.h2024.cs.impl.AbilityImpl
	 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getAbility()
	 * @generated
	 */
	int ABILITY = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABILITY__NAME = 0;

	/**
	 * The feature id for the '<em><b>Duration</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABILITY__DURATION = 1;

	/**
	 * The feature id for the '<em><b>Is Being Used</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABILITY__IS_BEING_USED = 2;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABILITY__EFFECT = 3;

	/**
	 * The number of structural features of the '<em>Ability</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABILITY_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Ability</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ABILITY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link no.ntnu.tdt4250.h2024.cs.impl.ActionImpl <em>Action</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see no.ntnu.tdt4250.h2024.cs.impl.ActionImpl
	 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getAction()
	 * @generated
	 */
	int ACTION = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION__NAME = 0;

	/**
	 * The feature id for the '<em><b>Effect</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION__EFFECT = 1;

	/**
	 * The number of structural features of the '<em>Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Action</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ACTION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link no.ntnu.tdt4250.h2024.cs.impl.EffectImpl <em>Effect</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see no.ntnu.tdt4250.h2024.cs.impl.EffectImpl
	 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getEffect()
	 * @generated
	 */
	int EFFECT = 6;

	/**
	 * The feature id for the '<em><b>Identifier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT__IDENTIFIER = 0;

	/**
	 * The feature id for the '<em><b>Velocity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT__VELOCITY = 1;

	/**
	 * The feature id for the '<em><b>Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT__RANGE = 2;

	/**
	 * The number of structural features of the '<em>Effect</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Effect</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFECT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link no.ntnu.tdt4250.h2024.cs.impl.ObjectTypeImpl <em>Object Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see no.ntnu.tdt4250.h2024.cs.impl.ObjectTypeImpl
	 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getObjectType()
	 * @generated
	 */
	int OBJECT_TYPE = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_TYPE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Interaction</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_TYPE__INTERACTION = 1;

	/**
	 * The feature id for the '<em><b>Characteristic</b></em>' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_TYPE__CHARACTERISTIC = 2;

	/**
	 * The feature id for the '<em><b>Gameobject</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_TYPE__GAMEOBJECT = 3;

	/**
	 * The number of structural features of the '<em>Object Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_TYPE_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Object Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OBJECT_TYPE_OPERATION_COUNT = 0;

	/**
	 * Returns the meta object for class '{@link no.ntnu.tdt4250.h2024.cs.Background <em>Background</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Background</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Background
	 * @generated
	 */
	EClass getBackground();

	/**
	 * Returns the meta object for the attribute list '{@link no.ntnu.tdt4250.h2024.cs.Background#getCoordinates <em>Coordinates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Coordinates</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Background#getCoordinates()
	 * @see #getBackground()
	 * @generated
	 */
	EAttribute getBackground_Coordinates();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Background#getBackgroundSpeed <em>Background Speed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Background Speed</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Background#getBackgroundSpeed()
	 * @see #getBackground()
	 * @generated
	 */
	EAttribute getBackground_BackgroundSpeed();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Background#isBackgroundMoving <em>Background Moving</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Background Moving</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Background#isBackgroundMoving()
	 * @see #getBackground()
	 * @generated
	 */
	EAttribute getBackground_BackgroundMoving();

	/**
	 * Returns the meta object for the attribute list '{@link no.ntnu.tdt4250.h2024.cs.Background#getSize <em>Size</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Size</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Background#getSize()
	 * @see #getBackground()
	 * @generated
	 */
	EAttribute getBackground_Size();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Background#getIdentifier <em>Identifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Identifier</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Background#getIdentifier()
	 * @see #getBackground()
	 * @generated
	 */
	EAttribute getBackground_Identifier();

	/**
	 * Returns the meta object for class '{@link no.ntnu.tdt4250.h2024.cs.Collisions <em>Collisions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Collisions</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Collisions
	 * @generated
	 */
	EClass getCollisions();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Collisions#getHittedSpot <em>Hitted Spot</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Hitted Spot</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Collisions#getHittedSpot()
	 * @see #getCollisions()
	 * @generated
	 */
	EAttribute getCollisions_HittedSpot();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Collisions#getEffect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Effect</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Collisions#getEffect()
	 * @see #getCollisions()
	 * @generated
	 */
	EAttribute getCollisions_Effect();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Collisions#getEffectValue <em>Effect Value</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Effect Value</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Collisions#getEffectValue()
	 * @see #getCollisions()
	 * @generated
	 */
	EAttribute getCollisions_EffectValue();

	/**
	 * Returns the meta object for the attribute list '{@link no.ntnu.tdt4250.h2024.cs.Collisions#getObjID <em>Obj ID</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Obj ID</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Collisions#getObjID()
	 * @see #getCollisions()
	 * @generated
	 */
	EAttribute getCollisions_ObjID();

	/**
	 * Returns the meta object for class '{@link no.ntnu.tdt4250.h2024.cs.Game <em>Game</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Game</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Game
	 * @generated
	 */
	EClass getGame();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Game#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Game#getName()
	 * @see #getGame()
	 * @generated
	 */
	EAttribute getGame_Name();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Game#getDescription <em>Description</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Description</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Game#getDescription()
	 * @see #getGame()
	 * @generated
	 */
	EAttribute getGame_Description();

	/**
	 * Returns the meta object for the containment reference list '{@link no.ntnu.tdt4250.h2024.cs.Game#getBackground <em>Background</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Background</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Game#getBackground()
	 * @see #getGame()
	 * @generated
	 */
	EReference getGame_Background();

	/**
	 * Returns the meta object for the containment reference list '{@link no.ntnu.tdt4250.h2024.cs.Game#getObjectType <em>Object Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Object Type</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Game#getObjectType()
	 * @see #getGame()
	 * @generated
	 */
	EReference getGame_ObjectType();

	/**
	 * Returns the meta object for the containment reference list '{@link no.ntnu.tdt4250.h2024.cs.Game#getCollisions <em>Collisions</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Collisions</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Game#getCollisions()
	 * @see #getGame()
	 * @generated
	 */
	EReference getGame_Collisions();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Game#isHasLost <em>Has Lost</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Has Lost</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Game#isHasLost()
	 * @see #getGame()
	 * @generated
	 */
	EAttribute getGame_HasLost();

	/**
	 * Returns the meta object for class '{@link no.ntnu.tdt4250.h2024.cs.GameObject <em>Game Object</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Game Object</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject
	 * @generated
	 */
	EClass getGameObject();

	/**
	 * Returns the meta object for the attribute list '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getCoordinates <em>Coordinates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Coordinates</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#getCoordinates()
	 * @see #getGameObject()
	 * @generated
	 */
	EAttribute getGameObject_Coordinates();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getSprite <em>Sprite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sprite</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#getSprite()
	 * @see #getGameObject()
	 * @generated
	 */
	EAttribute getGameObject_Sprite();

	/**
	 * Returns the meta object for the attribute list '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getSize <em>Size</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Size</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#getSize()
	 * @see #getGameObject()
	 * @generated
	 */
	EAttribute getGameObject_Size();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.GameObject#isIsTakingDamage <em>Is Taking Damage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Taking Damage</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#isIsTakingDamage()
	 * @see #getGameObject()
	 * @generated
	 */
	EAttribute getGameObject_IsTakingDamage();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getAmountOfDamage <em>Amount Of Damage</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Amount Of Damage</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#getAmountOfDamage()
	 * @see #getGameObject()
	 * @generated
	 */
	EAttribute getGameObject_AmountOfDamage();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getDamageDuration <em>Damage Duration</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Damage Duration</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#getDamageDuration()
	 * @see #getGameObject()
	 * @generated
	 */
	EAttribute getGameObject_DamageDuration();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getVelocity <em>Velocity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Velocity</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#getVelocity()
	 * @see #getGameObject()
	 * @generated
	 */
	EAttribute getGameObject_Velocity();

	/**
	 * Returns the meta object for the attribute list '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getDirectionDegrees <em>Direction Degrees</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Direction Degrees</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#getDirectionDegrees()
	 * @see #getGameObject()
	 * @generated
	 */
	EAttribute getGameObject_DirectionDegrees();

	/**
	 * Returns the meta object for the containment reference list '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getAbility <em>Ability</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Ability</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#getAbility()
	 * @see #getGameObject()
	 * @generated
	 */
	EReference getGameObject_Ability();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getIdentifier <em>Identifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Identifier</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#getIdentifier()
	 * @see #getGameObject()
	 * @generated
	 */
	EAttribute getGameObject_Identifier();

	/**
	 * Returns the meta object for the containment reference list '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getAction <em>Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Action</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#getAction()
	 * @see #getGameObject()
	 * @generated
	 */
	EReference getGameObject_Action();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getDurability <em>Durability</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Durability</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.GameObject#getDurability()
	 * @see #getGameObject()
	 * @generated
	 */
	EAttribute getGameObject_Durability();

	/**
	 * Returns the meta object for class '{@link no.ntnu.tdt4250.h2024.cs.Ability <em>Ability</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Ability</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Ability
	 * @generated
	 */
	EClass getAbility();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Ability#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Ability#getName()
	 * @see #getAbility()
	 * @generated
	 */
	EAttribute getAbility_Name();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Ability#getDuration <em>Duration</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Duration</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Ability#getDuration()
	 * @see #getAbility()
	 * @generated
	 */
	EAttribute getAbility_Duration();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Ability#isIsBeingUsed <em>Is Being Used</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Is Being Used</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Ability#isIsBeingUsed()
	 * @see #getAbility()
	 * @generated
	 */
	EAttribute getAbility_IsBeingUsed();

	/**
	 * Returns the meta object for the containment reference list '{@link no.ntnu.tdt4250.h2024.cs.Ability#getEffect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Effect</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Ability#getEffect()
	 * @see #getAbility()
	 * @generated
	 */
	EReference getAbility_Effect();

	/**
	 * Returns the meta object for class '{@link no.ntnu.tdt4250.h2024.cs.Action <em>Action</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Action</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Action
	 * @generated
	 */
	EClass getAction();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Action#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Action#getName()
	 * @see #getAction()
	 * @generated
	 */
	EAttribute getAction_Name();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Action#getEffect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Effect</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Action#getEffect()
	 * @see #getAction()
	 * @generated
	 */
	EAttribute getAction_Effect();

	/**
	 * Returns the meta object for class '{@link no.ntnu.tdt4250.h2024.cs.Effect <em>Effect</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Effect</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Effect
	 * @generated
	 */
	EClass getEffect();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Effect#getIdentifier <em>Identifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Identifier</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Effect#getIdentifier()
	 * @see #getEffect()
	 * @generated
	 */
	EAttribute getEffect_Identifier();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Effect#getVelocity <em>Velocity</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Velocity</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Effect#getVelocity()
	 * @see #getEffect()
	 * @generated
	 */
	EAttribute getEffect_Velocity();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.Effect#getRange <em>Range</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Range</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.Effect#getRange()
	 * @see #getEffect()
	 * @generated
	 */
	EAttribute getEffect_Range();

	/**
	 * Returns the meta object for class '{@link no.ntnu.tdt4250.h2024.cs.ObjectType <em>Object Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Object Type</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.ObjectType
	 * @generated
	 */
	EClass getObjectType();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.ObjectType#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.ObjectType#getName()
	 * @see #getObjectType()
	 * @generated
	 */
	EAttribute getObjectType_Name();

	/**
	 * Returns the meta object for the attribute '{@link no.ntnu.tdt4250.h2024.cs.ObjectType#getInteraction <em>Interaction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Interaction</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.ObjectType#getInteraction()
	 * @see #getObjectType()
	 * @generated
	 */
	EAttribute getObjectType_Interaction();

	/**
	 * Returns the meta object for the attribute list '{@link no.ntnu.tdt4250.h2024.cs.ObjectType#getCharacteristic <em>Characteristic</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute list '<em>Characteristic</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.ObjectType#getCharacteristic()
	 * @see #getObjectType()
	 * @generated
	 */
	EAttribute getObjectType_Characteristic();

	/**
	 * Returns the meta object for the containment reference list '{@link no.ntnu.tdt4250.h2024.cs.ObjectType#getGameobject <em>Gameobject</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Gameobject</em>'.
	 * @see no.ntnu.tdt4250.h2024.cs.ObjectType#getGameobject()
	 * @see #getObjectType()
	 * @generated
	 */
	EReference getObjectType_Gameobject();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	CsFactory getCsFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link no.ntnu.tdt4250.h2024.cs.impl.BackgroundImpl <em>Background</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see no.ntnu.tdt4250.h2024.cs.impl.BackgroundImpl
		 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getBackground()
		 * @generated
		 */
		EClass BACKGROUND = eINSTANCE.getBackground();

		/**
		 * The meta object literal for the '<em><b>Coordinates</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BACKGROUND__COORDINATES = eINSTANCE.getBackground_Coordinates();

		/**
		 * The meta object literal for the '<em><b>Background Speed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BACKGROUND__BACKGROUND_SPEED = eINSTANCE.getBackground_BackgroundSpeed();

		/**
		 * The meta object literal for the '<em><b>Background Moving</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BACKGROUND__BACKGROUND_MOVING = eINSTANCE.getBackground_BackgroundMoving();

		/**
		 * The meta object literal for the '<em><b>Size</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BACKGROUND__SIZE = eINSTANCE.getBackground_Size();

		/**
		 * The meta object literal for the '<em><b>Identifier</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BACKGROUND__IDENTIFIER = eINSTANCE.getBackground_Identifier();

		/**
		 * The meta object literal for the '{@link no.ntnu.tdt4250.h2024.cs.impl.CollisionsImpl <em>Collisions</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see no.ntnu.tdt4250.h2024.cs.impl.CollisionsImpl
		 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getCollisions()
		 * @generated
		 */
		EClass COLLISIONS = eINSTANCE.getCollisions();

		/**
		 * The meta object literal for the '<em><b>Hitted Spot</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLISIONS__HITTED_SPOT = eINSTANCE.getCollisions_HittedSpot();

		/**
		 * The meta object literal for the '<em><b>Effect</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLISIONS__EFFECT = eINSTANCE.getCollisions_Effect();

		/**
		 * The meta object literal for the '<em><b>Effect Value</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLISIONS__EFFECT_VALUE = eINSTANCE.getCollisions_EffectValue();

		/**
		 * The meta object literal for the '<em><b>Obj ID</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute COLLISIONS__OBJ_ID = eINSTANCE.getCollisions_ObjID();

		/**
		 * The meta object literal for the '{@link no.ntnu.tdt4250.h2024.cs.impl.GameImpl <em>Game</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see no.ntnu.tdt4250.h2024.cs.impl.GameImpl
		 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getGame()
		 * @generated
		 */
		EClass GAME = eINSTANCE.getGame();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME__NAME = eINSTANCE.getGame_Name();

		/**
		 * The meta object literal for the '<em><b>Description</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME__DESCRIPTION = eINSTANCE.getGame_Description();

		/**
		 * The meta object literal for the '<em><b>Background</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GAME__BACKGROUND = eINSTANCE.getGame_Background();

		/**
		 * The meta object literal for the '<em><b>Object Type</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GAME__OBJECT_TYPE = eINSTANCE.getGame_ObjectType();

		/**
		 * The meta object literal for the '<em><b>Collisions</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GAME__COLLISIONS = eINSTANCE.getGame_Collisions();

		/**
		 * The meta object literal for the '<em><b>Has Lost</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME__HAS_LOST = eINSTANCE.getGame_HasLost();

		/**
		 * The meta object literal for the '{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl <em>Game Object</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl
		 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getGameObject()
		 * @generated
		 */
		EClass GAME_OBJECT = eINSTANCE.getGameObject();

		/**
		 * The meta object literal for the '<em><b>Coordinates</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_OBJECT__COORDINATES = eINSTANCE.getGameObject_Coordinates();

		/**
		 * The meta object literal for the '<em><b>Sprite</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_OBJECT__SPRITE = eINSTANCE.getGameObject_Sprite();

		/**
		 * The meta object literal for the '<em><b>Size</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_OBJECT__SIZE = eINSTANCE.getGameObject_Size();

		/**
		 * The meta object literal for the '<em><b>Is Taking Damage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_OBJECT__IS_TAKING_DAMAGE = eINSTANCE.getGameObject_IsTakingDamage();

		/**
		 * The meta object literal for the '<em><b>Amount Of Damage</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_OBJECT__AMOUNT_OF_DAMAGE = eINSTANCE.getGameObject_AmountOfDamage();

		/**
		 * The meta object literal for the '<em><b>Damage Duration</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_OBJECT__DAMAGE_DURATION = eINSTANCE.getGameObject_DamageDuration();

		/**
		 * The meta object literal for the '<em><b>Velocity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_OBJECT__VELOCITY = eINSTANCE.getGameObject_Velocity();

		/**
		 * The meta object literal for the '<em><b>Direction Degrees</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_OBJECT__DIRECTION_DEGREES = eINSTANCE.getGameObject_DirectionDegrees();

		/**
		 * The meta object literal for the '<em><b>Ability</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GAME_OBJECT__ABILITY = eINSTANCE.getGameObject_Ability();

		/**
		 * The meta object literal for the '<em><b>Identifier</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_OBJECT__IDENTIFIER = eINSTANCE.getGameObject_Identifier();

		/**
		 * The meta object literal for the '<em><b>Action</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GAME_OBJECT__ACTION = eINSTANCE.getGameObject_Action();

		/**
		 * The meta object literal for the '<em><b>Durability</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GAME_OBJECT__DURABILITY = eINSTANCE.getGameObject_Durability();

		/**
		 * The meta object literal for the '{@link no.ntnu.tdt4250.h2024.cs.impl.AbilityImpl <em>Ability</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see no.ntnu.tdt4250.h2024.cs.impl.AbilityImpl
		 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getAbility()
		 * @generated
		 */
		EClass ABILITY = eINSTANCE.getAbility();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABILITY__NAME = eINSTANCE.getAbility_Name();

		/**
		 * The meta object literal for the '<em><b>Duration</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABILITY__DURATION = eINSTANCE.getAbility_Duration();

		/**
		 * The meta object literal for the '<em><b>Is Being Used</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ABILITY__IS_BEING_USED = eINSTANCE.getAbility_IsBeingUsed();

		/**
		 * The meta object literal for the '<em><b>Effect</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ABILITY__EFFECT = eINSTANCE.getAbility_Effect();

		/**
		 * The meta object literal for the '{@link no.ntnu.tdt4250.h2024.cs.impl.ActionImpl <em>Action</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see no.ntnu.tdt4250.h2024.cs.impl.ActionImpl
		 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getAction()
		 * @generated
		 */
		EClass ACTION = eINSTANCE.getAction();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTION__NAME = eINSTANCE.getAction_Name();

		/**
		 * The meta object literal for the '<em><b>Effect</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ACTION__EFFECT = eINSTANCE.getAction_Effect();

		/**
		 * The meta object literal for the '{@link no.ntnu.tdt4250.h2024.cs.impl.EffectImpl <em>Effect</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see no.ntnu.tdt4250.h2024.cs.impl.EffectImpl
		 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getEffect()
		 * @generated
		 */
		EClass EFFECT = eINSTANCE.getEffect();

		/**
		 * The meta object literal for the '<em><b>Identifier</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EFFECT__IDENTIFIER = eINSTANCE.getEffect_Identifier();

		/**
		 * The meta object literal for the '<em><b>Velocity</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EFFECT__VELOCITY = eINSTANCE.getEffect_Velocity();

		/**
		 * The meta object literal for the '<em><b>Range</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute EFFECT__RANGE = eINSTANCE.getEffect_Range();

		/**
		 * The meta object literal for the '{@link no.ntnu.tdt4250.h2024.cs.impl.ObjectTypeImpl <em>Object Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see no.ntnu.tdt4250.h2024.cs.impl.ObjectTypeImpl
		 * @see no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl#getObjectType()
		 * @generated
		 */
		EClass OBJECT_TYPE = eINSTANCE.getObjectType();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_TYPE__NAME = eINSTANCE.getObjectType_Name();

		/**
		 * The meta object literal for the '<em><b>Interaction</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_TYPE__INTERACTION = eINSTANCE.getObjectType_Interaction();

		/**
		 * The meta object literal for the '<em><b>Characteristic</b></em>' attribute list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OBJECT_TYPE__CHARACTERISTIC = eINSTANCE.getObjectType_Characteristic();

		/**
		 * The meta object literal for the '<em><b>Gameobject</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference OBJECT_TYPE__GAMEOBJECT = eINSTANCE.getObjectType_Gameobject();

	}

} //CsPackage
