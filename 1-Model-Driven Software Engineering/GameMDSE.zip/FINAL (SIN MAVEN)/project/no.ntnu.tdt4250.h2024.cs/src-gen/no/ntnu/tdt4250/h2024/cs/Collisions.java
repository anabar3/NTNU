/**
 */
package no.ntnu.tdt4250.h2024.cs;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Collisions</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Collisions#getHittedSpot <em>Hitted Spot</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Collisions#getEffect <em>Effect</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Collisions#getEffectValue <em>Effect Value</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Collisions#getObjID <em>Obj ID</em>}</li>
 * </ul>
 *
 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getCollisions()
 * @model
 * @generated
 */
public interface Collisions extends EObject {
	/**
	 * Returns the value of the '<em><b>Hitted Spot</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Hitted Spot</em>' attribute.
	 * @see #setHittedSpot(String)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getCollisions_HittedSpot()
	 * @model
	 * @generated
	 */
	String getHittedSpot();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Collisions#getHittedSpot <em>Hitted Spot</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Hitted Spot</em>' attribute.
	 * @see #getHittedSpot()
	 * @generated
	 */
	void setHittedSpot(String value);

	/**
	 * Returns the value of the '<em><b>Effect</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Effect</em>' attribute.
	 * @see #setEffect(String)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getCollisions_Effect()
	 * @model
	 * @generated
	 */
	String getEffect();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Collisions#getEffect <em>Effect</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Effect</em>' attribute.
	 * @see #getEffect()
	 * @generated
	 */
	void setEffect(String value);

	/**
	 * Returns the value of the '<em><b>Effect Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Effect Value</em>' attribute.
	 * @see #setEffectValue(float)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getCollisions_EffectValue()
	 * @model
	 * @generated
	 */
	float getEffectValue();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Collisions#getEffectValue <em>Effect Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Effect Value</em>' attribute.
	 * @see #getEffectValue()
	 * @generated
	 */
	void setEffectValue(float value);

	/**
	 * Returns the value of the '<em><b>Obj ID</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.String}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Obj ID</em>' attribute list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getCollisions_ObjID()
	 * @model default="" lower="2" upper="10"
	 * @generated
	 */
	EList<String> getObjID();

} // Collisions
