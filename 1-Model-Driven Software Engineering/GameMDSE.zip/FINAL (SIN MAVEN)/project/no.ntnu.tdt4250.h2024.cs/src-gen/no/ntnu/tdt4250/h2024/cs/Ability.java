/**
 */
package no.ntnu.tdt4250.h2024.cs;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Ability</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Ability#getName <em>Name</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Ability#getDuration <em>Duration</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Ability#isIsBeingUsed <em>Is Being Used</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Ability#getEffect <em>Effect</em>}</li>
 * </ul>
 *
 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getAbility()
 * @model
 * @generated
 */
public interface Ability extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getAbility_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Ability#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Duration</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Duration</em>' attribute.
	 * @see #setDuration(int)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getAbility_Duration()
	 * @model
	 * @generated
	 */
	int getDuration();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Ability#getDuration <em>Duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Duration</em>' attribute.
	 * @see #getDuration()
	 * @generated
	 */
	void setDuration(int value);

	/**
	 * Returns the value of the '<em><b>Is Being Used</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Being Used</em>' attribute.
	 * @see #setIsBeingUsed(boolean)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getAbility_IsBeingUsed()
	 * @model required="true"
	 * @generated
	 */
	boolean isIsBeingUsed();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Ability#isIsBeingUsed <em>Is Being Used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Being Used</em>' attribute.
	 * @see #isIsBeingUsed()
	 * @generated
	 */
	void setIsBeingUsed(boolean value);

	/**
	 * Returns the value of the '<em><b>Effect</b></em>' containment reference list.
	 * The list contents are of type {@link no.ntnu.tdt4250.h2024.cs.Effect}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Effect</em>' containment reference list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getAbility_Effect()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Effect> getEffect();

} // Ability
