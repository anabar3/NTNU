/**
 */
package no.ntnu.tdt4250.h2024.cs;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Game Object</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#getCoordinates <em>Coordinates</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#getSprite <em>Sprite</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#getSize <em>Size</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#isIsTakingDamage <em>Is Taking Damage</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#getAmountOfDamage <em>Amount Of Damage</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#getDamageDuration <em>Damage Duration</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#getVelocity <em>Velocity</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#getDirectionDegrees <em>Direction Degrees</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#getAbility <em>Ability</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#getIdentifier <em>Identifier</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#getAction <em>Action</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.GameObject#getDurability <em>Durability</em>}</li>
 * </ul>
 *
 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject()
 * @model
 * @generated
 */
public interface GameObject extends EObject {
	/**
	 * Returns the value of the '<em><b>Coordinates</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Coordinates</em>' attribute list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_Coordinates()
	 * @model default="0" unique="false" lower="3" upper="3" transient="true"
	 * @generated
	 */
	EList<Integer> getCoordinates();

	/**
	 * Returns the value of the '<em><b>Sprite</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sprite</em>' attribute.
	 * @see #setSprite(String)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_Sprite()
	 * @model unique="false" required="true" transient="true"
	 * @generated
	 */
	String getSprite();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getSprite <em>Sprite</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Sprite</em>' attribute.
	 * @see #getSprite()
	 * @generated
	 */
	void setSprite(String value);

	/**
	 * Returns the value of the '<em><b>Size</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Size</em>' attribute list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_Size()
	 * @model unique="false" lower="3" upper="3" transient="true"
	 * @generated
	 */
	EList<Integer> getSize();

	/**
	 * Returns the value of the '<em><b>Is Taking Damage</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Is Taking Damage</em>' attribute.
	 * @see #setIsTakingDamage(boolean)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_IsTakingDamage()
	 * @model default="false"
	 * @generated
	 */
	boolean isIsTakingDamage();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.GameObject#isIsTakingDamage <em>Is Taking Damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Is Taking Damage</em>' attribute.
	 * @see #isIsTakingDamage()
	 * @generated
	 */
	void setIsTakingDamage(boolean value);

	/**
	 * Returns the value of the '<em><b>Amount Of Damage</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Amount Of Damage</em>' attribute.
	 * @see #setAmountOfDamage(float)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_AmountOfDamage()
	 * @model default="0.0"
	 * @generated
	 */
	float getAmountOfDamage();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getAmountOfDamage <em>Amount Of Damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Amount Of Damage</em>' attribute.
	 * @see #getAmountOfDamage()
	 * @generated
	 */
	void setAmountOfDamage(float value);

	/**
	 * Returns the value of the '<em><b>Damage Duration</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Damage Duration</em>' attribute.
	 * @see #setDamageDuration(int)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_DamageDuration()
	 * @model default="0"
	 * @generated
	 */
	int getDamageDuration();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getDamageDuration <em>Damage Duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Damage Duration</em>' attribute.
	 * @see #getDamageDuration()
	 * @generated
	 */
	void setDamageDuration(int value);

	/**
	 * Returns the value of the '<em><b>Velocity</b></em>' attribute.
	 * The default value is <code>"0.0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Velocity</em>' attribute.
	 * @see #setVelocity(float)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_Velocity()
	 * @model default="0.0" required="true"
	 * @generated
	 */
	float getVelocity();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getVelocity <em>Velocity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Velocity</em>' attribute.
	 * @see #getVelocity()
	 * @generated
	 */
	void setVelocity(float value);

	/**
	 * Returns the value of the '<em><b>Direction Degrees</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Double}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Direction Degrees</em>' attribute list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_DirectionDegrees()
	 * @model default="0" lower="3" upper="3"
	 * @generated
	 */
	EList<Double> getDirectionDegrees();

	/**
	 * Returns the value of the '<em><b>Ability</b></em>' containment reference list.
	 * The list contents are of type {@link no.ntnu.tdt4250.h2024.cs.Ability}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ability</em>' containment reference list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_Ability()
	 * @model containment="true"
	 * @generated
	 */
	EList<Ability> getAbility();

	/**
	 * Returns the value of the '<em><b>Identifier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Identifier</em>' attribute.
	 * @see #setIdentifier(String)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_Identifier()
	 * @model
	 * @generated
	 */
	String getIdentifier();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getIdentifier <em>Identifier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Identifier</em>' attribute.
	 * @see #getIdentifier()
	 * @generated
	 */
	void setIdentifier(String value);

	/**
	 * Returns the value of the '<em><b>Action</b></em>' containment reference list.
	 * The list contents are of type {@link no.ntnu.tdt4250.h2024.cs.Action}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Action</em>' containment reference list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_Action()
	 * @model containment="true"
	 * @generated
	 */
	EList<Action> getAction();

	/**
	 * Returns the value of the '<em><b>Durability</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Durability</em>' attribute.
	 * @see #setDurability(int)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGameObject_Durability()
	 * @model
	 * @generated
	 */
	int getDurability();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.GameObject#getDurability <em>Durability</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Durability</em>' attribute.
	 * @see #getDurability()
	 * @generated
	 */
	void setDurability(int value);

} // GameObject
