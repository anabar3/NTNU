/**
 */
package no.ntnu.tdt4250.h2024.cs;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Background</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Background#getCoordinates <em>Coordinates</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Background#getBackgroundSpeed <em>Background Speed</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Background#isBackgroundMoving <em>Background Moving</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Background#getSize <em>Size</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Background#getIdentifier <em>Identifier</em>}</li>
 * </ul>
 *
 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getBackground()
 * @model
 * @generated
 */
public interface Background extends EObject {
	/**
	 * Returns the value of the '<em><b>Coordinates</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Coordinates</em>' attribute list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getBackground_Coordinates()
	 * @model default="0" unique="false" lower="3" upper="3"
	 * @generated
	 */
	EList<Integer> getCoordinates();

	/**
	 * Returns the value of the '<em><b>Background Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Background Speed</em>' attribute.
	 * @see #setBackgroundSpeed(int)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getBackground_BackgroundSpeed()
	 * @model
	 * @generated
	 */
	int getBackgroundSpeed();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Background#getBackgroundSpeed <em>Background Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Background Speed</em>' attribute.
	 * @see #getBackgroundSpeed()
	 * @generated
	 */
	void setBackgroundSpeed(int value);

	/**
	 * Returns the value of the '<em><b>Background Moving</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Background Moving</em>' attribute.
	 * @see #setBackgroundMoving(boolean)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getBackground_BackgroundMoving()
	 * @model default="false"
	 * @generated
	 */
	boolean isBackgroundMoving();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Background#isBackgroundMoving <em>Background Moving</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Background Moving</em>' attribute.
	 * @see #isBackgroundMoving()
	 * @generated
	 */
	void setBackgroundMoving(boolean value);

	/**
	 * Returns the value of the '<em><b>Size</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Integer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Size</em>' attribute list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getBackground_Size()
	 * @model unique="false" lower="2" upper="2"
	 * @generated
	 */
	EList<Integer> getSize();

	/**
	 * Returns the value of the '<em><b>Identifier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Identifier</em>' attribute.
	 * @see #setIdentifier(String)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getBackground_Identifier()
	 * @model required="true"
	 * @generated
	 */
	String getIdentifier();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Background#getIdentifier <em>Identifier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Identifier</em>' attribute.
	 * @see #getIdentifier()
	 * @generated
	 */
	void setIdentifier(String value);

} // Background
