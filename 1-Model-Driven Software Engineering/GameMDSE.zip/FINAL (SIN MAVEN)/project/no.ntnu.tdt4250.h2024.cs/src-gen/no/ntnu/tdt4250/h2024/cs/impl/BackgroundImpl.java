/**
 */
package no.ntnu.tdt4250.h2024.cs.impl;

import java.util.Collection;

import no.ntnu.tdt4250.h2024.cs.Background;
import no.ntnu.tdt4250.h2024.cs.CsPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Background</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.BackgroundImpl#getCoordinates <em>Coordinates</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.BackgroundImpl#getBackgroundSpeed <em>Background Speed</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.BackgroundImpl#isBackgroundMoving <em>Background Moving</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.BackgroundImpl#getSize <em>Size</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.BackgroundImpl#getIdentifier <em>Identifier</em>}</li>
 * </ul>
 *
 * @generated
 */
public class BackgroundImpl extends MinimalEObjectImpl.Container implements Background {
	/**
	 * The cached value of the '{@link #getCoordinates() <em>Coordinates</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCoordinates()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> coordinates;

	/**
	 * The default value of the '{@link #getBackgroundSpeed() <em>Background Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBackgroundSpeed()
	 * @generated
	 * @ordered
	 */
	protected static final int BACKGROUND_SPEED_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getBackgroundSpeed() <em>Background Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBackgroundSpeed()
	 * @generated
	 * @ordered
	 */
	protected int backgroundSpeed = BACKGROUND_SPEED_EDEFAULT;

	/**
	 * The default value of the '{@link #isBackgroundMoving() <em>Background Moving</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBackgroundMoving()
	 * @generated
	 * @ordered
	 */
	protected static final boolean BACKGROUND_MOVING_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isBackgroundMoving() <em>Background Moving</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBackgroundMoving()
	 * @generated
	 * @ordered
	 */
	protected boolean backgroundMoving = BACKGROUND_MOVING_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSize() <em>Size</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSize()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> size;

	/**
	 * The default value of the '{@link #getIdentifier() <em>Identifier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdentifier()
	 * @generated
	 * @ordered
	 */
	protected static final String IDENTIFIER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIdentifier() <em>Identifier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdentifier()
	 * @generated
	 * @ordered
	 */
	protected String identifier = IDENTIFIER_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BackgroundImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CsPackage.Literals.BACKGROUND;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getCoordinates() {
		if (coordinates == null) {
			coordinates = new EDataTypeEList<Integer>(Integer.class, this, CsPackage.BACKGROUND__COORDINATES);
		}
		return coordinates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getBackgroundSpeed() {
		return backgroundSpeed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBackgroundSpeed(int newBackgroundSpeed) {
		int oldBackgroundSpeed = backgroundSpeed;
		backgroundSpeed = newBackgroundSpeed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.BACKGROUND__BACKGROUND_SPEED,
					oldBackgroundSpeed, backgroundSpeed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isBackgroundMoving() {
		return backgroundMoving;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBackgroundMoving(boolean newBackgroundMoving) {
		boolean oldBackgroundMoving = backgroundMoving;
		backgroundMoving = newBackgroundMoving;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.BACKGROUND__BACKGROUND_MOVING,
					oldBackgroundMoving, backgroundMoving));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getSize() {
		if (size == null) {
			size = new EDataTypeEList<Integer>(Integer.class, this, CsPackage.BACKGROUND__SIZE);
		}
		return size;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIdentifier() {
		return identifier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIdentifier(String newIdentifier) {
		String oldIdentifier = identifier;
		identifier = newIdentifier;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.BACKGROUND__IDENTIFIER, oldIdentifier,
					identifier));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CsPackage.BACKGROUND__COORDINATES:
			return getCoordinates();
		case CsPackage.BACKGROUND__BACKGROUND_SPEED:
			return getBackgroundSpeed();
		case CsPackage.BACKGROUND__BACKGROUND_MOVING:
			return isBackgroundMoving();
		case CsPackage.BACKGROUND__SIZE:
			return getSize();
		case CsPackage.BACKGROUND__IDENTIFIER:
			return getIdentifier();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CsPackage.BACKGROUND__COORDINATES:
			getCoordinates().clear();
			getCoordinates().addAll((Collection<? extends Integer>) newValue);
			return;
		case CsPackage.BACKGROUND__BACKGROUND_SPEED:
			setBackgroundSpeed((Integer) newValue);
			return;
		case CsPackage.BACKGROUND__BACKGROUND_MOVING:
			setBackgroundMoving((Boolean) newValue);
			return;
		case CsPackage.BACKGROUND__SIZE:
			getSize().clear();
			getSize().addAll((Collection<? extends Integer>) newValue);
			return;
		case CsPackage.BACKGROUND__IDENTIFIER:
			setIdentifier((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CsPackage.BACKGROUND__COORDINATES:
			getCoordinates().clear();
			return;
		case CsPackage.BACKGROUND__BACKGROUND_SPEED:
			setBackgroundSpeed(BACKGROUND_SPEED_EDEFAULT);
			return;
		case CsPackage.BACKGROUND__BACKGROUND_MOVING:
			setBackgroundMoving(BACKGROUND_MOVING_EDEFAULT);
			return;
		case CsPackage.BACKGROUND__SIZE:
			getSize().clear();
			return;
		case CsPackage.BACKGROUND__IDENTIFIER:
			setIdentifier(IDENTIFIER_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CsPackage.BACKGROUND__COORDINATES:
			return coordinates != null && !coordinates.isEmpty();
		case CsPackage.BACKGROUND__BACKGROUND_SPEED:
			return backgroundSpeed != BACKGROUND_SPEED_EDEFAULT;
		case CsPackage.BACKGROUND__BACKGROUND_MOVING:
			return backgroundMoving != BACKGROUND_MOVING_EDEFAULT;
		case CsPackage.BACKGROUND__SIZE:
			return size != null && !size.isEmpty();
		case CsPackage.BACKGROUND__IDENTIFIER:
			return IDENTIFIER_EDEFAULT == null ? identifier != null : !IDENTIFIER_EDEFAULT.equals(identifier);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (coordinates: ");
		result.append(coordinates);
		result.append(", backgroundSpeed: ");
		result.append(backgroundSpeed);
		result.append(", backgroundMoving: ");
		result.append(backgroundMoving);
		result.append(", size: ");
		result.append(size);
		result.append(", identifier: ");
		result.append(identifier);
		result.append(')');
		return result.toString();
	}

} //BackgroundImpl
