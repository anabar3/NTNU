/**
 */
package no.ntnu.tdt4250.h2024.cs.impl;

import java.util.Collection;

import no.ntnu.tdt4250.h2024.cs.Collisions;
import no.ntnu.tdt4250.h2024.cs.CsPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Collisions</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.CollisionsImpl#getHittedSpot <em>Hitted Spot</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.CollisionsImpl#getEffect <em>Effect</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.CollisionsImpl#getEffectValue <em>Effect Value</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.CollisionsImpl#getObjID <em>Obj ID</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CollisionsImpl extends MinimalEObjectImpl.Container implements Collisions {
	/**
	 * The default value of the '{@link #getHittedSpot() <em>Hitted Spot</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHittedSpot()
	 * @generated
	 * @ordered
	 */
	protected static final String HITTED_SPOT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHittedSpot() <em>Hitted Spot</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHittedSpot()
	 * @generated
	 * @ordered
	 */
	protected String hittedSpot = HITTED_SPOT_EDEFAULT;

	/**
	 * The default value of the '{@link #getEffect() <em>Effect</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffect()
	 * @generated
	 * @ordered
	 */
	protected static final String EFFECT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEffect() <em>Effect</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffect()
	 * @generated
	 * @ordered
	 */
	protected String effect = EFFECT_EDEFAULT;

	/**
	 * The default value of the '{@link #getEffectValue() <em>Effect Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffectValue()
	 * @generated
	 * @ordered
	 */
	protected static final float EFFECT_VALUE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getEffectValue() <em>Effect Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffectValue()
	 * @generated
	 * @ordered
	 */
	protected float effectValue = EFFECT_VALUE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getObjID() <em>Obj ID</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjID()
	 * @generated
	 * @ordered
	 */
	protected EList<String> objID;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CollisionsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CsPackage.Literals.COLLISIONS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getHittedSpot() {
		return hittedSpot;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setHittedSpot(String newHittedSpot) {
		String oldHittedSpot = hittedSpot;
		hittedSpot = newHittedSpot;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.COLLISIONS__HITTED_SPOT, oldHittedSpot,
					hittedSpot));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getEffect() {
		return effect;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setEffect(String newEffect) {
		String oldEffect = effect;
		effect = newEffect;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.COLLISIONS__EFFECT, oldEffect, effect));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getEffectValue() {
		return effectValue;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setEffectValue(float newEffectValue) {
		float oldEffectValue = effectValue;
		effectValue = newEffectValue;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.COLLISIONS__EFFECT_VALUE, oldEffectValue,
					effectValue));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<String> getObjID() {
		if (objID == null) {
			objID = new EDataTypeUniqueEList<String>(String.class, this, CsPackage.COLLISIONS__OBJ_ID);
		}
		return objID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CsPackage.COLLISIONS__HITTED_SPOT:
			return getHittedSpot();
		case CsPackage.COLLISIONS__EFFECT:
			return getEffect();
		case CsPackage.COLLISIONS__EFFECT_VALUE:
			return getEffectValue();
		case CsPackage.COLLISIONS__OBJ_ID:
			return getObjID();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CsPackage.COLLISIONS__HITTED_SPOT:
			setHittedSpot((String) newValue);
			return;
		case CsPackage.COLLISIONS__EFFECT:
			setEffect((String) newValue);
			return;
		case CsPackage.COLLISIONS__EFFECT_VALUE:
			setEffectValue((Float) newValue);
			return;
		case CsPackage.COLLISIONS__OBJ_ID:
			getObjID().clear();
			getObjID().addAll((Collection<? extends String>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CsPackage.COLLISIONS__HITTED_SPOT:
			setHittedSpot(HITTED_SPOT_EDEFAULT);
			return;
		case CsPackage.COLLISIONS__EFFECT:
			setEffect(EFFECT_EDEFAULT);
			return;
		case CsPackage.COLLISIONS__EFFECT_VALUE:
			setEffectValue(EFFECT_VALUE_EDEFAULT);
			return;
		case CsPackage.COLLISIONS__OBJ_ID:
			getObjID().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CsPackage.COLLISIONS__HITTED_SPOT:
			return HITTED_SPOT_EDEFAULT == null ? hittedSpot != null : !HITTED_SPOT_EDEFAULT.equals(hittedSpot);
		case CsPackage.COLLISIONS__EFFECT:
			return EFFECT_EDEFAULT == null ? effect != null : !EFFECT_EDEFAULT.equals(effect);
		case CsPackage.COLLISIONS__EFFECT_VALUE:
			return effectValue != EFFECT_VALUE_EDEFAULT;
		case CsPackage.COLLISIONS__OBJ_ID:
			return objID != null && !objID.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (hittedSpot: ");
		result.append(hittedSpot);
		result.append(", effect: ");
		result.append(effect);
		result.append(", effectValue: ");
		result.append(effectValue);
		result.append(", objID: ");
		result.append(objID);
		result.append(')');
		return result.toString();
	}

} //CollisionsImpl
