/**
 */
package no.ntnu.tdt4250.h2024.cs.impl;

import java.util.Collection;

import no.ntnu.tdt4250.h2024.cs.Ability;
import no.ntnu.tdt4250.h2024.cs.Action;
import no.ntnu.tdt4250.h2024.cs.CsPackage;
import no.ntnu.tdt4250.h2024.cs.GameObject;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeEList;
import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Game Object</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#getCoordinates <em>Coordinates</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#getSprite <em>Sprite</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#getSize <em>Size</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#isIsTakingDamage <em>Is Taking Damage</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#getAmountOfDamage <em>Amount Of Damage</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#getDamageDuration <em>Damage Duration</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#getVelocity <em>Velocity</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#getDirectionDegrees <em>Direction Degrees</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#getAbility <em>Ability</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#getIdentifier <em>Identifier</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#getAction <em>Action</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.GameObjectImpl#getDurability <em>Durability</em>}</li>
 * </ul>
 *
 * @generated
 */
public class GameObjectImpl extends MinimalEObjectImpl.Container implements GameObject {
	/**
	 * The cached value of the '{@link #getCoordinates() <em>Coordinates</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCoordinates()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> coordinates;

	/**
	 * The default value of the '{@link #getSprite() <em>Sprite</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSprite()
	 * @generated
	 * @ordered
	 */
	protected static final String SPRITE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSprite() <em>Sprite</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSprite()
	 * @generated
	 * @ordered
	 */
	protected String sprite = SPRITE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getSize() <em>Size</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSize()
	 * @generated
	 * @ordered
	 */
	protected EList<Integer> size;

	/**
	 * The default value of the '{@link #isIsTakingDamage() <em>Is Taking Damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsTakingDamage()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_TAKING_DAMAGE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsTakingDamage() <em>Is Taking Damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsTakingDamage()
	 * @generated
	 * @ordered
	 */
	protected boolean isTakingDamage = IS_TAKING_DAMAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getAmountOfDamage() <em>Amount Of Damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAmountOfDamage()
	 * @generated
	 * @ordered
	 */
	protected static final float AMOUNT_OF_DAMAGE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getAmountOfDamage() <em>Amount Of Damage</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAmountOfDamage()
	 * @generated
	 * @ordered
	 */
	protected float amountOfDamage = AMOUNT_OF_DAMAGE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDamageDuration() <em>Damage Duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDamageDuration()
	 * @generated
	 * @ordered
	 */
	protected static final int DAMAGE_DURATION_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getDamageDuration() <em>Damage Duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDamageDuration()
	 * @generated
	 * @ordered
	 */
	protected int damageDuration = DAMAGE_DURATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getVelocity() <em>Velocity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVelocity()
	 * @generated
	 * @ordered
	 */
	protected static final float VELOCITY_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getVelocity() <em>Velocity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getVelocity()
	 * @generated
	 * @ordered
	 */
	protected float velocity = VELOCITY_EDEFAULT;

	/**
	 * The cached value of the '{@link #getDirectionDegrees() <em>Direction Degrees</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDirectionDegrees()
	 * @generated
	 * @ordered
	 */
	protected EList<Double> directionDegrees;

	/**
	 * The cached value of the '{@link #getAbility() <em>Ability</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAbility()
	 * @generated
	 * @ordered
	 */
	protected EList<Ability> ability;

	/**
	 * The default value of the '{@link #getIdentifier() <em>Identifier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdentifier()
	 * @generated
	 * @ordered
	 */
	protected static final String IDENTIFIER_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getIdentifier() <em>Identifier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIdentifier()
	 * @generated
	 * @ordered
	 */
	protected String identifier = IDENTIFIER_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAction() <em>Action</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAction()
	 * @generated
	 * @ordered
	 */
	protected EList<Action> action;

	/**
	 * The default value of the '{@link #getDurability() <em>Durability</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDurability()
	 * @generated
	 * @ordered
	 */
	protected static final int DURABILITY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getDurability() <em>Durability</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDurability()
	 * @generated
	 * @ordered
	 */
	protected int durability = DURABILITY_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GameObjectImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CsPackage.Literals.GAME_OBJECT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getCoordinates() {
		if (coordinates == null) {
			coordinates = new EDataTypeEList<Integer>(Integer.class, this, CsPackage.GAME_OBJECT__COORDINATES);
		}
		return coordinates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getSprite() {
		return sprite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setSprite(String newSprite) {
		String oldSprite = sprite;
		sprite = newSprite;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.GAME_OBJECT__SPRITE, oldSprite, sprite));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Integer> getSize() {
		if (size == null) {
			size = new EDataTypeEList<Integer>(Integer.class, this, CsPackage.GAME_OBJECT__SIZE);
		}
		return size;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isIsTakingDamage() {
		return isTakingDamage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsTakingDamage(boolean newIsTakingDamage) {
		boolean oldIsTakingDamage = isTakingDamage;
		isTakingDamage = newIsTakingDamage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.GAME_OBJECT__IS_TAKING_DAMAGE,
					oldIsTakingDamage, isTakingDamage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getAmountOfDamage() {
		return amountOfDamage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setAmountOfDamage(float newAmountOfDamage) {
		float oldAmountOfDamage = amountOfDamage;
		amountOfDamage = newAmountOfDamage;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.GAME_OBJECT__AMOUNT_OF_DAMAGE,
					oldAmountOfDamage, amountOfDamage));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getDamageDuration() {
		return damageDuration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDamageDuration(int newDamageDuration) {
		int oldDamageDuration = damageDuration;
		damageDuration = newDamageDuration;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.GAME_OBJECT__DAMAGE_DURATION,
					oldDamageDuration, damageDuration));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getVelocity() {
		return velocity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setVelocity(float newVelocity) {
		float oldVelocity = velocity;
		velocity = newVelocity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.GAME_OBJECT__VELOCITY, oldVelocity,
					velocity));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Double> getDirectionDegrees() {
		if (directionDegrees == null) {
			directionDegrees = new EDataTypeUniqueEList<Double>(Double.class, this,
					CsPackage.GAME_OBJECT__DIRECTION_DEGREES);
		}
		return directionDegrees;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Ability> getAbility() {
		if (ability == null) {
			ability = new EObjectContainmentEList<Ability>(Ability.class, this, CsPackage.GAME_OBJECT__ABILITY);
		}
		return ability;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getIdentifier() {
		return identifier;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIdentifier(String newIdentifier) {
		String oldIdentifier = identifier;
		identifier = newIdentifier;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.GAME_OBJECT__IDENTIFIER, oldIdentifier,
					identifier));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Action> getAction() {
		if (action == null) {
			action = new EObjectContainmentEList<Action>(Action.class, this, CsPackage.GAME_OBJECT__ACTION);
		}
		return action;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getDurability() {
		return durability;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDurability(int newDurability) {
		int oldDurability = durability;
		durability = newDurability;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.GAME_OBJECT__DURABILITY, oldDurability,
					durability));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case CsPackage.GAME_OBJECT__ABILITY:
			return ((InternalEList<?>) getAbility()).basicRemove(otherEnd, msgs);
		case CsPackage.GAME_OBJECT__ACTION:
			return ((InternalEList<?>) getAction()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CsPackage.GAME_OBJECT__COORDINATES:
			return getCoordinates();
		case CsPackage.GAME_OBJECT__SPRITE:
			return getSprite();
		case CsPackage.GAME_OBJECT__SIZE:
			return getSize();
		case CsPackage.GAME_OBJECT__IS_TAKING_DAMAGE:
			return isIsTakingDamage();
		case CsPackage.GAME_OBJECT__AMOUNT_OF_DAMAGE:
			return getAmountOfDamage();
		case CsPackage.GAME_OBJECT__DAMAGE_DURATION:
			return getDamageDuration();
		case CsPackage.GAME_OBJECT__VELOCITY:
			return getVelocity();
		case CsPackage.GAME_OBJECT__DIRECTION_DEGREES:
			return getDirectionDegrees();
		case CsPackage.GAME_OBJECT__ABILITY:
			return getAbility();
		case CsPackage.GAME_OBJECT__IDENTIFIER:
			return getIdentifier();
		case CsPackage.GAME_OBJECT__ACTION:
			return getAction();
		case CsPackage.GAME_OBJECT__DURABILITY:
			return getDurability();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CsPackage.GAME_OBJECT__COORDINATES:
			getCoordinates().clear();
			getCoordinates().addAll((Collection<? extends Integer>) newValue);
			return;
		case CsPackage.GAME_OBJECT__SPRITE:
			setSprite((String) newValue);
			return;
		case CsPackage.GAME_OBJECT__SIZE:
			getSize().clear();
			getSize().addAll((Collection<? extends Integer>) newValue);
			return;
		case CsPackage.GAME_OBJECT__IS_TAKING_DAMAGE:
			setIsTakingDamage((Boolean) newValue);
			return;
		case CsPackage.GAME_OBJECT__AMOUNT_OF_DAMAGE:
			setAmountOfDamage((Float) newValue);
			return;
		case CsPackage.GAME_OBJECT__DAMAGE_DURATION:
			setDamageDuration((Integer) newValue);
			return;
		case CsPackage.GAME_OBJECT__VELOCITY:
			setVelocity((Float) newValue);
			return;
		case CsPackage.GAME_OBJECT__DIRECTION_DEGREES:
			getDirectionDegrees().clear();
			getDirectionDegrees().addAll((Collection<? extends Double>) newValue);
			return;
		case CsPackage.GAME_OBJECT__ABILITY:
			getAbility().clear();
			getAbility().addAll((Collection<? extends Ability>) newValue);
			return;
		case CsPackage.GAME_OBJECT__IDENTIFIER:
			setIdentifier((String) newValue);
			return;
		case CsPackage.GAME_OBJECT__ACTION:
			getAction().clear();
			getAction().addAll((Collection<? extends Action>) newValue);
			return;
		case CsPackage.GAME_OBJECT__DURABILITY:
			setDurability((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CsPackage.GAME_OBJECT__COORDINATES:
			getCoordinates().clear();
			return;
		case CsPackage.GAME_OBJECT__SPRITE:
			setSprite(SPRITE_EDEFAULT);
			return;
		case CsPackage.GAME_OBJECT__SIZE:
			getSize().clear();
			return;
		case CsPackage.GAME_OBJECT__IS_TAKING_DAMAGE:
			setIsTakingDamage(IS_TAKING_DAMAGE_EDEFAULT);
			return;
		case CsPackage.GAME_OBJECT__AMOUNT_OF_DAMAGE:
			setAmountOfDamage(AMOUNT_OF_DAMAGE_EDEFAULT);
			return;
		case CsPackage.GAME_OBJECT__DAMAGE_DURATION:
			setDamageDuration(DAMAGE_DURATION_EDEFAULT);
			return;
		case CsPackage.GAME_OBJECT__VELOCITY:
			setVelocity(VELOCITY_EDEFAULT);
			return;
		case CsPackage.GAME_OBJECT__DIRECTION_DEGREES:
			getDirectionDegrees().clear();
			return;
		case CsPackage.GAME_OBJECT__ABILITY:
			getAbility().clear();
			return;
		case CsPackage.GAME_OBJECT__IDENTIFIER:
			setIdentifier(IDENTIFIER_EDEFAULT);
			return;
		case CsPackage.GAME_OBJECT__ACTION:
			getAction().clear();
			return;
		case CsPackage.GAME_OBJECT__DURABILITY:
			setDurability(DURABILITY_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CsPackage.GAME_OBJECT__COORDINATES:
			return coordinates != null && !coordinates.isEmpty();
		case CsPackage.GAME_OBJECT__SPRITE:
			return SPRITE_EDEFAULT == null ? sprite != null : !SPRITE_EDEFAULT.equals(sprite);
		case CsPackage.GAME_OBJECT__SIZE:
			return size != null && !size.isEmpty();
		case CsPackage.GAME_OBJECT__IS_TAKING_DAMAGE:
			return isTakingDamage != IS_TAKING_DAMAGE_EDEFAULT;
		case CsPackage.GAME_OBJECT__AMOUNT_OF_DAMAGE:
			return amountOfDamage != AMOUNT_OF_DAMAGE_EDEFAULT;
		case CsPackage.GAME_OBJECT__DAMAGE_DURATION:
			return damageDuration != DAMAGE_DURATION_EDEFAULT;
		case CsPackage.GAME_OBJECT__VELOCITY:
			return velocity != VELOCITY_EDEFAULT;
		case CsPackage.GAME_OBJECT__DIRECTION_DEGREES:
			return directionDegrees != null && !directionDegrees.isEmpty();
		case CsPackage.GAME_OBJECT__ABILITY:
			return ability != null && !ability.isEmpty();
		case CsPackage.GAME_OBJECT__IDENTIFIER:
			return IDENTIFIER_EDEFAULT == null ? identifier != null : !IDENTIFIER_EDEFAULT.equals(identifier);
		case CsPackage.GAME_OBJECT__ACTION:
			return action != null && !action.isEmpty();
		case CsPackage.GAME_OBJECT__DURABILITY:
			return durability != DURABILITY_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (coordinates: ");
		result.append(coordinates);
		result.append(", sprite: ");
		result.append(sprite);
		result.append(", size: ");
		result.append(size);
		result.append(", isTakingDamage: ");
		result.append(isTakingDamage);
		result.append(", amountOfDamage: ");
		result.append(amountOfDamage);
		result.append(", damageDuration: ");
		result.append(damageDuration);
		result.append(", velocity: ");
		result.append(velocity);
		result.append(", directionDegrees: ");
		result.append(directionDegrees);
		result.append(", identifier: ");
		result.append(identifier);
		result.append(", durability: ");
		result.append(durability);
		result.append(')');
		return result.toString();
	}

} //GameObjectImpl
