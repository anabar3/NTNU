/**
 */
package no.ntnu.tdt4250.h2024.cs.impl;

import java.util.Collection;

import no.ntnu.tdt4250.h2024.cs.CsPackage;
import no.ntnu.tdt4250.h2024.cs.GameObject;
import no.ntnu.tdt4250.h2024.cs.ObjectType;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EDataTypeUniqueEList;
import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Object Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.ObjectTypeImpl#getName <em>Name</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.ObjectTypeImpl#getInteraction <em>Interaction</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.ObjectTypeImpl#getCharacteristic <em>Characteristic</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.ObjectTypeImpl#getGameobject <em>Gameobject</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ObjectTypeImpl extends MinimalEObjectImpl.Container implements ObjectType {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getInteraction() <em>Interaction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInteraction()
	 * @generated
	 * @ordered
	 */
	protected static final String INTERACTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getInteraction() <em>Interaction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInteraction()
	 * @generated
	 * @ordered
	 */
	protected String interaction = INTERACTION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getCharacteristic() <em>Characteristic</em>}' attribute list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCharacteristic()
	 * @generated
	 * @ordered
	 */
	protected EList<Object> characteristic;

	/**
	 * The cached value of the '{@link #getGameobject() <em>Gameobject</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getGameobject()
	 * @generated
	 * @ordered
	 */
	protected EList<GameObject> gameobject;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ObjectTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CsPackage.Literals.OBJECT_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.OBJECT_TYPE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getInteraction() {
		return interaction;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInteraction(String newInteraction) {
		String oldInteraction = interaction;
		interaction = newInteraction;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.OBJECT_TYPE__INTERACTION, oldInteraction,
					interaction));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Object> getCharacteristic() {
		if (characteristic == null) {
			characteristic = new EDataTypeUniqueEList<Object>(Object.class, this,
					CsPackage.OBJECT_TYPE__CHARACTERISTIC);
		}
		return characteristic;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<GameObject> getGameobject() {
		if (gameobject == null) {
			gameobject = new EObjectContainmentEList<GameObject>(GameObject.class, this,
					CsPackage.OBJECT_TYPE__GAMEOBJECT);
		}
		return gameobject;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case CsPackage.OBJECT_TYPE__GAMEOBJECT:
			return ((InternalEList<?>) getGameobject()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CsPackage.OBJECT_TYPE__NAME:
			return getName();
		case CsPackage.OBJECT_TYPE__INTERACTION:
			return getInteraction();
		case CsPackage.OBJECT_TYPE__CHARACTERISTIC:
			return getCharacteristic();
		case CsPackage.OBJECT_TYPE__GAMEOBJECT:
			return getGameobject();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CsPackage.OBJECT_TYPE__NAME:
			setName((String) newValue);
			return;
		case CsPackage.OBJECT_TYPE__INTERACTION:
			setInteraction((String) newValue);
			return;
		case CsPackage.OBJECT_TYPE__CHARACTERISTIC:
			getCharacteristic().clear();
			getCharacteristic().addAll((Collection<? extends Object>) newValue);
			return;
		case CsPackage.OBJECT_TYPE__GAMEOBJECT:
			getGameobject().clear();
			getGameobject().addAll((Collection<? extends GameObject>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CsPackage.OBJECT_TYPE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case CsPackage.OBJECT_TYPE__INTERACTION:
			setInteraction(INTERACTION_EDEFAULT);
			return;
		case CsPackage.OBJECT_TYPE__CHARACTERISTIC:
			getCharacteristic().clear();
			return;
		case CsPackage.OBJECT_TYPE__GAMEOBJECT:
			getGameobject().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CsPackage.OBJECT_TYPE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case CsPackage.OBJECT_TYPE__INTERACTION:
			return INTERACTION_EDEFAULT == null ? interaction != null : !INTERACTION_EDEFAULT.equals(interaction);
		case CsPackage.OBJECT_TYPE__CHARACTERISTIC:
			return characteristic != null && !characteristic.isEmpty();
		case CsPackage.OBJECT_TYPE__GAMEOBJECT:
			return gameobject != null && !gameobject.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", interaction: ");
		result.append(interaction);
		result.append(", characteristic: ");
		result.append(characteristic);
		result.append(')');
		return result.toString();
	}

} //ObjectTypeImpl
