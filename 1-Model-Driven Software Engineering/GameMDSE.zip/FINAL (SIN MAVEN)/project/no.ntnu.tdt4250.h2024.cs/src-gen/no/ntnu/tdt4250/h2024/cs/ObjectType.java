/**
 */
package no.ntnu.tdt4250.h2024.cs;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Object Type</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.ObjectType#getName <em>Name</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.ObjectType#getInteraction <em>Interaction</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.ObjectType#getCharacteristic <em>Characteristic</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.ObjectType#getGameobject <em>Gameobject</em>}</li>
 * </ul>
 *
 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getObjectType()
 * @model
 * @generated
 */
public interface ObjectType extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getObjectType_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.ObjectType#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Interaction</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Interaction</em>' attribute.
	 * @see #setInteraction(String)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getObjectType_Interaction()
	 * @model
	 * @generated
	 */
	String getInteraction();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.ObjectType#getInteraction <em>Interaction</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Interaction</em>' attribute.
	 * @see #getInteraction()
	 * @generated
	 */
	void setInteraction(String value);

	/**
	 * Returns the value of the '<em><b>Characteristic</b></em>' attribute list.
	 * The list contents are of type {@link java.lang.Object}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Characteristic</em>' attribute list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getObjectType_Characteristic()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.AnySimpleType"
	 * @generated
	 */
	EList<Object> getCharacteristic();

	/**
	 * Returns the value of the '<em><b>Gameobject</b></em>' containment reference list.
	 * The list contents are of type {@link no.ntnu.tdt4250.h2024.cs.GameObject}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Gameobject</em>' containment reference list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getObjectType_Gameobject()
	 * @model containment="true"
	 * @generated
	 */
	EList<GameObject> getGameobject();

} // ObjectType
