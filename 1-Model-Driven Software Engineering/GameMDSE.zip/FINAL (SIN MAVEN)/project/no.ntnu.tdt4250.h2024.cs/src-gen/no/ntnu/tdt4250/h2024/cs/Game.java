/**
 */
package no.ntnu.tdt4250.h2024.cs;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Game</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Game#getName <em>Name</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Game#getDescription <em>Description</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Game#getBackground <em>Background</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Game#getObjectType <em>Object Type</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Game#getCollisions <em>Collisions</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Game#isHasLost <em>Has Lost</em>}</li>
 * </ul>
 *
 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGame()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='thereShouldBeAtLeastOneMarioAndAtMost4'"
 * @generated
 */
public interface Game extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGame_Name()
	 * @model required="true"
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Game#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Description</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description</em>' attribute.
	 * @see #setDescription(String)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGame_Description()
	 * @model
	 * @generated
	 */
	String getDescription();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Game#getDescription <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description</em>' attribute.
	 * @see #getDescription()
	 * @generated
	 */
	void setDescription(String value);

	/**
	 * Returns the value of the '<em><b>Background</b></em>' containment reference list.
	 * The list contents are of type {@link no.ntnu.tdt4250.h2024.cs.Background}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Background</em>' containment reference list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGame_Background()
	 * @model containment="true"
	 * @generated
	 */
	EList<Background> getBackground();

	/**
	 * Returns the value of the '<em><b>Object Type</b></em>' containment reference list.
	 * The list contents are of type {@link no.ntnu.tdt4250.h2024.cs.ObjectType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Object Type</em>' containment reference list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGame_ObjectType()
	 * @model containment="true"
	 * @generated
	 */
	EList<ObjectType> getObjectType();

	/**
	 * Returns the value of the '<em><b>Collisions</b></em>' containment reference list.
	 * The list contents are of type {@link no.ntnu.tdt4250.h2024.cs.Collisions}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Collisions</em>' containment reference list.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGame_Collisions()
	 * @model containment="true"
	 * @generated
	 */
	EList<Collisions> getCollisions();

	/**
	 * Returns the value of the '<em><b>Has Lost</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Has Lost</em>' attribute.
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getGame_HasLost()
	 * @model default="false" required="true" transient="true" changeable="false" volatile="true" derived="true"
	 * @generated
	 */
	boolean isHasLost();

} // Game
