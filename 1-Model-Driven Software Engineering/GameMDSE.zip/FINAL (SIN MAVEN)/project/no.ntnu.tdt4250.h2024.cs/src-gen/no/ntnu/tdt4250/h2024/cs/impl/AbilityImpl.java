/**
 */
package no.ntnu.tdt4250.h2024.cs.impl;

import java.util.Collection;

import no.ntnu.tdt4250.h2024.cs.Ability;
import no.ntnu.tdt4250.h2024.cs.CsPackage;
import no.ntnu.tdt4250.h2024.cs.Effect;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Ability</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.AbilityImpl#getName <em>Name</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.AbilityImpl#getDuration <em>Duration</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.AbilityImpl#isIsBeingUsed <em>Is Being Used</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.impl.AbilityImpl#getEffect <em>Effect</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AbilityImpl extends MinimalEObjectImpl.Container implements Ability {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getDuration() <em>Duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDuration()
	 * @generated
	 * @ordered
	 */
	protected static final int DURATION_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getDuration() <em>Duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDuration()
	 * @generated
	 * @ordered
	 */
	protected int duration = DURATION_EDEFAULT;

	/**
	 * The default value of the '{@link #isIsBeingUsed() <em>Is Being Used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsBeingUsed()
	 * @generated
	 * @ordered
	 */
	protected static final boolean IS_BEING_USED_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isIsBeingUsed() <em>Is Being Used</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isIsBeingUsed()
	 * @generated
	 * @ordered
	 */
	protected boolean isBeingUsed = IS_BEING_USED_EDEFAULT;

	/**
	 * The cached value of the '{@link #getEffect() <em>Effect</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffect()
	 * @generated
	 * @ordered
	 */
	protected EList<Effect> effect;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AbilityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CsPackage.Literals.ABILITY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.ABILITY__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getDuration() {
		return duration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDuration(int newDuration) {
		int oldDuration = duration;
		duration = newDuration;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.ABILITY__DURATION, oldDuration, duration));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isIsBeingUsed() {
		return isBeingUsed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setIsBeingUsed(boolean newIsBeingUsed) {
		boolean oldIsBeingUsed = isBeingUsed;
		isBeingUsed = newIsBeingUsed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CsPackage.ABILITY__IS_BEING_USED, oldIsBeingUsed,
					isBeingUsed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Effect> getEffect() {
		if (effect == null) {
			effect = new EObjectContainmentEList<Effect>(Effect.class, this, CsPackage.ABILITY__EFFECT);
		}
		return effect;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case CsPackage.ABILITY__EFFECT:
			return ((InternalEList<?>) getEffect()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case CsPackage.ABILITY__NAME:
			return getName();
		case CsPackage.ABILITY__DURATION:
			return getDuration();
		case CsPackage.ABILITY__IS_BEING_USED:
			return isIsBeingUsed();
		case CsPackage.ABILITY__EFFECT:
			return getEffect();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case CsPackage.ABILITY__NAME:
			setName((String) newValue);
			return;
		case CsPackage.ABILITY__DURATION:
			setDuration((Integer) newValue);
			return;
		case CsPackage.ABILITY__IS_BEING_USED:
			setIsBeingUsed((Boolean) newValue);
			return;
		case CsPackage.ABILITY__EFFECT:
			getEffect().clear();
			getEffect().addAll((Collection<? extends Effect>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case CsPackage.ABILITY__NAME:
			setName(NAME_EDEFAULT);
			return;
		case CsPackage.ABILITY__DURATION:
			setDuration(DURATION_EDEFAULT);
			return;
		case CsPackage.ABILITY__IS_BEING_USED:
			setIsBeingUsed(IS_BEING_USED_EDEFAULT);
			return;
		case CsPackage.ABILITY__EFFECT:
			getEffect().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case CsPackage.ABILITY__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case CsPackage.ABILITY__DURATION:
			return duration != DURATION_EDEFAULT;
		case CsPackage.ABILITY__IS_BEING_USED:
			return isBeingUsed != IS_BEING_USED_EDEFAULT;
		case CsPackage.ABILITY__EFFECT:
			return effect != null && !effect.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", duration: ");
		result.append(duration);
		result.append(", isBeingUsed: ");
		result.append(isBeingUsed);
		result.append(')');
		return result.toString();
	}

} //AbilityImpl
