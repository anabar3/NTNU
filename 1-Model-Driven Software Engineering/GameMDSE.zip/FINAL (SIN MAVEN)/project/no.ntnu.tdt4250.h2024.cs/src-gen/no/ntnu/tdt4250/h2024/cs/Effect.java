/**
 */
package no.ntnu.tdt4250.h2024.cs;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Effect</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Effect#getIdentifier <em>Identifier</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Effect#getVelocity <em>Velocity</em>}</li>
 *   <li>{@link no.ntnu.tdt4250.h2024.cs.Effect#getRange <em>Range</em>}</li>
 * </ul>
 *
 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getEffect()
 * @model
 * @generated
 */
public interface Effect extends EObject {
	/**
	 * Returns the value of the '<em><b>Identifier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Identifier</em>' attribute.
	 * @see #setIdentifier(String)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getEffect_Identifier()
	 * @model required="true"
	 * @generated
	 */
	String getIdentifier();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Effect#getIdentifier <em>Identifier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Identifier</em>' attribute.
	 * @see #getIdentifier()
	 * @generated
	 */
	void setIdentifier(String value);

	/**
	 * Returns the value of the '<em><b>Velocity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Velocity</em>' attribute.
	 * @see #setVelocity(float)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getEffect_Velocity()
	 * @model
	 * @generated
	 */
	float getVelocity();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Effect#getVelocity <em>Velocity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Velocity</em>' attribute.
	 * @see #getVelocity()
	 * @generated
	 */
	void setVelocity(float value);

	/**
	 * Returns the value of the '<em><b>Range</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Range</em>' attribute.
	 * @see #setRange(float)
	 * @see no.ntnu.tdt4250.h2024.cs.CsPackage#getEffect_Range()
	 * @model
	 * @generated
	 */
	float getRange();

	/**
	 * Sets the value of the '{@link no.ntnu.tdt4250.h2024.cs.Effect#getRange <em>Range</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Range</em>' attribute.
	 * @see #getRange()
	 * @generated
	 */
	void setRange(float value);

} // Effect
