## Game Development Project

A project done by sergiob@stud.ntnu.no
 
- Description:

This is an ecore modeling proyect that consist on
the development of "Super Mario Bros" like type
of games using Eclipse.

- Repo Structure

The repo is divided into two main folders, the model
folder, which will be explained below and the src-gen
folder, which is the one that contains all the generated
java code from the model.



- Model folder

The project is divided into several clases, the main
ones are the metaclass `game`, and the classes `gameObject`
`background` and `collisions`. From these, gameObject is a 
super class for all the elements that can be inside these
types of games, like the main characters, the enemies,
the boost and the obstacles.

The objective of this project is to generalize the 
"Super Mario Bros" type of games, and for doing so, 
I abstracted the classes to the gameObject class, as well as
make use of inheritances and provided a reliable approach 
regarding collisions.

Note: To make things easier, the sizes as well as the 
coordinates will be multiple of 2, and the sprites 
will all be set to 0,0,0, but in a real scenario, the
sizes could change and the sprites must be unique. Moreover,
some atributes of the mainCharacter (like hasStar or isBig)
are not really model-like, but since this is first and 
foresmost a Super Mario Bros model, the power-ups he receive
have to be related to the ones in the game. New power ups can 
also be implemented. In the future in another class to make 
things even more model-like.


[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/_CDJsVQB)
