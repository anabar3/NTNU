package no.ntnu.tdt4250.cs.genjavaxtend;

import java.io.FileWriter;
import java.util.Map;
import no.ntnu.tdt4250.h2024.cs.CsPackage;
import no.ntnu.tdt4250.h2024.cs.Game;
import no.ntnu.tdt4250.h2024.cs.impl.CsPackageImpl;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.InputOutput;
import org.eclipse.xtext.xbase.lib.IterableExtensions;

@SuppressWarnings("all")
public class GeneratorRunner {
  public static void main(final String[] args) {
    final String modelPath = "";
    final String outputFolder = "";
    GeneratorRunner.registerMetamodel();
    GeneratorRunner.registerResourceFactory();
    final Game game = GeneratorRunner.loadModel(modelPath);
    final GameGenerator generator = new GameGenerator(game);
  }

  /**
   * Writes a given string to a file at the specified file path.
   */
  public static String writeText(final String text, final String filePath) {
    try {
      String _xblockexpression = null;
      {
        InputOutput.<String>println(("> Writing: " + filePath));
        final FileWriter file = new FileWriter(filePath, false);
        file.write(text);
        file.close();
        _xblockexpression = InputOutput.<String>println("> Done.");
      }
      return _xblockexpression;
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }

  /**
   * Loads the model from the specified file path.
   */
  public static Game loadModel(final String filePath) {
    Game _xblockexpression = null;
    {
      final ResourceSet resSet = new ResourceSetImpl();
      final URI uri = URI.createURI(filePath);
      InputOutput.<String>println(("> Loading: " + uri));
      final Resource resource = resSet.getResource(uri, true);
      InputOutput.<String>println("> Loaded.");
      EObject _head = IterableExtensions.<EObject>head(resource.getContents());
      _xblockexpression = ((Game) _head);
    }
    return _xblockexpression;
  }

  /**
   * Registers the Game metamodel in the global EPackage registry.
   */
  public static Object registerMetamodel() {
    Object _xblockexpression = null;
    {
      final CsPackage myPackage = CsPackageImpl.eINSTANCE;
      _xblockexpression = EPackage.Registry.INSTANCE.put(myPackage.getNsURI(), myPackage);
    }
    return _xblockexpression;
  }

  /**
   * Registers the resource factory for .gamedsl files.
   */
  public static Object registerResourceFactory() {
    Object _xblockexpression = null;
    {
      final Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
      final Map<String, Object> extToFactoryMap = reg.getExtensionToFactoryMap();
      XMIResourceFactoryImpl _xMIResourceFactoryImpl = new XMIResourceFactoryImpl();
      _xblockexpression = extToFactoryMap.put("gamedsl", _xMIResourceFactoryImpl);
    }
    return _xblockexpression;
  }
}
