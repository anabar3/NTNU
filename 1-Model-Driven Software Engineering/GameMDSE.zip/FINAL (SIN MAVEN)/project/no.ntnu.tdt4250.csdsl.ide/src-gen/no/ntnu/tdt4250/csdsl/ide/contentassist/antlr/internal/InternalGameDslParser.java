package no.ntnu.tdt4250.csdsl.ide.contentassist.antlr.internal;

import java.io.InputStream;
import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.AbstractInternalContentAssistParser;
import org.eclipse.xtext.ide.editor.contentassist.antlr.internal.DFA;
import no.ntnu.tdt4250.csdsl.services.GameDslGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalGameDslParser extends AbstractInternalContentAssistParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_ID", "RULE_INT", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'true'", "'false'", "'E'", "'e'", "'Game'", "'{'", "'}'", "'background'", "','", "'objectType'", "'collisions'", "'Background'", "'coordinates'", "'('", "')'", "'size'", "'backgroundSpeed:'", "'backgroundMoving:'", "'Type'", "'interaction:'", "'characteristic'", "'gameObject'", "'GameObject'", "'sprite:'", "'velocity:'", "'directionDegrees'", "'isTakingDamage:'", "'amountOfDamage:'", "'damageDuration:'", "'durability:'", "'ability'", "'action'", "'Collisions'", "'hittedSpot:'", "'effect:'", "'effectValue:'", "'objID'", "'Ability'", "'isBeingUsed:'", "'effect'", "'duration:'", "'Action'", "'Effect'", "'range:'", "'-'", "'.'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__11=11;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_ID=5;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=9;
    public static final int RULE_ANY_OTHER=10;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalGameDslParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalGameDslParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalGameDslParser.tokenNames; }
    public String getGrammarFileName() { return "InternalGameDsl.g"; }


    	private GameDslGrammarAccess grammarAccess;

    	public void setGrammarAccess(GameDslGrammarAccess grammarAccess) {
    		this.grammarAccess = grammarAccess;
    	}

    	@Override
    	protected Grammar getGrammar() {
    		return grammarAccess.getGrammar();
    	}

    	@Override
    	protected String getValueForTokenName(String tokenName) {
    		return tokenName;
    	}



    // $ANTLR start "entryRuleGame"
    // InternalGameDsl.g:53:1: entryRuleGame : ruleGame EOF ;
    public final void entryRuleGame() throws RecognitionException {
        try {
            // InternalGameDsl.g:54:1: ( ruleGame EOF )
            // InternalGameDsl.g:55:1: ruleGame EOF
            {
             before(grammarAccess.getGameRule()); 
            pushFollow(FOLLOW_1);
            ruleGame();

            state._fsp--;

             after(grammarAccess.getGameRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGame"


    // $ANTLR start "ruleGame"
    // InternalGameDsl.g:62:1: ruleGame : ( ( rule__Game__Group__0 ) ) ;
    public final void ruleGame() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:66:2: ( ( ( rule__Game__Group__0 ) ) )
            // InternalGameDsl.g:67:2: ( ( rule__Game__Group__0 ) )
            {
            // InternalGameDsl.g:67:2: ( ( rule__Game__Group__0 ) )
            // InternalGameDsl.g:68:3: ( rule__Game__Group__0 )
            {
             before(grammarAccess.getGameAccess().getGroup()); 
            // InternalGameDsl.g:69:3: ( rule__Game__Group__0 )
            // InternalGameDsl.g:69:4: rule__Game__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Game__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGameAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGame"


    // $ANTLR start "entryRuleBackground"
    // InternalGameDsl.g:78:1: entryRuleBackground : ruleBackground EOF ;
    public final void entryRuleBackground() throws RecognitionException {
        try {
            // InternalGameDsl.g:79:1: ( ruleBackground EOF )
            // InternalGameDsl.g:80:1: ruleBackground EOF
            {
             before(grammarAccess.getBackgroundRule()); 
            pushFollow(FOLLOW_1);
            ruleBackground();

            state._fsp--;

             after(grammarAccess.getBackgroundRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleBackground"


    // $ANTLR start "ruleBackground"
    // InternalGameDsl.g:87:1: ruleBackground : ( ( rule__Background__Group__0 ) ) ;
    public final void ruleBackground() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:91:2: ( ( ( rule__Background__Group__0 ) ) )
            // InternalGameDsl.g:92:2: ( ( rule__Background__Group__0 ) )
            {
            // InternalGameDsl.g:92:2: ( ( rule__Background__Group__0 ) )
            // InternalGameDsl.g:93:3: ( rule__Background__Group__0 )
            {
             before(grammarAccess.getBackgroundAccess().getGroup()); 
            // InternalGameDsl.g:94:3: ( rule__Background__Group__0 )
            // InternalGameDsl.g:94:4: rule__Background__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Background__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getBackgroundAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleBackground"


    // $ANTLR start "entryRuleObjectType"
    // InternalGameDsl.g:103:1: entryRuleObjectType : ruleObjectType EOF ;
    public final void entryRuleObjectType() throws RecognitionException {
        try {
            // InternalGameDsl.g:104:1: ( ruleObjectType EOF )
            // InternalGameDsl.g:105:1: ruleObjectType EOF
            {
             before(grammarAccess.getObjectTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleObjectType();

            state._fsp--;

             after(grammarAccess.getObjectTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleObjectType"


    // $ANTLR start "ruleObjectType"
    // InternalGameDsl.g:112:1: ruleObjectType : ( ( rule__ObjectType__Group__0 ) ) ;
    public final void ruleObjectType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:116:2: ( ( ( rule__ObjectType__Group__0 ) ) )
            // InternalGameDsl.g:117:2: ( ( rule__ObjectType__Group__0 ) )
            {
            // InternalGameDsl.g:117:2: ( ( rule__ObjectType__Group__0 ) )
            // InternalGameDsl.g:118:3: ( rule__ObjectType__Group__0 )
            {
             before(grammarAccess.getObjectTypeAccess().getGroup()); 
            // InternalGameDsl.g:119:3: ( rule__ObjectType__Group__0 )
            // InternalGameDsl.g:119:4: rule__ObjectType__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getObjectTypeAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleObjectType"


    // $ANTLR start "entryRuleGameObject"
    // InternalGameDsl.g:128:1: entryRuleGameObject : ruleGameObject EOF ;
    public final void entryRuleGameObject() throws RecognitionException {
        try {
            // InternalGameDsl.g:129:1: ( ruleGameObject EOF )
            // InternalGameDsl.g:130:1: ruleGameObject EOF
            {
             before(grammarAccess.getGameObjectRule()); 
            pushFollow(FOLLOW_1);
            ruleGameObject();

            state._fsp--;

             after(grammarAccess.getGameObjectRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleGameObject"


    // $ANTLR start "ruleGameObject"
    // InternalGameDsl.g:137:1: ruleGameObject : ( ( rule__GameObject__Group__0 ) ) ;
    public final void ruleGameObject() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:141:2: ( ( ( rule__GameObject__Group__0 ) ) )
            // InternalGameDsl.g:142:2: ( ( rule__GameObject__Group__0 ) )
            {
            // InternalGameDsl.g:142:2: ( ( rule__GameObject__Group__0 ) )
            // InternalGameDsl.g:143:3: ( rule__GameObject__Group__0 )
            {
             before(grammarAccess.getGameObjectAccess().getGroup()); 
            // InternalGameDsl.g:144:3: ( rule__GameObject__Group__0 )
            // InternalGameDsl.g:144:4: rule__GameObject__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleGameObject"


    // $ANTLR start "entryRuleCollisions"
    // InternalGameDsl.g:153:1: entryRuleCollisions : ruleCollisions EOF ;
    public final void entryRuleCollisions() throws RecognitionException {
        try {
            // InternalGameDsl.g:154:1: ( ruleCollisions EOF )
            // InternalGameDsl.g:155:1: ruleCollisions EOF
            {
             before(grammarAccess.getCollisionsRule()); 
            pushFollow(FOLLOW_1);
            ruleCollisions();

            state._fsp--;

             after(grammarAccess.getCollisionsRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleCollisions"


    // $ANTLR start "ruleCollisions"
    // InternalGameDsl.g:162:1: ruleCollisions : ( ( rule__Collisions__Group__0 ) ) ;
    public final void ruleCollisions() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:166:2: ( ( ( rule__Collisions__Group__0 ) ) )
            // InternalGameDsl.g:167:2: ( ( rule__Collisions__Group__0 ) )
            {
            // InternalGameDsl.g:167:2: ( ( rule__Collisions__Group__0 ) )
            // InternalGameDsl.g:168:3: ( rule__Collisions__Group__0 )
            {
             before(grammarAccess.getCollisionsAccess().getGroup()); 
            // InternalGameDsl.g:169:3: ( rule__Collisions__Group__0 )
            // InternalGameDsl.g:169:4: rule__Collisions__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getCollisionsAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleCollisions"


    // $ANTLR start "entryRuleAbility"
    // InternalGameDsl.g:178:1: entryRuleAbility : ruleAbility EOF ;
    public final void entryRuleAbility() throws RecognitionException {
        try {
            // InternalGameDsl.g:179:1: ( ruleAbility EOF )
            // InternalGameDsl.g:180:1: ruleAbility EOF
            {
             before(grammarAccess.getAbilityRule()); 
            pushFollow(FOLLOW_1);
            ruleAbility();

            state._fsp--;

             after(grammarAccess.getAbilityRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAbility"


    // $ANTLR start "ruleAbility"
    // InternalGameDsl.g:187:1: ruleAbility : ( ( rule__Ability__Group__0 ) ) ;
    public final void ruleAbility() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:191:2: ( ( ( rule__Ability__Group__0 ) ) )
            // InternalGameDsl.g:192:2: ( ( rule__Ability__Group__0 ) )
            {
            // InternalGameDsl.g:192:2: ( ( rule__Ability__Group__0 ) )
            // InternalGameDsl.g:193:3: ( rule__Ability__Group__0 )
            {
             before(grammarAccess.getAbilityAccess().getGroup()); 
            // InternalGameDsl.g:194:3: ( rule__Ability__Group__0 )
            // InternalGameDsl.g:194:4: rule__Ability__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Ability__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getAbilityAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAbility"


    // $ANTLR start "entryRuleAction"
    // InternalGameDsl.g:203:1: entryRuleAction : ruleAction EOF ;
    public final void entryRuleAction() throws RecognitionException {
        try {
            // InternalGameDsl.g:204:1: ( ruleAction EOF )
            // InternalGameDsl.g:205:1: ruleAction EOF
            {
             before(grammarAccess.getActionRule()); 
            pushFollow(FOLLOW_1);
            ruleAction();

            state._fsp--;

             after(grammarAccess.getActionRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAction"


    // $ANTLR start "ruleAction"
    // InternalGameDsl.g:212:1: ruleAction : ( ( rule__Action__Group__0 ) ) ;
    public final void ruleAction() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:216:2: ( ( ( rule__Action__Group__0 ) ) )
            // InternalGameDsl.g:217:2: ( ( rule__Action__Group__0 ) )
            {
            // InternalGameDsl.g:217:2: ( ( rule__Action__Group__0 ) )
            // InternalGameDsl.g:218:3: ( rule__Action__Group__0 )
            {
             before(grammarAccess.getActionAccess().getGroup()); 
            // InternalGameDsl.g:219:3: ( rule__Action__Group__0 )
            // InternalGameDsl.g:219:4: rule__Action__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Action__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getActionAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAction"


    // $ANTLR start "entryRuleEffect"
    // InternalGameDsl.g:228:1: entryRuleEffect : ruleEffect EOF ;
    public final void entryRuleEffect() throws RecognitionException {
        try {
            // InternalGameDsl.g:229:1: ( ruleEffect EOF )
            // InternalGameDsl.g:230:1: ruleEffect EOF
            {
             before(grammarAccess.getEffectRule()); 
            pushFollow(FOLLOW_1);
            ruleEffect();

            state._fsp--;

             after(grammarAccess.getEffectRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEffect"


    // $ANTLR start "ruleEffect"
    // InternalGameDsl.g:237:1: ruleEffect : ( ( rule__Effect__Group__0 ) ) ;
    public final void ruleEffect() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:241:2: ( ( ( rule__Effect__Group__0 ) ) )
            // InternalGameDsl.g:242:2: ( ( rule__Effect__Group__0 ) )
            {
            // InternalGameDsl.g:242:2: ( ( rule__Effect__Group__0 ) )
            // InternalGameDsl.g:243:3: ( rule__Effect__Group__0 )
            {
             before(grammarAccess.getEffectAccess().getGroup()); 
            // InternalGameDsl.g:244:3: ( rule__Effect__Group__0 )
            // InternalGameDsl.g:244:4: rule__Effect__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__Effect__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEffectAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEffect"


    // $ANTLR start "entryRuleAnySimpleType"
    // InternalGameDsl.g:253:1: entryRuleAnySimpleType : ruleAnySimpleType EOF ;
    public final void entryRuleAnySimpleType() throws RecognitionException {
        try {
            // InternalGameDsl.g:254:1: ( ruleAnySimpleType EOF )
            // InternalGameDsl.g:255:1: ruleAnySimpleType EOF
            {
             before(grammarAccess.getAnySimpleTypeRule()); 
            pushFollow(FOLLOW_1);
            ruleAnySimpleType();

            state._fsp--;

             after(grammarAccess.getAnySimpleTypeRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleAnySimpleType"


    // $ANTLR start "ruleAnySimpleType"
    // InternalGameDsl.g:262:1: ruleAnySimpleType : ( ( rule__AnySimpleType__Alternatives ) ) ;
    public final void ruleAnySimpleType() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:266:2: ( ( ( rule__AnySimpleType__Alternatives ) ) )
            // InternalGameDsl.g:267:2: ( ( rule__AnySimpleType__Alternatives ) )
            {
            // InternalGameDsl.g:267:2: ( ( rule__AnySimpleType__Alternatives ) )
            // InternalGameDsl.g:268:3: ( rule__AnySimpleType__Alternatives )
            {
             before(grammarAccess.getAnySimpleTypeAccess().getAlternatives()); 
            // InternalGameDsl.g:269:3: ( rule__AnySimpleType__Alternatives )
            // InternalGameDsl.g:269:4: rule__AnySimpleType__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__AnySimpleType__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getAnySimpleTypeAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleAnySimpleType"


    // $ANTLR start "entryRuleEInt"
    // InternalGameDsl.g:278:1: entryRuleEInt : ruleEInt EOF ;
    public final void entryRuleEInt() throws RecognitionException {
        try {
            // InternalGameDsl.g:279:1: ( ruleEInt EOF )
            // InternalGameDsl.g:280:1: ruleEInt EOF
            {
             before(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getEIntRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalGameDsl.g:287:1: ruleEInt : ( ( rule__EInt__Group__0 ) ) ;
    public final void ruleEInt() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:291:2: ( ( ( rule__EInt__Group__0 ) ) )
            // InternalGameDsl.g:292:2: ( ( rule__EInt__Group__0 ) )
            {
            // InternalGameDsl.g:292:2: ( ( rule__EInt__Group__0 ) )
            // InternalGameDsl.g:293:3: ( rule__EInt__Group__0 )
            {
             before(grammarAccess.getEIntAccess().getGroup()); 
            // InternalGameDsl.g:294:3: ( rule__EInt__Group__0 )
            // InternalGameDsl.g:294:4: rule__EInt__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EInt__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEIntAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleEBoolean"
    // InternalGameDsl.g:303:1: entryRuleEBoolean : ruleEBoolean EOF ;
    public final void entryRuleEBoolean() throws RecognitionException {
        try {
            // InternalGameDsl.g:304:1: ( ruleEBoolean EOF )
            // InternalGameDsl.g:305:1: ruleEBoolean EOF
            {
             before(grammarAccess.getEBooleanRule()); 
            pushFollow(FOLLOW_1);
            ruleEBoolean();

            state._fsp--;

             after(grammarAccess.getEBooleanRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEBoolean"


    // $ANTLR start "ruleEBoolean"
    // InternalGameDsl.g:312:1: ruleEBoolean : ( ( rule__EBoolean__Alternatives ) ) ;
    public final void ruleEBoolean() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:316:2: ( ( ( rule__EBoolean__Alternatives ) ) )
            // InternalGameDsl.g:317:2: ( ( rule__EBoolean__Alternatives ) )
            {
            // InternalGameDsl.g:317:2: ( ( rule__EBoolean__Alternatives ) )
            // InternalGameDsl.g:318:3: ( rule__EBoolean__Alternatives )
            {
             before(grammarAccess.getEBooleanAccess().getAlternatives()); 
            // InternalGameDsl.g:319:3: ( rule__EBoolean__Alternatives )
            // InternalGameDsl.g:319:4: rule__EBoolean__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EBoolean__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEBooleanAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEBoolean"


    // $ANTLR start "entryRuleEFloat"
    // InternalGameDsl.g:328:1: entryRuleEFloat : ruleEFloat EOF ;
    public final void entryRuleEFloat() throws RecognitionException {
        try {
            // InternalGameDsl.g:329:1: ( ruleEFloat EOF )
            // InternalGameDsl.g:330:1: ruleEFloat EOF
            {
             before(grammarAccess.getEFloatRule()); 
            pushFollow(FOLLOW_1);
            ruleEFloat();

            state._fsp--;

             after(grammarAccess.getEFloatRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEFloat"


    // $ANTLR start "ruleEFloat"
    // InternalGameDsl.g:337:1: ruleEFloat : ( ( rule__EFloat__Group__0 ) ) ;
    public final void ruleEFloat() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:341:2: ( ( ( rule__EFloat__Group__0 ) ) )
            // InternalGameDsl.g:342:2: ( ( rule__EFloat__Group__0 ) )
            {
            // InternalGameDsl.g:342:2: ( ( rule__EFloat__Group__0 ) )
            // InternalGameDsl.g:343:3: ( rule__EFloat__Group__0 )
            {
             before(grammarAccess.getEFloatAccess().getGroup()); 
            // InternalGameDsl.g:344:3: ( rule__EFloat__Group__0 )
            // InternalGameDsl.g:344:4: rule__EFloat__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EFloat__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEFloatAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEFloat"


    // $ANTLR start "entryRuleEDouble"
    // InternalGameDsl.g:353:1: entryRuleEDouble : ruleEDouble EOF ;
    public final void entryRuleEDouble() throws RecognitionException {
        try {
            // InternalGameDsl.g:354:1: ( ruleEDouble EOF )
            // InternalGameDsl.g:355:1: ruleEDouble EOF
            {
             before(grammarAccess.getEDoubleRule()); 
            pushFollow(FOLLOW_1);
            ruleEDouble();

            state._fsp--;

             after(grammarAccess.getEDoubleRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEDouble"


    // $ANTLR start "ruleEDouble"
    // InternalGameDsl.g:362:1: ruleEDouble : ( ( rule__EDouble__Group__0 ) ) ;
    public final void ruleEDouble() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:366:2: ( ( ( rule__EDouble__Group__0 ) ) )
            // InternalGameDsl.g:367:2: ( ( rule__EDouble__Group__0 ) )
            {
            // InternalGameDsl.g:367:2: ( ( rule__EDouble__Group__0 ) )
            // InternalGameDsl.g:368:3: ( rule__EDouble__Group__0 )
            {
             before(grammarAccess.getEDoubleAccess().getGroup()); 
            // InternalGameDsl.g:369:3: ( rule__EDouble__Group__0 )
            // InternalGameDsl.g:369:4: rule__EDouble__Group__0
            {
            pushFollow(FOLLOW_2);
            rule__EDouble__Group__0();

            state._fsp--;


            }

             after(grammarAccess.getEDoubleAccess().getGroup()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEDouble"


    // $ANTLR start "entryRuleEString"
    // InternalGameDsl.g:378:1: entryRuleEString : ruleEString EOF ;
    public final void entryRuleEString() throws RecognitionException {
        try {
            // InternalGameDsl.g:379:1: ( ruleEString EOF )
            // InternalGameDsl.g:380:1: ruleEString EOF
            {
             before(grammarAccess.getEStringRule()); 
            pushFollow(FOLLOW_1);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getEStringRule()); 
            match(input,EOF,FOLLOW_2); 

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "entryRuleEString"


    // $ANTLR start "ruleEString"
    // InternalGameDsl.g:387:1: ruleEString : ( ( rule__EString__Alternatives ) ) ;
    public final void ruleEString() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:391:2: ( ( ( rule__EString__Alternatives ) ) )
            // InternalGameDsl.g:392:2: ( ( rule__EString__Alternatives ) )
            {
            // InternalGameDsl.g:392:2: ( ( rule__EString__Alternatives ) )
            // InternalGameDsl.g:393:3: ( rule__EString__Alternatives )
            {
             before(grammarAccess.getEStringAccess().getAlternatives()); 
            // InternalGameDsl.g:394:3: ( rule__EString__Alternatives )
            // InternalGameDsl.g:394:4: rule__EString__Alternatives
            {
            pushFollow(FOLLOW_2);
            rule__EString__Alternatives();

            state._fsp--;


            }

             after(grammarAccess.getEStringAccess().getAlternatives()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "ruleEString"


    // $ANTLR start "rule__AnySimpleType__Alternatives"
    // InternalGameDsl.g:402:1: rule__AnySimpleType__Alternatives : ( ( RULE_STRING ) | ( ruleEBoolean ) | ( ruleEFloat ) | ( ruleEInt ) );
    public final void rule__AnySimpleType__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:406:1: ( ( RULE_STRING ) | ( ruleEBoolean ) | ( ruleEFloat ) | ( ruleEInt ) )
            int alt1=4;
            switch ( input.LA(1) ) {
            case RULE_STRING:
                {
                alt1=1;
                }
                break;
            case 11:
            case 12:
                {
                alt1=2;
                }
                break;
            case 55:
                {
                int LA1_3 = input.LA(2);

                if ( (LA1_3==RULE_INT) ) {
                    int LA1_4 = input.LA(3);

                    if ( (LA1_4==56) ) {
                        alt1=3;
                    }
                    else if ( (LA1_4==EOF||LA1_4==19||LA1_4==25) ) {
                        alt1=4;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 1, 4, input);

                        throw nvae;
                    }
                }
                else if ( (LA1_3==56) ) {
                    alt1=3;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 1, 3, input);

                    throw nvae;
                }
                }
                break;
            case RULE_INT:
                {
                int LA1_4 = input.LA(2);

                if ( (LA1_4==56) ) {
                    alt1=3;
                }
                else if ( (LA1_4==EOF||LA1_4==19||LA1_4==25) ) {
                    alt1=4;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 1, 4, input);

                    throw nvae;
                }
                }
                break;
            case 56:
                {
                alt1=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 1, 0, input);

                throw nvae;
            }

            switch (alt1) {
                case 1 :
                    // InternalGameDsl.g:407:2: ( RULE_STRING )
                    {
                    // InternalGameDsl.g:407:2: ( RULE_STRING )
                    // InternalGameDsl.g:408:3: RULE_STRING
                    {
                     before(grammarAccess.getAnySimpleTypeAccess().getSTRINGTerminalRuleCall_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getAnySimpleTypeAccess().getSTRINGTerminalRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGameDsl.g:413:2: ( ruleEBoolean )
                    {
                    // InternalGameDsl.g:413:2: ( ruleEBoolean )
                    // InternalGameDsl.g:414:3: ruleEBoolean
                    {
                     before(grammarAccess.getAnySimpleTypeAccess().getEBooleanParserRuleCall_1()); 
                    pushFollow(FOLLOW_2);
                    ruleEBoolean();

                    state._fsp--;

                     after(grammarAccess.getAnySimpleTypeAccess().getEBooleanParserRuleCall_1()); 

                    }


                    }
                    break;
                case 3 :
                    // InternalGameDsl.g:419:2: ( ruleEFloat )
                    {
                    // InternalGameDsl.g:419:2: ( ruleEFloat )
                    // InternalGameDsl.g:420:3: ruleEFloat
                    {
                     before(grammarAccess.getAnySimpleTypeAccess().getEFloatParserRuleCall_2()); 
                    pushFollow(FOLLOW_2);
                    ruleEFloat();

                    state._fsp--;

                     after(grammarAccess.getAnySimpleTypeAccess().getEFloatParserRuleCall_2()); 

                    }


                    }
                    break;
                case 4 :
                    // InternalGameDsl.g:425:2: ( ruleEInt )
                    {
                    // InternalGameDsl.g:425:2: ( ruleEInt )
                    // InternalGameDsl.g:426:3: ruleEInt
                    {
                     before(grammarAccess.getAnySimpleTypeAccess().getEIntParserRuleCall_3()); 
                    pushFollow(FOLLOW_2);
                    ruleEInt();

                    state._fsp--;

                     after(grammarAccess.getAnySimpleTypeAccess().getEIntParserRuleCall_3()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__AnySimpleType__Alternatives"


    // $ANTLR start "rule__EBoolean__Alternatives"
    // InternalGameDsl.g:435:1: rule__EBoolean__Alternatives : ( ( 'true' ) | ( 'false' ) );
    public final void rule__EBoolean__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:439:1: ( ( 'true' ) | ( 'false' ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==11) ) {
                alt2=1;
            }
            else if ( (LA2_0==12) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalGameDsl.g:440:2: ( 'true' )
                    {
                    // InternalGameDsl.g:440:2: ( 'true' )
                    // InternalGameDsl.g:441:3: 'true'
                    {
                     before(grammarAccess.getEBooleanAccess().getTrueKeyword_0()); 
                    match(input,11,FOLLOW_2); 
                     after(grammarAccess.getEBooleanAccess().getTrueKeyword_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGameDsl.g:446:2: ( 'false' )
                    {
                    // InternalGameDsl.g:446:2: ( 'false' )
                    // InternalGameDsl.g:447:3: 'false'
                    {
                     before(grammarAccess.getEBooleanAccess().getFalseKeyword_1()); 
                    match(input,12,FOLLOW_2); 
                     after(grammarAccess.getEBooleanAccess().getFalseKeyword_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EBoolean__Alternatives"


    // $ANTLR start "rule__EFloat__Alternatives_4_0"
    // InternalGameDsl.g:456:1: rule__EFloat__Alternatives_4_0 : ( ( 'E' ) | ( 'e' ) );
    public final void rule__EFloat__Alternatives_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:460:1: ( ( 'E' ) | ( 'e' ) )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==13) ) {
                alt3=1;
            }
            else if ( (LA3_0==14) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalGameDsl.g:461:2: ( 'E' )
                    {
                    // InternalGameDsl.g:461:2: ( 'E' )
                    // InternalGameDsl.g:462:3: 'E'
                    {
                     before(grammarAccess.getEFloatAccess().getEKeyword_4_0_0()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getEFloatAccess().getEKeyword_4_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGameDsl.g:467:2: ( 'e' )
                    {
                    // InternalGameDsl.g:467:2: ( 'e' )
                    // InternalGameDsl.g:468:3: 'e'
                    {
                     before(grammarAccess.getEFloatAccess().getEKeyword_4_0_1()); 
                    match(input,14,FOLLOW_2); 
                     after(grammarAccess.getEFloatAccess().getEKeyword_4_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Alternatives_4_0"


    // $ANTLR start "rule__EDouble__Alternatives_4_0"
    // InternalGameDsl.g:477:1: rule__EDouble__Alternatives_4_0 : ( ( 'E' ) | ( 'e' ) );
    public final void rule__EDouble__Alternatives_4_0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:481:1: ( ( 'E' ) | ( 'e' ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==13) ) {
                alt4=1;
            }
            else if ( (LA4_0==14) ) {
                alt4=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // InternalGameDsl.g:482:2: ( 'E' )
                    {
                    // InternalGameDsl.g:482:2: ( 'E' )
                    // InternalGameDsl.g:483:3: 'E'
                    {
                     before(grammarAccess.getEDoubleAccess().getEKeyword_4_0_0()); 
                    match(input,13,FOLLOW_2); 
                     after(grammarAccess.getEDoubleAccess().getEKeyword_4_0_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGameDsl.g:488:2: ( 'e' )
                    {
                    // InternalGameDsl.g:488:2: ( 'e' )
                    // InternalGameDsl.g:489:3: 'e'
                    {
                     before(grammarAccess.getEDoubleAccess().getEKeyword_4_0_1()); 
                    match(input,14,FOLLOW_2); 
                     after(grammarAccess.getEDoubleAccess().getEKeyword_4_0_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Alternatives_4_0"


    // $ANTLR start "rule__EString__Alternatives"
    // InternalGameDsl.g:498:1: rule__EString__Alternatives : ( ( RULE_STRING ) | ( RULE_ID ) );
    public final void rule__EString__Alternatives() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:502:1: ( ( RULE_STRING ) | ( RULE_ID ) )
            int alt5=2;
            int LA5_0 = input.LA(1);

            if ( (LA5_0==RULE_STRING) ) {
                alt5=1;
            }
            else if ( (LA5_0==RULE_ID) ) {
                alt5=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 5, 0, input);

                throw nvae;
            }
            switch (alt5) {
                case 1 :
                    // InternalGameDsl.g:503:2: ( RULE_STRING )
                    {
                    // InternalGameDsl.g:503:2: ( RULE_STRING )
                    // InternalGameDsl.g:504:3: RULE_STRING
                    {
                     before(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 
                    match(input,RULE_STRING,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getSTRINGTerminalRuleCall_0()); 

                    }


                    }
                    break;
                case 2 :
                    // InternalGameDsl.g:509:2: ( RULE_ID )
                    {
                    // InternalGameDsl.g:509:2: ( RULE_ID )
                    // InternalGameDsl.g:510:3: RULE_ID
                    {
                     before(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 
                    match(input,RULE_ID,FOLLOW_2); 
                     after(grammarAccess.getEStringAccess().getIDTerminalRuleCall_1()); 

                    }


                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EString__Alternatives"


    // $ANTLR start "rule__Game__Group__0"
    // InternalGameDsl.g:519:1: rule__Game__Group__0 : rule__Game__Group__0__Impl rule__Game__Group__1 ;
    public final void rule__Game__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:523:1: ( rule__Game__Group__0__Impl rule__Game__Group__1 )
            // InternalGameDsl.g:524:2: rule__Game__Group__0__Impl rule__Game__Group__1
            {
            pushFollow(FOLLOW_3);
            rule__Game__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__0"


    // $ANTLR start "rule__Game__Group__0__Impl"
    // InternalGameDsl.g:531:1: rule__Game__Group__0__Impl : ( () ) ;
    public final void rule__Game__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:535:1: ( ( () ) )
            // InternalGameDsl.g:536:1: ( () )
            {
            // InternalGameDsl.g:536:1: ( () )
            // InternalGameDsl.g:537:2: ()
            {
             before(grammarAccess.getGameAccess().getGameAction_0()); 
            // InternalGameDsl.g:538:2: ()
            // InternalGameDsl.g:538:3: 
            {
            }

             after(grammarAccess.getGameAccess().getGameAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__0__Impl"


    // $ANTLR start "rule__Game__Group__1"
    // InternalGameDsl.g:546:1: rule__Game__Group__1 : rule__Game__Group__1__Impl rule__Game__Group__2 ;
    public final void rule__Game__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:550:1: ( rule__Game__Group__1__Impl rule__Game__Group__2 )
            // InternalGameDsl.g:551:2: rule__Game__Group__1__Impl rule__Game__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__Game__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__1"


    // $ANTLR start "rule__Game__Group__1__Impl"
    // InternalGameDsl.g:558:1: rule__Game__Group__1__Impl : ( 'Game' ) ;
    public final void rule__Game__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:562:1: ( ( 'Game' ) )
            // InternalGameDsl.g:563:1: ( 'Game' )
            {
            // InternalGameDsl.g:563:1: ( 'Game' )
            // InternalGameDsl.g:564:2: 'Game'
            {
             before(grammarAccess.getGameAccess().getGameKeyword_1()); 
            match(input,15,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getGameKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__1__Impl"


    // $ANTLR start "rule__Game__Group__2"
    // InternalGameDsl.g:573:1: rule__Game__Group__2 : rule__Game__Group__2__Impl rule__Game__Group__3 ;
    public final void rule__Game__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:577:1: ( rule__Game__Group__2__Impl rule__Game__Group__3 )
            // InternalGameDsl.g:578:2: rule__Game__Group__2__Impl rule__Game__Group__3
            {
            pushFollow(FOLLOW_4);
            rule__Game__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__2"


    // $ANTLR start "rule__Game__Group__2__Impl"
    // InternalGameDsl.g:585:1: rule__Game__Group__2__Impl : ( ( rule__Game__NameAssignment_2 ) ) ;
    public final void rule__Game__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:589:1: ( ( ( rule__Game__NameAssignment_2 ) ) )
            // InternalGameDsl.g:590:1: ( ( rule__Game__NameAssignment_2 ) )
            {
            // InternalGameDsl.g:590:1: ( ( rule__Game__NameAssignment_2 ) )
            // InternalGameDsl.g:591:2: ( rule__Game__NameAssignment_2 )
            {
             before(grammarAccess.getGameAccess().getNameAssignment_2()); 
            // InternalGameDsl.g:592:2: ( rule__Game__NameAssignment_2 )
            // InternalGameDsl.g:592:3: rule__Game__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__Game__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getGameAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__2__Impl"


    // $ANTLR start "rule__Game__Group__3"
    // InternalGameDsl.g:600:1: rule__Game__Group__3 : rule__Game__Group__3__Impl rule__Game__Group__4 ;
    public final void rule__Game__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:604:1: ( rule__Game__Group__3__Impl rule__Game__Group__4 )
            // InternalGameDsl.g:605:2: rule__Game__Group__3__Impl rule__Game__Group__4
            {
            pushFollow(FOLLOW_5);
            rule__Game__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__3"


    // $ANTLR start "rule__Game__Group__3__Impl"
    // InternalGameDsl.g:612:1: rule__Game__Group__3__Impl : ( ( rule__Game__DescriptionAssignment_3 ) ) ;
    public final void rule__Game__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:616:1: ( ( ( rule__Game__DescriptionAssignment_3 ) ) )
            // InternalGameDsl.g:617:1: ( ( rule__Game__DescriptionAssignment_3 ) )
            {
            // InternalGameDsl.g:617:1: ( ( rule__Game__DescriptionAssignment_3 ) )
            // InternalGameDsl.g:618:2: ( rule__Game__DescriptionAssignment_3 )
            {
             before(grammarAccess.getGameAccess().getDescriptionAssignment_3()); 
            // InternalGameDsl.g:619:2: ( rule__Game__DescriptionAssignment_3 )
            // InternalGameDsl.g:619:3: rule__Game__DescriptionAssignment_3
            {
            pushFollow(FOLLOW_2);
            rule__Game__DescriptionAssignment_3();

            state._fsp--;


            }

             after(grammarAccess.getGameAccess().getDescriptionAssignment_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__3__Impl"


    // $ANTLR start "rule__Game__Group__4"
    // InternalGameDsl.g:627:1: rule__Game__Group__4 : rule__Game__Group__4__Impl rule__Game__Group__5 ;
    public final void rule__Game__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:631:1: ( rule__Game__Group__4__Impl rule__Game__Group__5 )
            // InternalGameDsl.g:632:2: rule__Game__Group__4__Impl rule__Game__Group__5
            {
            pushFollow(FOLLOW_6);
            rule__Game__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__4"


    // $ANTLR start "rule__Game__Group__4__Impl"
    // InternalGameDsl.g:639:1: rule__Game__Group__4__Impl : ( '{' ) ;
    public final void rule__Game__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:643:1: ( ( '{' ) )
            // InternalGameDsl.g:644:1: ( '{' )
            {
            // InternalGameDsl.g:644:1: ( '{' )
            // InternalGameDsl.g:645:2: '{'
            {
             before(grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_4()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__4__Impl"


    // $ANTLR start "rule__Game__Group__5"
    // InternalGameDsl.g:654:1: rule__Game__Group__5 : rule__Game__Group__5__Impl rule__Game__Group__6 ;
    public final void rule__Game__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:658:1: ( rule__Game__Group__5__Impl rule__Game__Group__6 )
            // InternalGameDsl.g:659:2: rule__Game__Group__5__Impl rule__Game__Group__6
            {
            pushFollow(FOLLOW_6);
            rule__Game__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__5"


    // $ANTLR start "rule__Game__Group__5__Impl"
    // InternalGameDsl.g:666:1: rule__Game__Group__5__Impl : ( ( rule__Game__Group_5__0 )? ) ;
    public final void rule__Game__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:670:1: ( ( ( rule__Game__Group_5__0 )? ) )
            // InternalGameDsl.g:671:1: ( ( rule__Game__Group_5__0 )? )
            {
            // InternalGameDsl.g:671:1: ( ( rule__Game__Group_5__0 )? )
            // InternalGameDsl.g:672:2: ( rule__Game__Group_5__0 )?
            {
             before(grammarAccess.getGameAccess().getGroup_5()); 
            // InternalGameDsl.g:673:2: ( rule__Game__Group_5__0 )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==18) ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // InternalGameDsl.g:673:3: rule__Game__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Game__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__5__Impl"


    // $ANTLR start "rule__Game__Group__6"
    // InternalGameDsl.g:681:1: rule__Game__Group__6 : rule__Game__Group__6__Impl rule__Game__Group__7 ;
    public final void rule__Game__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:685:1: ( rule__Game__Group__6__Impl rule__Game__Group__7 )
            // InternalGameDsl.g:686:2: rule__Game__Group__6__Impl rule__Game__Group__7
            {
            pushFollow(FOLLOW_6);
            rule__Game__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__6"


    // $ANTLR start "rule__Game__Group__6__Impl"
    // InternalGameDsl.g:693:1: rule__Game__Group__6__Impl : ( ( rule__Game__Group_6__0 )? ) ;
    public final void rule__Game__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:697:1: ( ( ( rule__Game__Group_6__0 )? ) )
            // InternalGameDsl.g:698:1: ( ( rule__Game__Group_6__0 )? )
            {
            // InternalGameDsl.g:698:1: ( ( rule__Game__Group_6__0 )? )
            // InternalGameDsl.g:699:2: ( rule__Game__Group_6__0 )?
            {
             before(grammarAccess.getGameAccess().getGroup_6()); 
            // InternalGameDsl.g:700:2: ( rule__Game__Group_6__0 )?
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==20) ) {
                alt7=1;
            }
            switch (alt7) {
                case 1 :
                    // InternalGameDsl.g:700:3: rule__Game__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Game__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__6__Impl"


    // $ANTLR start "rule__Game__Group__7"
    // InternalGameDsl.g:708:1: rule__Game__Group__7 : rule__Game__Group__7__Impl rule__Game__Group__8 ;
    public final void rule__Game__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:712:1: ( rule__Game__Group__7__Impl rule__Game__Group__8 )
            // InternalGameDsl.g:713:2: rule__Game__Group__7__Impl rule__Game__Group__8
            {
            pushFollow(FOLLOW_6);
            rule__Game__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__7"


    // $ANTLR start "rule__Game__Group__7__Impl"
    // InternalGameDsl.g:720:1: rule__Game__Group__7__Impl : ( ( rule__Game__Group_7__0 )? ) ;
    public final void rule__Game__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:724:1: ( ( ( rule__Game__Group_7__0 )? ) )
            // InternalGameDsl.g:725:1: ( ( rule__Game__Group_7__0 )? )
            {
            // InternalGameDsl.g:725:1: ( ( rule__Game__Group_7__0 )? )
            // InternalGameDsl.g:726:2: ( rule__Game__Group_7__0 )?
            {
             before(grammarAccess.getGameAccess().getGroup_7()); 
            // InternalGameDsl.g:727:2: ( rule__Game__Group_7__0 )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==21) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalGameDsl.g:727:3: rule__Game__Group_7__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Game__Group_7__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameAccess().getGroup_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__7__Impl"


    // $ANTLR start "rule__Game__Group__8"
    // InternalGameDsl.g:735:1: rule__Game__Group__8 : rule__Game__Group__8__Impl ;
    public final void rule__Game__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:739:1: ( rule__Game__Group__8__Impl )
            // InternalGameDsl.g:740:2: rule__Game__Group__8__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Game__Group__8__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__8"


    // $ANTLR start "rule__Game__Group__8__Impl"
    // InternalGameDsl.g:746:1: rule__Game__Group__8__Impl : ( '}' ) ;
    public final void rule__Game__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:750:1: ( ( '}' ) )
            // InternalGameDsl.g:751:1: ( '}' )
            {
            // InternalGameDsl.g:751:1: ( '}' )
            // InternalGameDsl.g:752:2: '}'
            {
             before(grammarAccess.getGameAccess().getRightCurlyBracketKeyword_8()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getRightCurlyBracketKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group__8__Impl"


    // $ANTLR start "rule__Game__Group_5__0"
    // InternalGameDsl.g:762:1: rule__Game__Group_5__0 : rule__Game__Group_5__0__Impl rule__Game__Group_5__1 ;
    public final void rule__Game__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:766:1: ( rule__Game__Group_5__0__Impl rule__Game__Group_5__1 )
            // InternalGameDsl.g:767:2: rule__Game__Group_5__0__Impl rule__Game__Group_5__1
            {
            pushFollow(FOLLOW_5);
            rule__Game__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5__0"


    // $ANTLR start "rule__Game__Group_5__0__Impl"
    // InternalGameDsl.g:774:1: rule__Game__Group_5__0__Impl : ( 'background' ) ;
    public final void rule__Game__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:778:1: ( ( 'background' ) )
            // InternalGameDsl.g:779:1: ( 'background' )
            {
            // InternalGameDsl.g:779:1: ( 'background' )
            // InternalGameDsl.g:780:2: 'background'
            {
             before(grammarAccess.getGameAccess().getBackgroundKeyword_5_0()); 
            match(input,18,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getBackgroundKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5__0__Impl"


    // $ANTLR start "rule__Game__Group_5__1"
    // InternalGameDsl.g:789:1: rule__Game__Group_5__1 : rule__Game__Group_5__1__Impl rule__Game__Group_5__2 ;
    public final void rule__Game__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:793:1: ( rule__Game__Group_5__1__Impl rule__Game__Group_5__2 )
            // InternalGameDsl.g:794:2: rule__Game__Group_5__1__Impl rule__Game__Group_5__2
            {
            pushFollow(FOLLOW_7);
            rule__Game__Group_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5__1"


    // $ANTLR start "rule__Game__Group_5__1__Impl"
    // InternalGameDsl.g:801:1: rule__Game__Group_5__1__Impl : ( '{' ) ;
    public final void rule__Game__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:805:1: ( ( '{' ) )
            // InternalGameDsl.g:806:1: ( '{' )
            {
            // InternalGameDsl.g:806:1: ( '{' )
            // InternalGameDsl.g:807:2: '{'
            {
             before(grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_5_1()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5__1__Impl"


    // $ANTLR start "rule__Game__Group_5__2"
    // InternalGameDsl.g:816:1: rule__Game__Group_5__2 : rule__Game__Group_5__2__Impl rule__Game__Group_5__3 ;
    public final void rule__Game__Group_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:820:1: ( rule__Game__Group_5__2__Impl rule__Game__Group_5__3 )
            // InternalGameDsl.g:821:2: rule__Game__Group_5__2__Impl rule__Game__Group_5__3
            {
            pushFollow(FOLLOW_8);
            rule__Game__Group_5__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_5__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5__2"


    // $ANTLR start "rule__Game__Group_5__2__Impl"
    // InternalGameDsl.g:828:1: rule__Game__Group_5__2__Impl : ( ( rule__Game__BackgroundAssignment_5_2 ) ) ;
    public final void rule__Game__Group_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:832:1: ( ( ( rule__Game__BackgroundAssignment_5_2 ) ) )
            // InternalGameDsl.g:833:1: ( ( rule__Game__BackgroundAssignment_5_2 ) )
            {
            // InternalGameDsl.g:833:1: ( ( rule__Game__BackgroundAssignment_5_2 ) )
            // InternalGameDsl.g:834:2: ( rule__Game__BackgroundAssignment_5_2 )
            {
             before(grammarAccess.getGameAccess().getBackgroundAssignment_5_2()); 
            // InternalGameDsl.g:835:2: ( rule__Game__BackgroundAssignment_5_2 )
            // InternalGameDsl.g:835:3: rule__Game__BackgroundAssignment_5_2
            {
            pushFollow(FOLLOW_2);
            rule__Game__BackgroundAssignment_5_2();

            state._fsp--;


            }

             after(grammarAccess.getGameAccess().getBackgroundAssignment_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5__2__Impl"


    // $ANTLR start "rule__Game__Group_5__3"
    // InternalGameDsl.g:843:1: rule__Game__Group_5__3 : rule__Game__Group_5__3__Impl rule__Game__Group_5__4 ;
    public final void rule__Game__Group_5__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:847:1: ( rule__Game__Group_5__3__Impl rule__Game__Group_5__4 )
            // InternalGameDsl.g:848:2: rule__Game__Group_5__3__Impl rule__Game__Group_5__4
            {
            pushFollow(FOLLOW_8);
            rule__Game__Group_5__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_5__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5__3"


    // $ANTLR start "rule__Game__Group_5__3__Impl"
    // InternalGameDsl.g:855:1: rule__Game__Group_5__3__Impl : ( ( rule__Game__Group_5_3__0 )* ) ;
    public final void rule__Game__Group_5__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:859:1: ( ( ( rule__Game__Group_5_3__0 )* ) )
            // InternalGameDsl.g:860:1: ( ( rule__Game__Group_5_3__0 )* )
            {
            // InternalGameDsl.g:860:1: ( ( rule__Game__Group_5_3__0 )* )
            // InternalGameDsl.g:861:2: ( rule__Game__Group_5_3__0 )*
            {
             before(grammarAccess.getGameAccess().getGroup_5_3()); 
            // InternalGameDsl.g:862:2: ( rule__Game__Group_5_3__0 )*
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( (LA9_0==19) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // InternalGameDsl.g:862:3: rule__Game__Group_5_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Game__Group_5_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop9;
                }
            } while (true);

             after(grammarAccess.getGameAccess().getGroup_5_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5__3__Impl"


    // $ANTLR start "rule__Game__Group_5__4"
    // InternalGameDsl.g:870:1: rule__Game__Group_5__4 : rule__Game__Group_5__4__Impl ;
    public final void rule__Game__Group_5__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:874:1: ( rule__Game__Group_5__4__Impl )
            // InternalGameDsl.g:875:2: rule__Game__Group_5__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Game__Group_5__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5__4"


    // $ANTLR start "rule__Game__Group_5__4__Impl"
    // InternalGameDsl.g:881:1: rule__Game__Group_5__4__Impl : ( '}' ) ;
    public final void rule__Game__Group_5__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:885:1: ( ( '}' ) )
            // InternalGameDsl.g:886:1: ( '}' )
            {
            // InternalGameDsl.g:886:1: ( '}' )
            // InternalGameDsl.g:887:2: '}'
            {
             before(grammarAccess.getGameAccess().getRightCurlyBracketKeyword_5_4()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getRightCurlyBracketKeyword_5_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5__4__Impl"


    // $ANTLR start "rule__Game__Group_5_3__0"
    // InternalGameDsl.g:897:1: rule__Game__Group_5_3__0 : rule__Game__Group_5_3__0__Impl rule__Game__Group_5_3__1 ;
    public final void rule__Game__Group_5_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:901:1: ( rule__Game__Group_5_3__0__Impl rule__Game__Group_5_3__1 )
            // InternalGameDsl.g:902:2: rule__Game__Group_5_3__0__Impl rule__Game__Group_5_3__1
            {
            pushFollow(FOLLOW_7);
            rule__Game__Group_5_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_5_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5_3__0"


    // $ANTLR start "rule__Game__Group_5_3__0__Impl"
    // InternalGameDsl.g:909:1: rule__Game__Group_5_3__0__Impl : ( ',' ) ;
    public final void rule__Game__Group_5_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:913:1: ( ( ',' ) )
            // InternalGameDsl.g:914:1: ( ',' )
            {
            // InternalGameDsl.g:914:1: ( ',' )
            // InternalGameDsl.g:915:2: ','
            {
             before(grammarAccess.getGameAccess().getCommaKeyword_5_3_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getCommaKeyword_5_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5_3__0__Impl"


    // $ANTLR start "rule__Game__Group_5_3__1"
    // InternalGameDsl.g:924:1: rule__Game__Group_5_3__1 : rule__Game__Group_5_3__1__Impl ;
    public final void rule__Game__Group_5_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:928:1: ( rule__Game__Group_5_3__1__Impl )
            // InternalGameDsl.g:929:2: rule__Game__Group_5_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Game__Group_5_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5_3__1"


    // $ANTLR start "rule__Game__Group_5_3__1__Impl"
    // InternalGameDsl.g:935:1: rule__Game__Group_5_3__1__Impl : ( ( rule__Game__BackgroundAssignment_5_3_1 ) ) ;
    public final void rule__Game__Group_5_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:939:1: ( ( ( rule__Game__BackgroundAssignment_5_3_1 ) ) )
            // InternalGameDsl.g:940:1: ( ( rule__Game__BackgroundAssignment_5_3_1 ) )
            {
            // InternalGameDsl.g:940:1: ( ( rule__Game__BackgroundAssignment_5_3_1 ) )
            // InternalGameDsl.g:941:2: ( rule__Game__BackgroundAssignment_5_3_1 )
            {
             before(grammarAccess.getGameAccess().getBackgroundAssignment_5_3_1()); 
            // InternalGameDsl.g:942:2: ( rule__Game__BackgroundAssignment_5_3_1 )
            // InternalGameDsl.g:942:3: rule__Game__BackgroundAssignment_5_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Game__BackgroundAssignment_5_3_1();

            state._fsp--;


            }

             after(grammarAccess.getGameAccess().getBackgroundAssignment_5_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_5_3__1__Impl"


    // $ANTLR start "rule__Game__Group_6__0"
    // InternalGameDsl.g:951:1: rule__Game__Group_6__0 : rule__Game__Group_6__0__Impl rule__Game__Group_6__1 ;
    public final void rule__Game__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:955:1: ( rule__Game__Group_6__0__Impl rule__Game__Group_6__1 )
            // InternalGameDsl.g:956:2: rule__Game__Group_6__0__Impl rule__Game__Group_6__1
            {
            pushFollow(FOLLOW_5);
            rule__Game__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6__0"


    // $ANTLR start "rule__Game__Group_6__0__Impl"
    // InternalGameDsl.g:963:1: rule__Game__Group_6__0__Impl : ( 'objectType' ) ;
    public final void rule__Game__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:967:1: ( ( 'objectType' ) )
            // InternalGameDsl.g:968:1: ( 'objectType' )
            {
            // InternalGameDsl.g:968:1: ( 'objectType' )
            // InternalGameDsl.g:969:2: 'objectType'
            {
             before(grammarAccess.getGameAccess().getObjectTypeKeyword_6_0()); 
            match(input,20,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getObjectTypeKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6__0__Impl"


    // $ANTLR start "rule__Game__Group_6__1"
    // InternalGameDsl.g:978:1: rule__Game__Group_6__1 : rule__Game__Group_6__1__Impl rule__Game__Group_6__2 ;
    public final void rule__Game__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:982:1: ( rule__Game__Group_6__1__Impl rule__Game__Group_6__2 )
            // InternalGameDsl.g:983:2: rule__Game__Group_6__1__Impl rule__Game__Group_6__2
            {
            pushFollow(FOLLOW_10);
            rule__Game__Group_6__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_6__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6__1"


    // $ANTLR start "rule__Game__Group_6__1__Impl"
    // InternalGameDsl.g:990:1: rule__Game__Group_6__1__Impl : ( '{' ) ;
    public final void rule__Game__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:994:1: ( ( '{' ) )
            // InternalGameDsl.g:995:1: ( '{' )
            {
            // InternalGameDsl.g:995:1: ( '{' )
            // InternalGameDsl.g:996:2: '{'
            {
             before(grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_6_1()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6__1__Impl"


    // $ANTLR start "rule__Game__Group_6__2"
    // InternalGameDsl.g:1005:1: rule__Game__Group_6__2 : rule__Game__Group_6__2__Impl rule__Game__Group_6__3 ;
    public final void rule__Game__Group_6__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1009:1: ( rule__Game__Group_6__2__Impl rule__Game__Group_6__3 )
            // InternalGameDsl.g:1010:2: rule__Game__Group_6__2__Impl rule__Game__Group_6__3
            {
            pushFollow(FOLLOW_8);
            rule__Game__Group_6__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_6__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6__2"


    // $ANTLR start "rule__Game__Group_6__2__Impl"
    // InternalGameDsl.g:1017:1: rule__Game__Group_6__2__Impl : ( ( rule__Game__ObjectTypeAssignment_6_2 ) ) ;
    public final void rule__Game__Group_6__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1021:1: ( ( ( rule__Game__ObjectTypeAssignment_6_2 ) ) )
            // InternalGameDsl.g:1022:1: ( ( rule__Game__ObjectTypeAssignment_6_2 ) )
            {
            // InternalGameDsl.g:1022:1: ( ( rule__Game__ObjectTypeAssignment_6_2 ) )
            // InternalGameDsl.g:1023:2: ( rule__Game__ObjectTypeAssignment_6_2 )
            {
             before(grammarAccess.getGameAccess().getObjectTypeAssignment_6_2()); 
            // InternalGameDsl.g:1024:2: ( rule__Game__ObjectTypeAssignment_6_2 )
            // InternalGameDsl.g:1024:3: rule__Game__ObjectTypeAssignment_6_2
            {
            pushFollow(FOLLOW_2);
            rule__Game__ObjectTypeAssignment_6_2();

            state._fsp--;


            }

             after(grammarAccess.getGameAccess().getObjectTypeAssignment_6_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6__2__Impl"


    // $ANTLR start "rule__Game__Group_6__3"
    // InternalGameDsl.g:1032:1: rule__Game__Group_6__3 : rule__Game__Group_6__3__Impl rule__Game__Group_6__4 ;
    public final void rule__Game__Group_6__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1036:1: ( rule__Game__Group_6__3__Impl rule__Game__Group_6__4 )
            // InternalGameDsl.g:1037:2: rule__Game__Group_6__3__Impl rule__Game__Group_6__4
            {
            pushFollow(FOLLOW_8);
            rule__Game__Group_6__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_6__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6__3"


    // $ANTLR start "rule__Game__Group_6__3__Impl"
    // InternalGameDsl.g:1044:1: rule__Game__Group_6__3__Impl : ( ( rule__Game__Group_6_3__0 )* ) ;
    public final void rule__Game__Group_6__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1048:1: ( ( ( rule__Game__Group_6_3__0 )* ) )
            // InternalGameDsl.g:1049:1: ( ( rule__Game__Group_6_3__0 )* )
            {
            // InternalGameDsl.g:1049:1: ( ( rule__Game__Group_6_3__0 )* )
            // InternalGameDsl.g:1050:2: ( rule__Game__Group_6_3__0 )*
            {
             before(grammarAccess.getGameAccess().getGroup_6_3()); 
            // InternalGameDsl.g:1051:2: ( rule__Game__Group_6_3__0 )*
            loop10:
            do {
                int alt10=2;
                int LA10_0 = input.LA(1);

                if ( (LA10_0==19) ) {
                    alt10=1;
                }


                switch (alt10) {
            	case 1 :
            	    // InternalGameDsl.g:1051:3: rule__Game__Group_6_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Game__Group_6_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);

             after(grammarAccess.getGameAccess().getGroup_6_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6__3__Impl"


    // $ANTLR start "rule__Game__Group_6__4"
    // InternalGameDsl.g:1059:1: rule__Game__Group_6__4 : rule__Game__Group_6__4__Impl ;
    public final void rule__Game__Group_6__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1063:1: ( rule__Game__Group_6__4__Impl )
            // InternalGameDsl.g:1064:2: rule__Game__Group_6__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Game__Group_6__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6__4"


    // $ANTLR start "rule__Game__Group_6__4__Impl"
    // InternalGameDsl.g:1070:1: rule__Game__Group_6__4__Impl : ( '}' ) ;
    public final void rule__Game__Group_6__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1074:1: ( ( '}' ) )
            // InternalGameDsl.g:1075:1: ( '}' )
            {
            // InternalGameDsl.g:1075:1: ( '}' )
            // InternalGameDsl.g:1076:2: '}'
            {
             before(grammarAccess.getGameAccess().getRightCurlyBracketKeyword_6_4()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getRightCurlyBracketKeyword_6_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6__4__Impl"


    // $ANTLR start "rule__Game__Group_6_3__0"
    // InternalGameDsl.g:1086:1: rule__Game__Group_6_3__0 : rule__Game__Group_6_3__0__Impl rule__Game__Group_6_3__1 ;
    public final void rule__Game__Group_6_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1090:1: ( rule__Game__Group_6_3__0__Impl rule__Game__Group_6_3__1 )
            // InternalGameDsl.g:1091:2: rule__Game__Group_6_3__0__Impl rule__Game__Group_6_3__1
            {
            pushFollow(FOLLOW_10);
            rule__Game__Group_6_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_6_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6_3__0"


    // $ANTLR start "rule__Game__Group_6_3__0__Impl"
    // InternalGameDsl.g:1098:1: rule__Game__Group_6_3__0__Impl : ( ',' ) ;
    public final void rule__Game__Group_6_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1102:1: ( ( ',' ) )
            // InternalGameDsl.g:1103:1: ( ',' )
            {
            // InternalGameDsl.g:1103:1: ( ',' )
            // InternalGameDsl.g:1104:2: ','
            {
             before(grammarAccess.getGameAccess().getCommaKeyword_6_3_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getCommaKeyword_6_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6_3__0__Impl"


    // $ANTLR start "rule__Game__Group_6_3__1"
    // InternalGameDsl.g:1113:1: rule__Game__Group_6_3__1 : rule__Game__Group_6_3__1__Impl ;
    public final void rule__Game__Group_6_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1117:1: ( rule__Game__Group_6_3__1__Impl )
            // InternalGameDsl.g:1118:2: rule__Game__Group_6_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Game__Group_6_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6_3__1"


    // $ANTLR start "rule__Game__Group_6_3__1__Impl"
    // InternalGameDsl.g:1124:1: rule__Game__Group_6_3__1__Impl : ( ( rule__Game__ObjectTypeAssignment_6_3_1 ) ) ;
    public final void rule__Game__Group_6_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1128:1: ( ( ( rule__Game__ObjectTypeAssignment_6_3_1 ) ) )
            // InternalGameDsl.g:1129:1: ( ( rule__Game__ObjectTypeAssignment_6_3_1 ) )
            {
            // InternalGameDsl.g:1129:1: ( ( rule__Game__ObjectTypeAssignment_6_3_1 ) )
            // InternalGameDsl.g:1130:2: ( rule__Game__ObjectTypeAssignment_6_3_1 )
            {
             before(grammarAccess.getGameAccess().getObjectTypeAssignment_6_3_1()); 
            // InternalGameDsl.g:1131:2: ( rule__Game__ObjectTypeAssignment_6_3_1 )
            // InternalGameDsl.g:1131:3: rule__Game__ObjectTypeAssignment_6_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Game__ObjectTypeAssignment_6_3_1();

            state._fsp--;


            }

             after(grammarAccess.getGameAccess().getObjectTypeAssignment_6_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_6_3__1__Impl"


    // $ANTLR start "rule__Game__Group_7__0"
    // InternalGameDsl.g:1140:1: rule__Game__Group_7__0 : rule__Game__Group_7__0__Impl rule__Game__Group_7__1 ;
    public final void rule__Game__Group_7__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1144:1: ( rule__Game__Group_7__0__Impl rule__Game__Group_7__1 )
            // InternalGameDsl.g:1145:2: rule__Game__Group_7__0__Impl rule__Game__Group_7__1
            {
            pushFollow(FOLLOW_5);
            rule__Game__Group_7__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_7__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7__0"


    // $ANTLR start "rule__Game__Group_7__0__Impl"
    // InternalGameDsl.g:1152:1: rule__Game__Group_7__0__Impl : ( 'collisions' ) ;
    public final void rule__Game__Group_7__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1156:1: ( ( 'collisions' ) )
            // InternalGameDsl.g:1157:1: ( 'collisions' )
            {
            // InternalGameDsl.g:1157:1: ( 'collisions' )
            // InternalGameDsl.g:1158:2: 'collisions'
            {
             before(grammarAccess.getGameAccess().getCollisionsKeyword_7_0()); 
            match(input,21,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getCollisionsKeyword_7_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7__0__Impl"


    // $ANTLR start "rule__Game__Group_7__1"
    // InternalGameDsl.g:1167:1: rule__Game__Group_7__1 : rule__Game__Group_7__1__Impl rule__Game__Group_7__2 ;
    public final void rule__Game__Group_7__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1171:1: ( rule__Game__Group_7__1__Impl rule__Game__Group_7__2 )
            // InternalGameDsl.g:1172:2: rule__Game__Group_7__1__Impl rule__Game__Group_7__2
            {
            pushFollow(FOLLOW_11);
            rule__Game__Group_7__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_7__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7__1"


    // $ANTLR start "rule__Game__Group_7__1__Impl"
    // InternalGameDsl.g:1179:1: rule__Game__Group_7__1__Impl : ( '{' ) ;
    public final void rule__Game__Group_7__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1183:1: ( ( '{' ) )
            // InternalGameDsl.g:1184:1: ( '{' )
            {
            // InternalGameDsl.g:1184:1: ( '{' )
            // InternalGameDsl.g:1185:2: '{'
            {
             before(grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_7_1()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getLeftCurlyBracketKeyword_7_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7__1__Impl"


    // $ANTLR start "rule__Game__Group_7__2"
    // InternalGameDsl.g:1194:1: rule__Game__Group_7__2 : rule__Game__Group_7__2__Impl rule__Game__Group_7__3 ;
    public final void rule__Game__Group_7__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1198:1: ( rule__Game__Group_7__2__Impl rule__Game__Group_7__3 )
            // InternalGameDsl.g:1199:2: rule__Game__Group_7__2__Impl rule__Game__Group_7__3
            {
            pushFollow(FOLLOW_8);
            rule__Game__Group_7__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_7__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7__2"


    // $ANTLR start "rule__Game__Group_7__2__Impl"
    // InternalGameDsl.g:1206:1: rule__Game__Group_7__2__Impl : ( ( rule__Game__CollisionsAssignment_7_2 ) ) ;
    public final void rule__Game__Group_7__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1210:1: ( ( ( rule__Game__CollisionsAssignment_7_2 ) ) )
            // InternalGameDsl.g:1211:1: ( ( rule__Game__CollisionsAssignment_7_2 ) )
            {
            // InternalGameDsl.g:1211:1: ( ( rule__Game__CollisionsAssignment_7_2 ) )
            // InternalGameDsl.g:1212:2: ( rule__Game__CollisionsAssignment_7_2 )
            {
             before(grammarAccess.getGameAccess().getCollisionsAssignment_7_2()); 
            // InternalGameDsl.g:1213:2: ( rule__Game__CollisionsAssignment_7_2 )
            // InternalGameDsl.g:1213:3: rule__Game__CollisionsAssignment_7_2
            {
            pushFollow(FOLLOW_2);
            rule__Game__CollisionsAssignment_7_2();

            state._fsp--;


            }

             after(grammarAccess.getGameAccess().getCollisionsAssignment_7_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7__2__Impl"


    // $ANTLR start "rule__Game__Group_7__3"
    // InternalGameDsl.g:1221:1: rule__Game__Group_7__3 : rule__Game__Group_7__3__Impl rule__Game__Group_7__4 ;
    public final void rule__Game__Group_7__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1225:1: ( rule__Game__Group_7__3__Impl rule__Game__Group_7__4 )
            // InternalGameDsl.g:1226:2: rule__Game__Group_7__3__Impl rule__Game__Group_7__4
            {
            pushFollow(FOLLOW_8);
            rule__Game__Group_7__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_7__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7__3"


    // $ANTLR start "rule__Game__Group_7__3__Impl"
    // InternalGameDsl.g:1233:1: rule__Game__Group_7__3__Impl : ( ( rule__Game__Group_7_3__0 )* ) ;
    public final void rule__Game__Group_7__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1237:1: ( ( ( rule__Game__Group_7_3__0 )* ) )
            // InternalGameDsl.g:1238:1: ( ( rule__Game__Group_7_3__0 )* )
            {
            // InternalGameDsl.g:1238:1: ( ( rule__Game__Group_7_3__0 )* )
            // InternalGameDsl.g:1239:2: ( rule__Game__Group_7_3__0 )*
            {
             before(grammarAccess.getGameAccess().getGroup_7_3()); 
            // InternalGameDsl.g:1240:2: ( rule__Game__Group_7_3__0 )*
            loop11:
            do {
                int alt11=2;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==19) ) {
                    alt11=1;
                }


                switch (alt11) {
            	case 1 :
            	    // InternalGameDsl.g:1240:3: rule__Game__Group_7_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Game__Group_7_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);

             after(grammarAccess.getGameAccess().getGroup_7_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7__3__Impl"


    // $ANTLR start "rule__Game__Group_7__4"
    // InternalGameDsl.g:1248:1: rule__Game__Group_7__4 : rule__Game__Group_7__4__Impl ;
    public final void rule__Game__Group_7__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1252:1: ( rule__Game__Group_7__4__Impl )
            // InternalGameDsl.g:1253:2: rule__Game__Group_7__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Game__Group_7__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7__4"


    // $ANTLR start "rule__Game__Group_7__4__Impl"
    // InternalGameDsl.g:1259:1: rule__Game__Group_7__4__Impl : ( '}' ) ;
    public final void rule__Game__Group_7__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1263:1: ( ( '}' ) )
            // InternalGameDsl.g:1264:1: ( '}' )
            {
            // InternalGameDsl.g:1264:1: ( '}' )
            // InternalGameDsl.g:1265:2: '}'
            {
             before(grammarAccess.getGameAccess().getRightCurlyBracketKeyword_7_4()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getRightCurlyBracketKeyword_7_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7__4__Impl"


    // $ANTLR start "rule__Game__Group_7_3__0"
    // InternalGameDsl.g:1275:1: rule__Game__Group_7_3__0 : rule__Game__Group_7_3__0__Impl rule__Game__Group_7_3__1 ;
    public final void rule__Game__Group_7_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1279:1: ( rule__Game__Group_7_3__0__Impl rule__Game__Group_7_3__1 )
            // InternalGameDsl.g:1280:2: rule__Game__Group_7_3__0__Impl rule__Game__Group_7_3__1
            {
            pushFollow(FOLLOW_11);
            rule__Game__Group_7_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Game__Group_7_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7_3__0"


    // $ANTLR start "rule__Game__Group_7_3__0__Impl"
    // InternalGameDsl.g:1287:1: rule__Game__Group_7_3__0__Impl : ( ',' ) ;
    public final void rule__Game__Group_7_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1291:1: ( ( ',' ) )
            // InternalGameDsl.g:1292:1: ( ',' )
            {
            // InternalGameDsl.g:1292:1: ( ',' )
            // InternalGameDsl.g:1293:2: ','
            {
             before(grammarAccess.getGameAccess().getCommaKeyword_7_3_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getGameAccess().getCommaKeyword_7_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7_3__0__Impl"


    // $ANTLR start "rule__Game__Group_7_3__1"
    // InternalGameDsl.g:1302:1: rule__Game__Group_7_3__1 : rule__Game__Group_7_3__1__Impl ;
    public final void rule__Game__Group_7_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1306:1: ( rule__Game__Group_7_3__1__Impl )
            // InternalGameDsl.g:1307:2: rule__Game__Group_7_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Game__Group_7_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7_3__1"


    // $ANTLR start "rule__Game__Group_7_3__1__Impl"
    // InternalGameDsl.g:1313:1: rule__Game__Group_7_3__1__Impl : ( ( rule__Game__CollisionsAssignment_7_3_1 ) ) ;
    public final void rule__Game__Group_7_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1317:1: ( ( ( rule__Game__CollisionsAssignment_7_3_1 ) ) )
            // InternalGameDsl.g:1318:1: ( ( rule__Game__CollisionsAssignment_7_3_1 ) )
            {
            // InternalGameDsl.g:1318:1: ( ( rule__Game__CollisionsAssignment_7_3_1 ) )
            // InternalGameDsl.g:1319:2: ( rule__Game__CollisionsAssignment_7_3_1 )
            {
             before(grammarAccess.getGameAccess().getCollisionsAssignment_7_3_1()); 
            // InternalGameDsl.g:1320:2: ( rule__Game__CollisionsAssignment_7_3_1 )
            // InternalGameDsl.g:1320:3: rule__Game__CollisionsAssignment_7_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Game__CollisionsAssignment_7_3_1();

            state._fsp--;


            }

             after(grammarAccess.getGameAccess().getCollisionsAssignment_7_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__Group_7_3__1__Impl"


    // $ANTLR start "rule__Background__Group__0"
    // InternalGameDsl.g:1329:1: rule__Background__Group__0 : rule__Background__Group__0__Impl rule__Background__Group__1 ;
    public final void rule__Background__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1333:1: ( rule__Background__Group__0__Impl rule__Background__Group__1 )
            // InternalGameDsl.g:1334:2: rule__Background__Group__0__Impl rule__Background__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Background__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__0"


    // $ANTLR start "rule__Background__Group__0__Impl"
    // InternalGameDsl.g:1341:1: rule__Background__Group__0__Impl : ( 'Background' ) ;
    public final void rule__Background__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1345:1: ( ( 'Background' ) )
            // InternalGameDsl.g:1346:1: ( 'Background' )
            {
            // InternalGameDsl.g:1346:1: ( 'Background' )
            // InternalGameDsl.g:1347:2: 'Background'
            {
             before(grammarAccess.getBackgroundAccess().getBackgroundKeyword_0()); 
            match(input,22,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getBackgroundKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__0__Impl"


    // $ANTLR start "rule__Background__Group__1"
    // InternalGameDsl.g:1356:1: rule__Background__Group__1 : rule__Background__Group__1__Impl rule__Background__Group__2 ;
    public final void rule__Background__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1360:1: ( rule__Background__Group__1__Impl rule__Background__Group__2 )
            // InternalGameDsl.g:1361:2: rule__Background__Group__1__Impl rule__Background__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Background__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__1"


    // $ANTLR start "rule__Background__Group__1__Impl"
    // InternalGameDsl.g:1368:1: rule__Background__Group__1__Impl : ( ( rule__Background__IdentifierAssignment_1 ) ) ;
    public final void rule__Background__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1372:1: ( ( ( rule__Background__IdentifierAssignment_1 ) ) )
            // InternalGameDsl.g:1373:1: ( ( rule__Background__IdentifierAssignment_1 ) )
            {
            // InternalGameDsl.g:1373:1: ( ( rule__Background__IdentifierAssignment_1 ) )
            // InternalGameDsl.g:1374:2: ( rule__Background__IdentifierAssignment_1 )
            {
             before(grammarAccess.getBackgroundAccess().getIdentifierAssignment_1()); 
            // InternalGameDsl.g:1375:2: ( rule__Background__IdentifierAssignment_1 )
            // InternalGameDsl.g:1375:3: rule__Background__IdentifierAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Background__IdentifierAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getBackgroundAccess().getIdentifierAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__1__Impl"


    // $ANTLR start "rule__Background__Group__2"
    // InternalGameDsl.g:1383:1: rule__Background__Group__2 : rule__Background__Group__2__Impl rule__Background__Group__3 ;
    public final void rule__Background__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1387:1: ( rule__Background__Group__2__Impl rule__Background__Group__3 )
            // InternalGameDsl.g:1388:2: rule__Background__Group__2__Impl rule__Background__Group__3
            {
            pushFollow(FOLLOW_12);
            rule__Background__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__2"


    // $ANTLR start "rule__Background__Group__2__Impl"
    // InternalGameDsl.g:1395:1: rule__Background__Group__2__Impl : ( '{' ) ;
    public final void rule__Background__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1399:1: ( ( '{' ) )
            // InternalGameDsl.g:1400:1: ( '{' )
            {
            // InternalGameDsl.g:1400:1: ( '{' )
            // InternalGameDsl.g:1401:2: '{'
            {
             before(grammarAccess.getBackgroundAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__2__Impl"


    // $ANTLR start "rule__Background__Group__3"
    // InternalGameDsl.g:1410:1: rule__Background__Group__3 : rule__Background__Group__3__Impl rule__Background__Group__4 ;
    public final void rule__Background__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1414:1: ( rule__Background__Group__3__Impl rule__Background__Group__4 )
            // InternalGameDsl.g:1415:2: rule__Background__Group__3__Impl rule__Background__Group__4
            {
            pushFollow(FOLLOW_13);
            rule__Background__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__3"


    // $ANTLR start "rule__Background__Group__3__Impl"
    // InternalGameDsl.g:1422:1: rule__Background__Group__3__Impl : ( 'coordinates' ) ;
    public final void rule__Background__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1426:1: ( ( 'coordinates' ) )
            // InternalGameDsl.g:1427:1: ( 'coordinates' )
            {
            // InternalGameDsl.g:1427:1: ( 'coordinates' )
            // InternalGameDsl.g:1428:2: 'coordinates'
            {
             before(grammarAccess.getBackgroundAccess().getCoordinatesKeyword_3()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getCoordinatesKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__3__Impl"


    // $ANTLR start "rule__Background__Group__4"
    // InternalGameDsl.g:1437:1: rule__Background__Group__4 : rule__Background__Group__4__Impl rule__Background__Group__5 ;
    public final void rule__Background__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1441:1: ( rule__Background__Group__4__Impl rule__Background__Group__5 )
            // InternalGameDsl.g:1442:2: rule__Background__Group__4__Impl rule__Background__Group__5
            {
            pushFollow(FOLLOW_14);
            rule__Background__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__4"


    // $ANTLR start "rule__Background__Group__4__Impl"
    // InternalGameDsl.g:1449:1: rule__Background__Group__4__Impl : ( '(' ) ;
    public final void rule__Background__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1453:1: ( ( '(' ) )
            // InternalGameDsl.g:1454:1: ( '(' )
            {
            // InternalGameDsl.g:1454:1: ( '(' )
            // InternalGameDsl.g:1455:2: '('
            {
             before(grammarAccess.getBackgroundAccess().getLeftParenthesisKeyword_4()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getLeftParenthesisKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__4__Impl"


    // $ANTLR start "rule__Background__Group__5"
    // InternalGameDsl.g:1464:1: rule__Background__Group__5 : rule__Background__Group__5__Impl rule__Background__Group__6 ;
    public final void rule__Background__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1468:1: ( rule__Background__Group__5__Impl rule__Background__Group__6 )
            // InternalGameDsl.g:1469:2: rule__Background__Group__5__Impl rule__Background__Group__6
            {
            pushFollow(FOLLOW_15);
            rule__Background__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__5"


    // $ANTLR start "rule__Background__Group__5__Impl"
    // InternalGameDsl.g:1476:1: rule__Background__Group__5__Impl : ( ( rule__Background__CoordinatesAssignment_5 ) ) ;
    public final void rule__Background__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1480:1: ( ( ( rule__Background__CoordinatesAssignment_5 ) ) )
            // InternalGameDsl.g:1481:1: ( ( rule__Background__CoordinatesAssignment_5 ) )
            {
            // InternalGameDsl.g:1481:1: ( ( rule__Background__CoordinatesAssignment_5 ) )
            // InternalGameDsl.g:1482:2: ( rule__Background__CoordinatesAssignment_5 )
            {
             before(grammarAccess.getBackgroundAccess().getCoordinatesAssignment_5()); 
            // InternalGameDsl.g:1483:2: ( rule__Background__CoordinatesAssignment_5 )
            // InternalGameDsl.g:1483:3: rule__Background__CoordinatesAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__Background__CoordinatesAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getBackgroundAccess().getCoordinatesAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__5__Impl"


    // $ANTLR start "rule__Background__Group__6"
    // InternalGameDsl.g:1491:1: rule__Background__Group__6 : rule__Background__Group__6__Impl rule__Background__Group__7 ;
    public final void rule__Background__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1495:1: ( rule__Background__Group__6__Impl rule__Background__Group__7 )
            // InternalGameDsl.g:1496:2: rule__Background__Group__6__Impl rule__Background__Group__7
            {
            pushFollow(FOLLOW_15);
            rule__Background__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__6"


    // $ANTLR start "rule__Background__Group__6__Impl"
    // InternalGameDsl.g:1503:1: rule__Background__Group__6__Impl : ( ( rule__Background__Group_6__0 )* ) ;
    public final void rule__Background__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1507:1: ( ( ( rule__Background__Group_6__0 )* ) )
            // InternalGameDsl.g:1508:1: ( ( rule__Background__Group_6__0 )* )
            {
            // InternalGameDsl.g:1508:1: ( ( rule__Background__Group_6__0 )* )
            // InternalGameDsl.g:1509:2: ( rule__Background__Group_6__0 )*
            {
             before(grammarAccess.getBackgroundAccess().getGroup_6()); 
            // InternalGameDsl.g:1510:2: ( rule__Background__Group_6__0 )*
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==19) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // InternalGameDsl.g:1510:3: rule__Background__Group_6__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Background__Group_6__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);

             after(grammarAccess.getBackgroundAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__6__Impl"


    // $ANTLR start "rule__Background__Group__7"
    // InternalGameDsl.g:1518:1: rule__Background__Group__7 : rule__Background__Group__7__Impl rule__Background__Group__8 ;
    public final void rule__Background__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1522:1: ( rule__Background__Group__7__Impl rule__Background__Group__8 )
            // InternalGameDsl.g:1523:2: rule__Background__Group__7__Impl rule__Background__Group__8
            {
            pushFollow(FOLLOW_16);
            rule__Background__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__7"


    // $ANTLR start "rule__Background__Group__7__Impl"
    // InternalGameDsl.g:1530:1: rule__Background__Group__7__Impl : ( ')' ) ;
    public final void rule__Background__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1534:1: ( ( ')' ) )
            // InternalGameDsl.g:1535:1: ( ')' )
            {
            // InternalGameDsl.g:1535:1: ( ')' )
            // InternalGameDsl.g:1536:2: ')'
            {
             before(grammarAccess.getBackgroundAccess().getRightParenthesisKeyword_7()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getRightParenthesisKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__7__Impl"


    // $ANTLR start "rule__Background__Group__8"
    // InternalGameDsl.g:1545:1: rule__Background__Group__8 : rule__Background__Group__8__Impl rule__Background__Group__9 ;
    public final void rule__Background__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1549:1: ( rule__Background__Group__8__Impl rule__Background__Group__9 )
            // InternalGameDsl.g:1550:2: rule__Background__Group__8__Impl rule__Background__Group__9
            {
            pushFollow(FOLLOW_13);
            rule__Background__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__8"


    // $ANTLR start "rule__Background__Group__8__Impl"
    // InternalGameDsl.g:1557:1: rule__Background__Group__8__Impl : ( 'size' ) ;
    public final void rule__Background__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1561:1: ( ( 'size' ) )
            // InternalGameDsl.g:1562:1: ( 'size' )
            {
            // InternalGameDsl.g:1562:1: ( 'size' )
            // InternalGameDsl.g:1563:2: 'size'
            {
             before(grammarAccess.getBackgroundAccess().getSizeKeyword_8()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getSizeKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__8__Impl"


    // $ANTLR start "rule__Background__Group__9"
    // InternalGameDsl.g:1572:1: rule__Background__Group__9 : rule__Background__Group__9__Impl rule__Background__Group__10 ;
    public final void rule__Background__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1576:1: ( rule__Background__Group__9__Impl rule__Background__Group__10 )
            // InternalGameDsl.g:1577:2: rule__Background__Group__9__Impl rule__Background__Group__10
            {
            pushFollow(FOLLOW_14);
            rule__Background__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__9"


    // $ANTLR start "rule__Background__Group__9__Impl"
    // InternalGameDsl.g:1584:1: rule__Background__Group__9__Impl : ( '(' ) ;
    public final void rule__Background__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1588:1: ( ( '(' ) )
            // InternalGameDsl.g:1589:1: ( '(' )
            {
            // InternalGameDsl.g:1589:1: ( '(' )
            // InternalGameDsl.g:1590:2: '('
            {
             before(grammarAccess.getBackgroundAccess().getLeftParenthesisKeyword_9()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getLeftParenthesisKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__9__Impl"


    // $ANTLR start "rule__Background__Group__10"
    // InternalGameDsl.g:1599:1: rule__Background__Group__10 : rule__Background__Group__10__Impl rule__Background__Group__11 ;
    public final void rule__Background__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1603:1: ( rule__Background__Group__10__Impl rule__Background__Group__11 )
            // InternalGameDsl.g:1604:2: rule__Background__Group__10__Impl rule__Background__Group__11
            {
            pushFollow(FOLLOW_15);
            rule__Background__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__10"


    // $ANTLR start "rule__Background__Group__10__Impl"
    // InternalGameDsl.g:1611:1: rule__Background__Group__10__Impl : ( ( rule__Background__SizeAssignment_10 ) ) ;
    public final void rule__Background__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1615:1: ( ( ( rule__Background__SizeAssignment_10 ) ) )
            // InternalGameDsl.g:1616:1: ( ( rule__Background__SizeAssignment_10 ) )
            {
            // InternalGameDsl.g:1616:1: ( ( rule__Background__SizeAssignment_10 ) )
            // InternalGameDsl.g:1617:2: ( rule__Background__SizeAssignment_10 )
            {
             before(grammarAccess.getBackgroundAccess().getSizeAssignment_10()); 
            // InternalGameDsl.g:1618:2: ( rule__Background__SizeAssignment_10 )
            // InternalGameDsl.g:1618:3: rule__Background__SizeAssignment_10
            {
            pushFollow(FOLLOW_2);
            rule__Background__SizeAssignment_10();

            state._fsp--;


            }

             after(grammarAccess.getBackgroundAccess().getSizeAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__10__Impl"


    // $ANTLR start "rule__Background__Group__11"
    // InternalGameDsl.g:1626:1: rule__Background__Group__11 : rule__Background__Group__11__Impl rule__Background__Group__12 ;
    public final void rule__Background__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1630:1: ( rule__Background__Group__11__Impl rule__Background__Group__12 )
            // InternalGameDsl.g:1631:2: rule__Background__Group__11__Impl rule__Background__Group__12
            {
            pushFollow(FOLLOW_15);
            rule__Background__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__11"


    // $ANTLR start "rule__Background__Group__11__Impl"
    // InternalGameDsl.g:1638:1: rule__Background__Group__11__Impl : ( ( rule__Background__Group_11__0 )* ) ;
    public final void rule__Background__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1642:1: ( ( ( rule__Background__Group_11__0 )* ) )
            // InternalGameDsl.g:1643:1: ( ( rule__Background__Group_11__0 )* )
            {
            // InternalGameDsl.g:1643:1: ( ( rule__Background__Group_11__0 )* )
            // InternalGameDsl.g:1644:2: ( rule__Background__Group_11__0 )*
            {
             before(grammarAccess.getBackgroundAccess().getGroup_11()); 
            // InternalGameDsl.g:1645:2: ( rule__Background__Group_11__0 )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==19) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // InternalGameDsl.g:1645:3: rule__Background__Group_11__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Background__Group_11__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);

             after(grammarAccess.getBackgroundAccess().getGroup_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__11__Impl"


    // $ANTLR start "rule__Background__Group__12"
    // InternalGameDsl.g:1653:1: rule__Background__Group__12 : rule__Background__Group__12__Impl rule__Background__Group__13 ;
    public final void rule__Background__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1657:1: ( rule__Background__Group__12__Impl rule__Background__Group__13 )
            // InternalGameDsl.g:1658:2: rule__Background__Group__12__Impl rule__Background__Group__13
            {
            pushFollow(FOLLOW_17);
            rule__Background__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__12"


    // $ANTLR start "rule__Background__Group__12__Impl"
    // InternalGameDsl.g:1665:1: rule__Background__Group__12__Impl : ( ')' ) ;
    public final void rule__Background__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1669:1: ( ( ')' ) )
            // InternalGameDsl.g:1670:1: ( ')' )
            {
            // InternalGameDsl.g:1670:1: ( ')' )
            // InternalGameDsl.g:1671:2: ')'
            {
             before(grammarAccess.getBackgroundAccess().getRightParenthesisKeyword_12()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getRightParenthesisKeyword_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__12__Impl"


    // $ANTLR start "rule__Background__Group__13"
    // InternalGameDsl.g:1680:1: rule__Background__Group__13 : rule__Background__Group__13__Impl rule__Background__Group__14 ;
    public final void rule__Background__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1684:1: ( rule__Background__Group__13__Impl rule__Background__Group__14 )
            // InternalGameDsl.g:1685:2: rule__Background__Group__13__Impl rule__Background__Group__14
            {
            pushFollow(FOLLOW_17);
            rule__Background__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__13"


    // $ANTLR start "rule__Background__Group__13__Impl"
    // InternalGameDsl.g:1692:1: rule__Background__Group__13__Impl : ( ( rule__Background__Group_13__0 )? ) ;
    public final void rule__Background__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1696:1: ( ( ( rule__Background__Group_13__0 )? ) )
            // InternalGameDsl.g:1697:1: ( ( rule__Background__Group_13__0 )? )
            {
            // InternalGameDsl.g:1697:1: ( ( rule__Background__Group_13__0 )? )
            // InternalGameDsl.g:1698:2: ( rule__Background__Group_13__0 )?
            {
             before(grammarAccess.getBackgroundAccess().getGroup_13()); 
            // InternalGameDsl.g:1699:2: ( rule__Background__Group_13__0 )?
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==27) ) {
                alt14=1;
            }
            switch (alt14) {
                case 1 :
                    // InternalGameDsl.g:1699:3: rule__Background__Group_13__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Background__Group_13__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getBackgroundAccess().getGroup_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__13__Impl"


    // $ANTLR start "rule__Background__Group__14"
    // InternalGameDsl.g:1707:1: rule__Background__Group__14 : rule__Background__Group__14__Impl rule__Background__Group__15 ;
    public final void rule__Background__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1711:1: ( rule__Background__Group__14__Impl rule__Background__Group__15 )
            // InternalGameDsl.g:1712:2: rule__Background__Group__14__Impl rule__Background__Group__15
            {
            pushFollow(FOLLOW_17);
            rule__Background__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__14"


    // $ANTLR start "rule__Background__Group__14__Impl"
    // InternalGameDsl.g:1719:1: rule__Background__Group__14__Impl : ( ( rule__Background__Group_14__0 )? ) ;
    public final void rule__Background__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1723:1: ( ( ( rule__Background__Group_14__0 )? ) )
            // InternalGameDsl.g:1724:1: ( ( rule__Background__Group_14__0 )? )
            {
            // InternalGameDsl.g:1724:1: ( ( rule__Background__Group_14__0 )? )
            // InternalGameDsl.g:1725:2: ( rule__Background__Group_14__0 )?
            {
             before(grammarAccess.getBackgroundAccess().getGroup_14()); 
            // InternalGameDsl.g:1726:2: ( rule__Background__Group_14__0 )?
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==28) ) {
                alt15=1;
            }
            switch (alt15) {
                case 1 :
                    // InternalGameDsl.g:1726:3: rule__Background__Group_14__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Background__Group_14__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getBackgroundAccess().getGroup_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__14__Impl"


    // $ANTLR start "rule__Background__Group__15"
    // InternalGameDsl.g:1734:1: rule__Background__Group__15 : rule__Background__Group__15__Impl ;
    public final void rule__Background__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1738:1: ( rule__Background__Group__15__Impl )
            // InternalGameDsl.g:1739:2: rule__Background__Group__15__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Background__Group__15__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__15"


    // $ANTLR start "rule__Background__Group__15__Impl"
    // InternalGameDsl.g:1745:1: rule__Background__Group__15__Impl : ( '}' ) ;
    public final void rule__Background__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1749:1: ( ( '}' ) )
            // InternalGameDsl.g:1750:1: ( '}' )
            {
            // InternalGameDsl.g:1750:1: ( '}' )
            // InternalGameDsl.g:1751:2: '}'
            {
             before(grammarAccess.getBackgroundAccess().getRightCurlyBracketKeyword_15()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getRightCurlyBracketKeyword_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group__15__Impl"


    // $ANTLR start "rule__Background__Group_6__0"
    // InternalGameDsl.g:1761:1: rule__Background__Group_6__0 : rule__Background__Group_6__0__Impl rule__Background__Group_6__1 ;
    public final void rule__Background__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1765:1: ( rule__Background__Group_6__0__Impl rule__Background__Group_6__1 )
            // InternalGameDsl.g:1766:2: rule__Background__Group_6__0__Impl rule__Background__Group_6__1
            {
            pushFollow(FOLLOW_14);
            rule__Background__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_6__0"


    // $ANTLR start "rule__Background__Group_6__0__Impl"
    // InternalGameDsl.g:1773:1: rule__Background__Group_6__0__Impl : ( ',' ) ;
    public final void rule__Background__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1777:1: ( ( ',' ) )
            // InternalGameDsl.g:1778:1: ( ',' )
            {
            // InternalGameDsl.g:1778:1: ( ',' )
            // InternalGameDsl.g:1779:2: ','
            {
             before(grammarAccess.getBackgroundAccess().getCommaKeyword_6_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getCommaKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_6__0__Impl"


    // $ANTLR start "rule__Background__Group_6__1"
    // InternalGameDsl.g:1788:1: rule__Background__Group_6__1 : rule__Background__Group_6__1__Impl ;
    public final void rule__Background__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1792:1: ( rule__Background__Group_6__1__Impl )
            // InternalGameDsl.g:1793:2: rule__Background__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Background__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_6__1"


    // $ANTLR start "rule__Background__Group_6__1__Impl"
    // InternalGameDsl.g:1799:1: rule__Background__Group_6__1__Impl : ( ( rule__Background__CoordinatesAssignment_6_1 ) ) ;
    public final void rule__Background__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1803:1: ( ( ( rule__Background__CoordinatesAssignment_6_1 ) ) )
            // InternalGameDsl.g:1804:1: ( ( rule__Background__CoordinatesAssignment_6_1 ) )
            {
            // InternalGameDsl.g:1804:1: ( ( rule__Background__CoordinatesAssignment_6_1 ) )
            // InternalGameDsl.g:1805:2: ( rule__Background__CoordinatesAssignment_6_1 )
            {
             before(grammarAccess.getBackgroundAccess().getCoordinatesAssignment_6_1()); 
            // InternalGameDsl.g:1806:2: ( rule__Background__CoordinatesAssignment_6_1 )
            // InternalGameDsl.g:1806:3: rule__Background__CoordinatesAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__Background__CoordinatesAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getBackgroundAccess().getCoordinatesAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_6__1__Impl"


    // $ANTLR start "rule__Background__Group_11__0"
    // InternalGameDsl.g:1815:1: rule__Background__Group_11__0 : rule__Background__Group_11__0__Impl rule__Background__Group_11__1 ;
    public final void rule__Background__Group_11__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1819:1: ( rule__Background__Group_11__0__Impl rule__Background__Group_11__1 )
            // InternalGameDsl.g:1820:2: rule__Background__Group_11__0__Impl rule__Background__Group_11__1
            {
            pushFollow(FOLLOW_14);
            rule__Background__Group_11__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group_11__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_11__0"


    // $ANTLR start "rule__Background__Group_11__0__Impl"
    // InternalGameDsl.g:1827:1: rule__Background__Group_11__0__Impl : ( ',' ) ;
    public final void rule__Background__Group_11__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1831:1: ( ( ',' ) )
            // InternalGameDsl.g:1832:1: ( ',' )
            {
            // InternalGameDsl.g:1832:1: ( ',' )
            // InternalGameDsl.g:1833:2: ','
            {
             before(grammarAccess.getBackgroundAccess().getCommaKeyword_11_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getCommaKeyword_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_11__0__Impl"


    // $ANTLR start "rule__Background__Group_11__1"
    // InternalGameDsl.g:1842:1: rule__Background__Group_11__1 : rule__Background__Group_11__1__Impl ;
    public final void rule__Background__Group_11__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1846:1: ( rule__Background__Group_11__1__Impl )
            // InternalGameDsl.g:1847:2: rule__Background__Group_11__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Background__Group_11__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_11__1"


    // $ANTLR start "rule__Background__Group_11__1__Impl"
    // InternalGameDsl.g:1853:1: rule__Background__Group_11__1__Impl : ( ( rule__Background__SizeAssignment_11_1 ) ) ;
    public final void rule__Background__Group_11__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1857:1: ( ( ( rule__Background__SizeAssignment_11_1 ) ) )
            // InternalGameDsl.g:1858:1: ( ( rule__Background__SizeAssignment_11_1 ) )
            {
            // InternalGameDsl.g:1858:1: ( ( rule__Background__SizeAssignment_11_1 ) )
            // InternalGameDsl.g:1859:2: ( rule__Background__SizeAssignment_11_1 )
            {
             before(grammarAccess.getBackgroundAccess().getSizeAssignment_11_1()); 
            // InternalGameDsl.g:1860:2: ( rule__Background__SizeAssignment_11_1 )
            // InternalGameDsl.g:1860:3: rule__Background__SizeAssignment_11_1
            {
            pushFollow(FOLLOW_2);
            rule__Background__SizeAssignment_11_1();

            state._fsp--;


            }

             after(grammarAccess.getBackgroundAccess().getSizeAssignment_11_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_11__1__Impl"


    // $ANTLR start "rule__Background__Group_13__0"
    // InternalGameDsl.g:1869:1: rule__Background__Group_13__0 : rule__Background__Group_13__0__Impl rule__Background__Group_13__1 ;
    public final void rule__Background__Group_13__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1873:1: ( rule__Background__Group_13__0__Impl rule__Background__Group_13__1 )
            // InternalGameDsl.g:1874:2: rule__Background__Group_13__0__Impl rule__Background__Group_13__1
            {
            pushFollow(FOLLOW_14);
            rule__Background__Group_13__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group_13__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_13__0"


    // $ANTLR start "rule__Background__Group_13__0__Impl"
    // InternalGameDsl.g:1881:1: rule__Background__Group_13__0__Impl : ( 'backgroundSpeed:' ) ;
    public final void rule__Background__Group_13__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1885:1: ( ( 'backgroundSpeed:' ) )
            // InternalGameDsl.g:1886:1: ( 'backgroundSpeed:' )
            {
            // InternalGameDsl.g:1886:1: ( 'backgroundSpeed:' )
            // InternalGameDsl.g:1887:2: 'backgroundSpeed:'
            {
             before(grammarAccess.getBackgroundAccess().getBackgroundSpeedKeyword_13_0()); 
            match(input,27,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getBackgroundSpeedKeyword_13_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_13__0__Impl"


    // $ANTLR start "rule__Background__Group_13__1"
    // InternalGameDsl.g:1896:1: rule__Background__Group_13__1 : rule__Background__Group_13__1__Impl ;
    public final void rule__Background__Group_13__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1900:1: ( rule__Background__Group_13__1__Impl )
            // InternalGameDsl.g:1901:2: rule__Background__Group_13__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Background__Group_13__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_13__1"


    // $ANTLR start "rule__Background__Group_13__1__Impl"
    // InternalGameDsl.g:1907:1: rule__Background__Group_13__1__Impl : ( ( rule__Background__BackgroundSpeedAssignment_13_1 ) ) ;
    public final void rule__Background__Group_13__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1911:1: ( ( ( rule__Background__BackgroundSpeedAssignment_13_1 ) ) )
            // InternalGameDsl.g:1912:1: ( ( rule__Background__BackgroundSpeedAssignment_13_1 ) )
            {
            // InternalGameDsl.g:1912:1: ( ( rule__Background__BackgroundSpeedAssignment_13_1 ) )
            // InternalGameDsl.g:1913:2: ( rule__Background__BackgroundSpeedAssignment_13_1 )
            {
             before(grammarAccess.getBackgroundAccess().getBackgroundSpeedAssignment_13_1()); 
            // InternalGameDsl.g:1914:2: ( rule__Background__BackgroundSpeedAssignment_13_1 )
            // InternalGameDsl.g:1914:3: rule__Background__BackgroundSpeedAssignment_13_1
            {
            pushFollow(FOLLOW_2);
            rule__Background__BackgroundSpeedAssignment_13_1();

            state._fsp--;


            }

             after(grammarAccess.getBackgroundAccess().getBackgroundSpeedAssignment_13_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_13__1__Impl"


    // $ANTLR start "rule__Background__Group_14__0"
    // InternalGameDsl.g:1923:1: rule__Background__Group_14__0 : rule__Background__Group_14__0__Impl rule__Background__Group_14__1 ;
    public final void rule__Background__Group_14__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1927:1: ( rule__Background__Group_14__0__Impl rule__Background__Group_14__1 )
            // InternalGameDsl.g:1928:2: rule__Background__Group_14__0__Impl rule__Background__Group_14__1
            {
            pushFollow(FOLLOW_18);
            rule__Background__Group_14__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Background__Group_14__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_14__0"


    // $ANTLR start "rule__Background__Group_14__0__Impl"
    // InternalGameDsl.g:1935:1: rule__Background__Group_14__0__Impl : ( 'backgroundMoving:' ) ;
    public final void rule__Background__Group_14__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1939:1: ( ( 'backgroundMoving:' ) )
            // InternalGameDsl.g:1940:1: ( 'backgroundMoving:' )
            {
            // InternalGameDsl.g:1940:1: ( 'backgroundMoving:' )
            // InternalGameDsl.g:1941:2: 'backgroundMoving:'
            {
             before(grammarAccess.getBackgroundAccess().getBackgroundMovingKeyword_14_0()); 
            match(input,28,FOLLOW_2); 
             after(grammarAccess.getBackgroundAccess().getBackgroundMovingKeyword_14_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_14__0__Impl"


    // $ANTLR start "rule__Background__Group_14__1"
    // InternalGameDsl.g:1950:1: rule__Background__Group_14__1 : rule__Background__Group_14__1__Impl ;
    public final void rule__Background__Group_14__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1954:1: ( rule__Background__Group_14__1__Impl )
            // InternalGameDsl.g:1955:2: rule__Background__Group_14__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Background__Group_14__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_14__1"


    // $ANTLR start "rule__Background__Group_14__1__Impl"
    // InternalGameDsl.g:1961:1: rule__Background__Group_14__1__Impl : ( ( rule__Background__BackgroundMovingAssignment_14_1 ) ) ;
    public final void rule__Background__Group_14__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1965:1: ( ( ( rule__Background__BackgroundMovingAssignment_14_1 ) ) )
            // InternalGameDsl.g:1966:1: ( ( rule__Background__BackgroundMovingAssignment_14_1 ) )
            {
            // InternalGameDsl.g:1966:1: ( ( rule__Background__BackgroundMovingAssignment_14_1 ) )
            // InternalGameDsl.g:1967:2: ( rule__Background__BackgroundMovingAssignment_14_1 )
            {
             before(grammarAccess.getBackgroundAccess().getBackgroundMovingAssignment_14_1()); 
            // InternalGameDsl.g:1968:2: ( rule__Background__BackgroundMovingAssignment_14_1 )
            // InternalGameDsl.g:1968:3: rule__Background__BackgroundMovingAssignment_14_1
            {
            pushFollow(FOLLOW_2);
            rule__Background__BackgroundMovingAssignment_14_1();

            state._fsp--;


            }

             after(grammarAccess.getBackgroundAccess().getBackgroundMovingAssignment_14_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__Group_14__1__Impl"


    // $ANTLR start "rule__ObjectType__Group__0"
    // InternalGameDsl.g:1977:1: rule__ObjectType__Group__0 : rule__ObjectType__Group__0__Impl rule__ObjectType__Group__1 ;
    public final void rule__ObjectType__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1981:1: ( rule__ObjectType__Group__0__Impl rule__ObjectType__Group__1 )
            // InternalGameDsl.g:1982:2: rule__ObjectType__Group__0__Impl rule__ObjectType__Group__1
            {
            pushFollow(FOLLOW_10);
            rule__ObjectType__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__0"


    // $ANTLR start "rule__ObjectType__Group__0__Impl"
    // InternalGameDsl.g:1989:1: rule__ObjectType__Group__0__Impl : ( () ) ;
    public final void rule__ObjectType__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:1993:1: ( ( () ) )
            // InternalGameDsl.g:1994:1: ( () )
            {
            // InternalGameDsl.g:1994:1: ( () )
            // InternalGameDsl.g:1995:2: ()
            {
             before(grammarAccess.getObjectTypeAccess().getObjectTypeAction_0()); 
            // InternalGameDsl.g:1996:2: ()
            // InternalGameDsl.g:1996:3: 
            {
            }

             after(grammarAccess.getObjectTypeAccess().getObjectTypeAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__0__Impl"


    // $ANTLR start "rule__ObjectType__Group__1"
    // InternalGameDsl.g:2004:1: rule__ObjectType__Group__1 : rule__ObjectType__Group__1__Impl rule__ObjectType__Group__2 ;
    public final void rule__ObjectType__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2008:1: ( rule__ObjectType__Group__1__Impl rule__ObjectType__Group__2 )
            // InternalGameDsl.g:2009:2: rule__ObjectType__Group__1__Impl rule__ObjectType__Group__2
            {
            pushFollow(FOLLOW_4);
            rule__ObjectType__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__1"


    // $ANTLR start "rule__ObjectType__Group__1__Impl"
    // InternalGameDsl.g:2016:1: rule__ObjectType__Group__1__Impl : ( 'Type' ) ;
    public final void rule__ObjectType__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2020:1: ( ( 'Type' ) )
            // InternalGameDsl.g:2021:1: ( 'Type' )
            {
            // InternalGameDsl.g:2021:1: ( 'Type' )
            // InternalGameDsl.g:2022:2: 'Type'
            {
             before(grammarAccess.getObjectTypeAccess().getTypeKeyword_1()); 
            match(input,29,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getTypeKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__1__Impl"


    // $ANTLR start "rule__ObjectType__Group__2"
    // InternalGameDsl.g:2031:1: rule__ObjectType__Group__2 : rule__ObjectType__Group__2__Impl rule__ObjectType__Group__3 ;
    public final void rule__ObjectType__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2035:1: ( rule__ObjectType__Group__2__Impl rule__ObjectType__Group__3 )
            // InternalGameDsl.g:2036:2: rule__ObjectType__Group__2__Impl rule__ObjectType__Group__3
            {
            pushFollow(FOLLOW_5);
            rule__ObjectType__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__2"


    // $ANTLR start "rule__ObjectType__Group__2__Impl"
    // InternalGameDsl.g:2043:1: rule__ObjectType__Group__2__Impl : ( ( rule__ObjectType__NameAssignment_2 ) ) ;
    public final void rule__ObjectType__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2047:1: ( ( ( rule__ObjectType__NameAssignment_2 ) ) )
            // InternalGameDsl.g:2048:1: ( ( rule__ObjectType__NameAssignment_2 ) )
            {
            // InternalGameDsl.g:2048:1: ( ( rule__ObjectType__NameAssignment_2 ) )
            // InternalGameDsl.g:2049:2: ( rule__ObjectType__NameAssignment_2 )
            {
             before(grammarAccess.getObjectTypeAccess().getNameAssignment_2()); 
            // InternalGameDsl.g:2050:2: ( rule__ObjectType__NameAssignment_2 )
            // InternalGameDsl.g:2050:3: rule__ObjectType__NameAssignment_2
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__NameAssignment_2();

            state._fsp--;


            }

             after(grammarAccess.getObjectTypeAccess().getNameAssignment_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__2__Impl"


    // $ANTLR start "rule__ObjectType__Group__3"
    // InternalGameDsl.g:2058:1: rule__ObjectType__Group__3 : rule__ObjectType__Group__3__Impl rule__ObjectType__Group__4 ;
    public final void rule__ObjectType__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2062:1: ( rule__ObjectType__Group__3__Impl rule__ObjectType__Group__4 )
            // InternalGameDsl.g:2063:2: rule__ObjectType__Group__3__Impl rule__ObjectType__Group__4
            {
            pushFollow(FOLLOW_19);
            rule__ObjectType__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__3"


    // $ANTLR start "rule__ObjectType__Group__3__Impl"
    // InternalGameDsl.g:2070:1: rule__ObjectType__Group__3__Impl : ( '{' ) ;
    public final void rule__ObjectType__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2074:1: ( ( '{' ) )
            // InternalGameDsl.g:2075:1: ( '{' )
            {
            // InternalGameDsl.g:2075:1: ( '{' )
            // InternalGameDsl.g:2076:2: '{'
            {
             before(grammarAccess.getObjectTypeAccess().getLeftCurlyBracketKeyword_3()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getLeftCurlyBracketKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__3__Impl"


    // $ANTLR start "rule__ObjectType__Group__4"
    // InternalGameDsl.g:2085:1: rule__ObjectType__Group__4 : rule__ObjectType__Group__4__Impl rule__ObjectType__Group__5 ;
    public final void rule__ObjectType__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2089:1: ( rule__ObjectType__Group__4__Impl rule__ObjectType__Group__5 )
            // InternalGameDsl.g:2090:2: rule__ObjectType__Group__4__Impl rule__ObjectType__Group__5
            {
            pushFollow(FOLLOW_19);
            rule__ObjectType__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__4"


    // $ANTLR start "rule__ObjectType__Group__4__Impl"
    // InternalGameDsl.g:2097:1: rule__ObjectType__Group__4__Impl : ( ( rule__ObjectType__Group_4__0 )? ) ;
    public final void rule__ObjectType__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2101:1: ( ( ( rule__ObjectType__Group_4__0 )? ) )
            // InternalGameDsl.g:2102:1: ( ( rule__ObjectType__Group_4__0 )? )
            {
            // InternalGameDsl.g:2102:1: ( ( rule__ObjectType__Group_4__0 )? )
            // InternalGameDsl.g:2103:2: ( rule__ObjectType__Group_4__0 )?
            {
             before(grammarAccess.getObjectTypeAccess().getGroup_4()); 
            // InternalGameDsl.g:2104:2: ( rule__ObjectType__Group_4__0 )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( (LA16_0==30) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalGameDsl.g:2104:3: rule__ObjectType__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ObjectType__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getObjectTypeAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__4__Impl"


    // $ANTLR start "rule__ObjectType__Group__5"
    // InternalGameDsl.g:2112:1: rule__ObjectType__Group__5 : rule__ObjectType__Group__5__Impl rule__ObjectType__Group__6 ;
    public final void rule__ObjectType__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2116:1: ( rule__ObjectType__Group__5__Impl rule__ObjectType__Group__6 )
            // InternalGameDsl.g:2117:2: rule__ObjectType__Group__5__Impl rule__ObjectType__Group__6
            {
            pushFollow(FOLLOW_19);
            rule__ObjectType__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__5"


    // $ANTLR start "rule__ObjectType__Group__5__Impl"
    // InternalGameDsl.g:2124:1: rule__ObjectType__Group__5__Impl : ( ( rule__ObjectType__Group_5__0 )? ) ;
    public final void rule__ObjectType__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2128:1: ( ( ( rule__ObjectType__Group_5__0 )? ) )
            // InternalGameDsl.g:2129:1: ( ( rule__ObjectType__Group_5__0 )? )
            {
            // InternalGameDsl.g:2129:1: ( ( rule__ObjectType__Group_5__0 )? )
            // InternalGameDsl.g:2130:2: ( rule__ObjectType__Group_5__0 )?
            {
             before(grammarAccess.getObjectTypeAccess().getGroup_5()); 
            // InternalGameDsl.g:2131:2: ( rule__ObjectType__Group_5__0 )?
            int alt17=2;
            int LA17_0 = input.LA(1);

            if ( (LA17_0==31) ) {
                alt17=1;
            }
            switch (alt17) {
                case 1 :
                    // InternalGameDsl.g:2131:3: rule__ObjectType__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ObjectType__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getObjectTypeAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__5__Impl"


    // $ANTLR start "rule__ObjectType__Group__6"
    // InternalGameDsl.g:2139:1: rule__ObjectType__Group__6 : rule__ObjectType__Group__6__Impl rule__ObjectType__Group__7 ;
    public final void rule__ObjectType__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2143:1: ( rule__ObjectType__Group__6__Impl rule__ObjectType__Group__7 )
            // InternalGameDsl.g:2144:2: rule__ObjectType__Group__6__Impl rule__ObjectType__Group__7
            {
            pushFollow(FOLLOW_19);
            rule__ObjectType__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__6"


    // $ANTLR start "rule__ObjectType__Group__6__Impl"
    // InternalGameDsl.g:2151:1: rule__ObjectType__Group__6__Impl : ( ( rule__ObjectType__Group_6__0 )? ) ;
    public final void rule__ObjectType__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2155:1: ( ( ( rule__ObjectType__Group_6__0 )? ) )
            // InternalGameDsl.g:2156:1: ( ( rule__ObjectType__Group_6__0 )? )
            {
            // InternalGameDsl.g:2156:1: ( ( rule__ObjectType__Group_6__0 )? )
            // InternalGameDsl.g:2157:2: ( rule__ObjectType__Group_6__0 )?
            {
             before(grammarAccess.getObjectTypeAccess().getGroup_6()); 
            // InternalGameDsl.g:2158:2: ( rule__ObjectType__Group_6__0 )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( (LA18_0==32) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalGameDsl.g:2158:3: rule__ObjectType__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__ObjectType__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getObjectTypeAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__6__Impl"


    // $ANTLR start "rule__ObjectType__Group__7"
    // InternalGameDsl.g:2166:1: rule__ObjectType__Group__7 : rule__ObjectType__Group__7__Impl ;
    public final void rule__ObjectType__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2170:1: ( rule__ObjectType__Group__7__Impl )
            // InternalGameDsl.g:2171:2: rule__ObjectType__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__7"


    // $ANTLR start "rule__ObjectType__Group__7__Impl"
    // InternalGameDsl.g:2177:1: rule__ObjectType__Group__7__Impl : ( '}' ) ;
    public final void rule__ObjectType__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2181:1: ( ( '}' ) )
            // InternalGameDsl.g:2182:1: ( '}' )
            {
            // InternalGameDsl.g:2182:1: ( '}' )
            // InternalGameDsl.g:2183:2: '}'
            {
             before(grammarAccess.getObjectTypeAccess().getRightCurlyBracketKeyword_7()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group__7__Impl"


    // $ANTLR start "rule__ObjectType__Group_4__0"
    // InternalGameDsl.g:2193:1: rule__ObjectType__Group_4__0 : rule__ObjectType__Group_4__0__Impl rule__ObjectType__Group_4__1 ;
    public final void rule__ObjectType__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2197:1: ( rule__ObjectType__Group_4__0__Impl rule__ObjectType__Group_4__1 )
            // InternalGameDsl.g:2198:2: rule__ObjectType__Group_4__0__Impl rule__ObjectType__Group_4__1
            {
            pushFollow(FOLLOW_4);
            rule__ObjectType__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_4__0"


    // $ANTLR start "rule__ObjectType__Group_4__0__Impl"
    // InternalGameDsl.g:2205:1: rule__ObjectType__Group_4__0__Impl : ( 'interaction:' ) ;
    public final void rule__ObjectType__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2209:1: ( ( 'interaction:' ) )
            // InternalGameDsl.g:2210:1: ( 'interaction:' )
            {
            // InternalGameDsl.g:2210:1: ( 'interaction:' )
            // InternalGameDsl.g:2211:2: 'interaction:'
            {
             before(grammarAccess.getObjectTypeAccess().getInteractionKeyword_4_0()); 
            match(input,30,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getInteractionKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_4__0__Impl"


    // $ANTLR start "rule__ObjectType__Group_4__1"
    // InternalGameDsl.g:2220:1: rule__ObjectType__Group_4__1 : rule__ObjectType__Group_4__1__Impl ;
    public final void rule__ObjectType__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2224:1: ( rule__ObjectType__Group_4__1__Impl )
            // InternalGameDsl.g:2225:2: rule__ObjectType__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_4__1"


    // $ANTLR start "rule__ObjectType__Group_4__1__Impl"
    // InternalGameDsl.g:2231:1: rule__ObjectType__Group_4__1__Impl : ( ( rule__ObjectType__InteractionAssignment_4_1 ) ) ;
    public final void rule__ObjectType__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2235:1: ( ( ( rule__ObjectType__InteractionAssignment_4_1 ) ) )
            // InternalGameDsl.g:2236:1: ( ( rule__ObjectType__InteractionAssignment_4_1 ) )
            {
            // InternalGameDsl.g:2236:1: ( ( rule__ObjectType__InteractionAssignment_4_1 ) )
            // InternalGameDsl.g:2237:2: ( rule__ObjectType__InteractionAssignment_4_1 )
            {
             before(grammarAccess.getObjectTypeAccess().getInteractionAssignment_4_1()); 
            // InternalGameDsl.g:2238:2: ( rule__ObjectType__InteractionAssignment_4_1 )
            // InternalGameDsl.g:2238:3: rule__ObjectType__InteractionAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__InteractionAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getObjectTypeAccess().getInteractionAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_4__1__Impl"


    // $ANTLR start "rule__ObjectType__Group_5__0"
    // InternalGameDsl.g:2247:1: rule__ObjectType__Group_5__0 : rule__ObjectType__Group_5__0__Impl rule__ObjectType__Group_5__1 ;
    public final void rule__ObjectType__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2251:1: ( rule__ObjectType__Group_5__0__Impl rule__ObjectType__Group_5__1 )
            // InternalGameDsl.g:2252:2: rule__ObjectType__Group_5__0__Impl rule__ObjectType__Group_5__1
            {
            pushFollow(FOLLOW_13);
            rule__ObjectType__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5__0"


    // $ANTLR start "rule__ObjectType__Group_5__0__Impl"
    // InternalGameDsl.g:2259:1: rule__ObjectType__Group_5__0__Impl : ( 'characteristic' ) ;
    public final void rule__ObjectType__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2263:1: ( ( 'characteristic' ) )
            // InternalGameDsl.g:2264:1: ( 'characteristic' )
            {
            // InternalGameDsl.g:2264:1: ( 'characteristic' )
            // InternalGameDsl.g:2265:2: 'characteristic'
            {
             before(grammarAccess.getObjectTypeAccess().getCharacteristicKeyword_5_0()); 
            match(input,31,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getCharacteristicKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5__0__Impl"


    // $ANTLR start "rule__ObjectType__Group_5__1"
    // InternalGameDsl.g:2274:1: rule__ObjectType__Group_5__1 : rule__ObjectType__Group_5__1__Impl rule__ObjectType__Group_5__2 ;
    public final void rule__ObjectType__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2278:1: ( rule__ObjectType__Group_5__1__Impl rule__ObjectType__Group_5__2 )
            // InternalGameDsl.g:2279:2: rule__ObjectType__Group_5__1__Impl rule__ObjectType__Group_5__2
            {
            pushFollow(FOLLOW_20);
            rule__ObjectType__Group_5__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_5__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5__1"


    // $ANTLR start "rule__ObjectType__Group_5__1__Impl"
    // InternalGameDsl.g:2286:1: rule__ObjectType__Group_5__1__Impl : ( '(' ) ;
    public final void rule__ObjectType__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2290:1: ( ( '(' ) )
            // InternalGameDsl.g:2291:1: ( '(' )
            {
            // InternalGameDsl.g:2291:1: ( '(' )
            // InternalGameDsl.g:2292:2: '('
            {
             before(grammarAccess.getObjectTypeAccess().getLeftParenthesisKeyword_5_1()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getLeftParenthesisKeyword_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5__1__Impl"


    // $ANTLR start "rule__ObjectType__Group_5__2"
    // InternalGameDsl.g:2301:1: rule__ObjectType__Group_5__2 : rule__ObjectType__Group_5__2__Impl rule__ObjectType__Group_5__3 ;
    public final void rule__ObjectType__Group_5__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2305:1: ( rule__ObjectType__Group_5__2__Impl rule__ObjectType__Group_5__3 )
            // InternalGameDsl.g:2306:2: rule__ObjectType__Group_5__2__Impl rule__ObjectType__Group_5__3
            {
            pushFollow(FOLLOW_15);
            rule__ObjectType__Group_5__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_5__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5__2"


    // $ANTLR start "rule__ObjectType__Group_5__2__Impl"
    // InternalGameDsl.g:2313:1: rule__ObjectType__Group_5__2__Impl : ( ( rule__ObjectType__CharacteristicAssignment_5_2 ) ) ;
    public final void rule__ObjectType__Group_5__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2317:1: ( ( ( rule__ObjectType__CharacteristicAssignment_5_2 ) ) )
            // InternalGameDsl.g:2318:1: ( ( rule__ObjectType__CharacteristicAssignment_5_2 ) )
            {
            // InternalGameDsl.g:2318:1: ( ( rule__ObjectType__CharacteristicAssignment_5_2 ) )
            // InternalGameDsl.g:2319:2: ( rule__ObjectType__CharacteristicAssignment_5_2 )
            {
             before(grammarAccess.getObjectTypeAccess().getCharacteristicAssignment_5_2()); 
            // InternalGameDsl.g:2320:2: ( rule__ObjectType__CharacteristicAssignment_5_2 )
            // InternalGameDsl.g:2320:3: rule__ObjectType__CharacteristicAssignment_5_2
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__CharacteristicAssignment_5_2();

            state._fsp--;


            }

             after(grammarAccess.getObjectTypeAccess().getCharacteristicAssignment_5_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5__2__Impl"


    // $ANTLR start "rule__ObjectType__Group_5__3"
    // InternalGameDsl.g:2328:1: rule__ObjectType__Group_5__3 : rule__ObjectType__Group_5__3__Impl rule__ObjectType__Group_5__4 ;
    public final void rule__ObjectType__Group_5__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2332:1: ( rule__ObjectType__Group_5__3__Impl rule__ObjectType__Group_5__4 )
            // InternalGameDsl.g:2333:2: rule__ObjectType__Group_5__3__Impl rule__ObjectType__Group_5__4
            {
            pushFollow(FOLLOW_15);
            rule__ObjectType__Group_5__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_5__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5__3"


    // $ANTLR start "rule__ObjectType__Group_5__3__Impl"
    // InternalGameDsl.g:2340:1: rule__ObjectType__Group_5__3__Impl : ( ( rule__ObjectType__Group_5_3__0 )* ) ;
    public final void rule__ObjectType__Group_5__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2344:1: ( ( ( rule__ObjectType__Group_5_3__0 )* ) )
            // InternalGameDsl.g:2345:1: ( ( rule__ObjectType__Group_5_3__0 )* )
            {
            // InternalGameDsl.g:2345:1: ( ( rule__ObjectType__Group_5_3__0 )* )
            // InternalGameDsl.g:2346:2: ( rule__ObjectType__Group_5_3__0 )*
            {
             before(grammarAccess.getObjectTypeAccess().getGroup_5_3()); 
            // InternalGameDsl.g:2347:2: ( rule__ObjectType__Group_5_3__0 )*
            loop19:
            do {
                int alt19=2;
                int LA19_0 = input.LA(1);

                if ( (LA19_0==19) ) {
                    alt19=1;
                }


                switch (alt19) {
            	case 1 :
            	    // InternalGameDsl.g:2347:3: rule__ObjectType__Group_5_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__ObjectType__Group_5_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop19;
                }
            } while (true);

             after(grammarAccess.getObjectTypeAccess().getGroup_5_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5__3__Impl"


    // $ANTLR start "rule__ObjectType__Group_5__4"
    // InternalGameDsl.g:2355:1: rule__ObjectType__Group_5__4 : rule__ObjectType__Group_5__4__Impl ;
    public final void rule__ObjectType__Group_5__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2359:1: ( rule__ObjectType__Group_5__4__Impl )
            // InternalGameDsl.g:2360:2: rule__ObjectType__Group_5__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_5__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5__4"


    // $ANTLR start "rule__ObjectType__Group_5__4__Impl"
    // InternalGameDsl.g:2366:1: rule__ObjectType__Group_5__4__Impl : ( ')' ) ;
    public final void rule__ObjectType__Group_5__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2370:1: ( ( ')' ) )
            // InternalGameDsl.g:2371:1: ( ')' )
            {
            // InternalGameDsl.g:2371:1: ( ')' )
            // InternalGameDsl.g:2372:2: ')'
            {
             before(grammarAccess.getObjectTypeAccess().getRightParenthesisKeyword_5_4()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getRightParenthesisKeyword_5_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5__4__Impl"


    // $ANTLR start "rule__ObjectType__Group_5_3__0"
    // InternalGameDsl.g:2382:1: rule__ObjectType__Group_5_3__0 : rule__ObjectType__Group_5_3__0__Impl rule__ObjectType__Group_5_3__1 ;
    public final void rule__ObjectType__Group_5_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2386:1: ( rule__ObjectType__Group_5_3__0__Impl rule__ObjectType__Group_5_3__1 )
            // InternalGameDsl.g:2387:2: rule__ObjectType__Group_5_3__0__Impl rule__ObjectType__Group_5_3__1
            {
            pushFollow(FOLLOW_20);
            rule__ObjectType__Group_5_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_5_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5_3__0"


    // $ANTLR start "rule__ObjectType__Group_5_3__0__Impl"
    // InternalGameDsl.g:2394:1: rule__ObjectType__Group_5_3__0__Impl : ( ',' ) ;
    public final void rule__ObjectType__Group_5_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2398:1: ( ( ',' ) )
            // InternalGameDsl.g:2399:1: ( ',' )
            {
            // InternalGameDsl.g:2399:1: ( ',' )
            // InternalGameDsl.g:2400:2: ','
            {
             before(grammarAccess.getObjectTypeAccess().getCommaKeyword_5_3_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getCommaKeyword_5_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5_3__0__Impl"


    // $ANTLR start "rule__ObjectType__Group_5_3__1"
    // InternalGameDsl.g:2409:1: rule__ObjectType__Group_5_3__1 : rule__ObjectType__Group_5_3__1__Impl ;
    public final void rule__ObjectType__Group_5_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2413:1: ( rule__ObjectType__Group_5_3__1__Impl )
            // InternalGameDsl.g:2414:2: rule__ObjectType__Group_5_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_5_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5_3__1"


    // $ANTLR start "rule__ObjectType__Group_5_3__1__Impl"
    // InternalGameDsl.g:2420:1: rule__ObjectType__Group_5_3__1__Impl : ( ( rule__ObjectType__CharacteristicAssignment_5_3_1 ) ) ;
    public final void rule__ObjectType__Group_5_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2424:1: ( ( ( rule__ObjectType__CharacteristicAssignment_5_3_1 ) ) )
            // InternalGameDsl.g:2425:1: ( ( rule__ObjectType__CharacteristicAssignment_5_3_1 ) )
            {
            // InternalGameDsl.g:2425:1: ( ( rule__ObjectType__CharacteristicAssignment_5_3_1 ) )
            // InternalGameDsl.g:2426:2: ( rule__ObjectType__CharacteristicAssignment_5_3_1 )
            {
             before(grammarAccess.getObjectTypeAccess().getCharacteristicAssignment_5_3_1()); 
            // InternalGameDsl.g:2427:2: ( rule__ObjectType__CharacteristicAssignment_5_3_1 )
            // InternalGameDsl.g:2427:3: rule__ObjectType__CharacteristicAssignment_5_3_1
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__CharacteristicAssignment_5_3_1();

            state._fsp--;


            }

             after(grammarAccess.getObjectTypeAccess().getCharacteristicAssignment_5_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_5_3__1__Impl"


    // $ANTLR start "rule__ObjectType__Group_6__0"
    // InternalGameDsl.g:2436:1: rule__ObjectType__Group_6__0 : rule__ObjectType__Group_6__0__Impl rule__ObjectType__Group_6__1 ;
    public final void rule__ObjectType__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2440:1: ( rule__ObjectType__Group_6__0__Impl rule__ObjectType__Group_6__1 )
            // InternalGameDsl.g:2441:2: rule__ObjectType__Group_6__0__Impl rule__ObjectType__Group_6__1
            {
            pushFollow(FOLLOW_5);
            rule__ObjectType__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6__0"


    // $ANTLR start "rule__ObjectType__Group_6__0__Impl"
    // InternalGameDsl.g:2448:1: rule__ObjectType__Group_6__0__Impl : ( 'gameObject' ) ;
    public final void rule__ObjectType__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2452:1: ( ( 'gameObject' ) )
            // InternalGameDsl.g:2453:1: ( 'gameObject' )
            {
            // InternalGameDsl.g:2453:1: ( 'gameObject' )
            // InternalGameDsl.g:2454:2: 'gameObject'
            {
             before(grammarAccess.getObjectTypeAccess().getGameObjectKeyword_6_0()); 
            match(input,32,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getGameObjectKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6__0__Impl"


    // $ANTLR start "rule__ObjectType__Group_6__1"
    // InternalGameDsl.g:2463:1: rule__ObjectType__Group_6__1 : rule__ObjectType__Group_6__1__Impl rule__ObjectType__Group_6__2 ;
    public final void rule__ObjectType__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2467:1: ( rule__ObjectType__Group_6__1__Impl rule__ObjectType__Group_6__2 )
            // InternalGameDsl.g:2468:2: rule__ObjectType__Group_6__1__Impl rule__ObjectType__Group_6__2
            {
            pushFollow(FOLLOW_21);
            rule__ObjectType__Group_6__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_6__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6__1"


    // $ANTLR start "rule__ObjectType__Group_6__1__Impl"
    // InternalGameDsl.g:2475:1: rule__ObjectType__Group_6__1__Impl : ( '{' ) ;
    public final void rule__ObjectType__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2479:1: ( ( '{' ) )
            // InternalGameDsl.g:2480:1: ( '{' )
            {
            // InternalGameDsl.g:2480:1: ( '{' )
            // InternalGameDsl.g:2481:2: '{'
            {
             before(grammarAccess.getObjectTypeAccess().getLeftCurlyBracketKeyword_6_1()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getLeftCurlyBracketKeyword_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6__1__Impl"


    // $ANTLR start "rule__ObjectType__Group_6__2"
    // InternalGameDsl.g:2490:1: rule__ObjectType__Group_6__2 : rule__ObjectType__Group_6__2__Impl rule__ObjectType__Group_6__3 ;
    public final void rule__ObjectType__Group_6__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2494:1: ( rule__ObjectType__Group_6__2__Impl rule__ObjectType__Group_6__3 )
            // InternalGameDsl.g:2495:2: rule__ObjectType__Group_6__2__Impl rule__ObjectType__Group_6__3
            {
            pushFollow(FOLLOW_8);
            rule__ObjectType__Group_6__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_6__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6__2"


    // $ANTLR start "rule__ObjectType__Group_6__2__Impl"
    // InternalGameDsl.g:2502:1: rule__ObjectType__Group_6__2__Impl : ( ( rule__ObjectType__GameobjectAssignment_6_2 ) ) ;
    public final void rule__ObjectType__Group_6__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2506:1: ( ( ( rule__ObjectType__GameobjectAssignment_6_2 ) ) )
            // InternalGameDsl.g:2507:1: ( ( rule__ObjectType__GameobjectAssignment_6_2 ) )
            {
            // InternalGameDsl.g:2507:1: ( ( rule__ObjectType__GameobjectAssignment_6_2 ) )
            // InternalGameDsl.g:2508:2: ( rule__ObjectType__GameobjectAssignment_6_2 )
            {
             before(grammarAccess.getObjectTypeAccess().getGameobjectAssignment_6_2()); 
            // InternalGameDsl.g:2509:2: ( rule__ObjectType__GameobjectAssignment_6_2 )
            // InternalGameDsl.g:2509:3: rule__ObjectType__GameobjectAssignment_6_2
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__GameobjectAssignment_6_2();

            state._fsp--;


            }

             after(grammarAccess.getObjectTypeAccess().getGameobjectAssignment_6_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6__2__Impl"


    // $ANTLR start "rule__ObjectType__Group_6__3"
    // InternalGameDsl.g:2517:1: rule__ObjectType__Group_6__3 : rule__ObjectType__Group_6__3__Impl rule__ObjectType__Group_6__4 ;
    public final void rule__ObjectType__Group_6__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2521:1: ( rule__ObjectType__Group_6__3__Impl rule__ObjectType__Group_6__4 )
            // InternalGameDsl.g:2522:2: rule__ObjectType__Group_6__3__Impl rule__ObjectType__Group_6__4
            {
            pushFollow(FOLLOW_8);
            rule__ObjectType__Group_6__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_6__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6__3"


    // $ANTLR start "rule__ObjectType__Group_6__3__Impl"
    // InternalGameDsl.g:2529:1: rule__ObjectType__Group_6__3__Impl : ( ( rule__ObjectType__Group_6_3__0 )* ) ;
    public final void rule__ObjectType__Group_6__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2533:1: ( ( ( rule__ObjectType__Group_6_3__0 )* ) )
            // InternalGameDsl.g:2534:1: ( ( rule__ObjectType__Group_6_3__0 )* )
            {
            // InternalGameDsl.g:2534:1: ( ( rule__ObjectType__Group_6_3__0 )* )
            // InternalGameDsl.g:2535:2: ( rule__ObjectType__Group_6_3__0 )*
            {
             before(grammarAccess.getObjectTypeAccess().getGroup_6_3()); 
            // InternalGameDsl.g:2536:2: ( rule__ObjectType__Group_6_3__0 )*
            loop20:
            do {
                int alt20=2;
                int LA20_0 = input.LA(1);

                if ( (LA20_0==19) ) {
                    alt20=1;
                }


                switch (alt20) {
            	case 1 :
            	    // InternalGameDsl.g:2536:3: rule__ObjectType__Group_6_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__ObjectType__Group_6_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop20;
                }
            } while (true);

             after(grammarAccess.getObjectTypeAccess().getGroup_6_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6__3__Impl"


    // $ANTLR start "rule__ObjectType__Group_6__4"
    // InternalGameDsl.g:2544:1: rule__ObjectType__Group_6__4 : rule__ObjectType__Group_6__4__Impl ;
    public final void rule__ObjectType__Group_6__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2548:1: ( rule__ObjectType__Group_6__4__Impl )
            // InternalGameDsl.g:2549:2: rule__ObjectType__Group_6__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_6__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6__4"


    // $ANTLR start "rule__ObjectType__Group_6__4__Impl"
    // InternalGameDsl.g:2555:1: rule__ObjectType__Group_6__4__Impl : ( '}' ) ;
    public final void rule__ObjectType__Group_6__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2559:1: ( ( '}' ) )
            // InternalGameDsl.g:2560:1: ( '}' )
            {
            // InternalGameDsl.g:2560:1: ( '}' )
            // InternalGameDsl.g:2561:2: '}'
            {
             before(grammarAccess.getObjectTypeAccess().getRightCurlyBracketKeyword_6_4()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getRightCurlyBracketKeyword_6_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6__4__Impl"


    // $ANTLR start "rule__ObjectType__Group_6_3__0"
    // InternalGameDsl.g:2571:1: rule__ObjectType__Group_6_3__0 : rule__ObjectType__Group_6_3__0__Impl rule__ObjectType__Group_6_3__1 ;
    public final void rule__ObjectType__Group_6_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2575:1: ( rule__ObjectType__Group_6_3__0__Impl rule__ObjectType__Group_6_3__1 )
            // InternalGameDsl.g:2576:2: rule__ObjectType__Group_6_3__0__Impl rule__ObjectType__Group_6_3__1
            {
            pushFollow(FOLLOW_21);
            rule__ObjectType__Group_6_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_6_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6_3__0"


    // $ANTLR start "rule__ObjectType__Group_6_3__0__Impl"
    // InternalGameDsl.g:2583:1: rule__ObjectType__Group_6_3__0__Impl : ( ',' ) ;
    public final void rule__ObjectType__Group_6_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2587:1: ( ( ',' ) )
            // InternalGameDsl.g:2588:1: ( ',' )
            {
            // InternalGameDsl.g:2588:1: ( ',' )
            // InternalGameDsl.g:2589:2: ','
            {
             before(grammarAccess.getObjectTypeAccess().getCommaKeyword_6_3_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getObjectTypeAccess().getCommaKeyword_6_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6_3__0__Impl"


    // $ANTLR start "rule__ObjectType__Group_6_3__1"
    // InternalGameDsl.g:2598:1: rule__ObjectType__Group_6_3__1 : rule__ObjectType__Group_6_3__1__Impl ;
    public final void rule__ObjectType__Group_6_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2602:1: ( rule__ObjectType__Group_6_3__1__Impl )
            // InternalGameDsl.g:2603:2: rule__ObjectType__Group_6_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__Group_6_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6_3__1"


    // $ANTLR start "rule__ObjectType__Group_6_3__1__Impl"
    // InternalGameDsl.g:2609:1: rule__ObjectType__Group_6_3__1__Impl : ( ( rule__ObjectType__GameobjectAssignment_6_3_1 ) ) ;
    public final void rule__ObjectType__Group_6_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2613:1: ( ( ( rule__ObjectType__GameobjectAssignment_6_3_1 ) ) )
            // InternalGameDsl.g:2614:1: ( ( rule__ObjectType__GameobjectAssignment_6_3_1 ) )
            {
            // InternalGameDsl.g:2614:1: ( ( rule__ObjectType__GameobjectAssignment_6_3_1 ) )
            // InternalGameDsl.g:2615:2: ( rule__ObjectType__GameobjectAssignment_6_3_1 )
            {
             before(grammarAccess.getObjectTypeAccess().getGameobjectAssignment_6_3_1()); 
            // InternalGameDsl.g:2616:2: ( rule__ObjectType__GameobjectAssignment_6_3_1 )
            // InternalGameDsl.g:2616:3: rule__ObjectType__GameobjectAssignment_6_3_1
            {
            pushFollow(FOLLOW_2);
            rule__ObjectType__GameobjectAssignment_6_3_1();

            state._fsp--;


            }

             after(grammarAccess.getObjectTypeAccess().getGameobjectAssignment_6_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__Group_6_3__1__Impl"


    // $ANTLR start "rule__GameObject__Group__0"
    // InternalGameDsl.g:2625:1: rule__GameObject__Group__0 : rule__GameObject__Group__0__Impl rule__GameObject__Group__1 ;
    public final void rule__GameObject__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2629:1: ( rule__GameObject__Group__0__Impl rule__GameObject__Group__1 )
            // InternalGameDsl.g:2630:2: rule__GameObject__Group__0__Impl rule__GameObject__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__GameObject__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__0"


    // $ANTLR start "rule__GameObject__Group__0__Impl"
    // InternalGameDsl.g:2637:1: rule__GameObject__Group__0__Impl : ( 'GameObject' ) ;
    public final void rule__GameObject__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2641:1: ( ( 'GameObject' ) )
            // InternalGameDsl.g:2642:1: ( 'GameObject' )
            {
            // InternalGameDsl.g:2642:1: ( 'GameObject' )
            // InternalGameDsl.g:2643:2: 'GameObject'
            {
             before(grammarAccess.getGameObjectAccess().getGameObjectKeyword_0()); 
            match(input,33,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getGameObjectKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__0__Impl"


    // $ANTLR start "rule__GameObject__Group__1"
    // InternalGameDsl.g:2652:1: rule__GameObject__Group__1 : rule__GameObject__Group__1__Impl rule__GameObject__Group__2 ;
    public final void rule__GameObject__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2656:1: ( rule__GameObject__Group__1__Impl rule__GameObject__Group__2 )
            // InternalGameDsl.g:2657:2: rule__GameObject__Group__1__Impl rule__GameObject__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__GameObject__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__1"


    // $ANTLR start "rule__GameObject__Group__1__Impl"
    // InternalGameDsl.g:2664:1: rule__GameObject__Group__1__Impl : ( ( rule__GameObject__IdentifierAssignment_1 ) ) ;
    public final void rule__GameObject__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2668:1: ( ( ( rule__GameObject__IdentifierAssignment_1 ) ) )
            // InternalGameDsl.g:2669:1: ( ( rule__GameObject__IdentifierAssignment_1 ) )
            {
            // InternalGameDsl.g:2669:1: ( ( rule__GameObject__IdentifierAssignment_1 ) )
            // InternalGameDsl.g:2670:2: ( rule__GameObject__IdentifierAssignment_1 )
            {
             before(grammarAccess.getGameObjectAccess().getIdentifierAssignment_1()); 
            // InternalGameDsl.g:2671:2: ( rule__GameObject__IdentifierAssignment_1 )
            // InternalGameDsl.g:2671:3: rule__GameObject__IdentifierAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__IdentifierAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getIdentifierAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__1__Impl"


    // $ANTLR start "rule__GameObject__Group__2"
    // InternalGameDsl.g:2679:1: rule__GameObject__Group__2 : rule__GameObject__Group__2__Impl rule__GameObject__Group__3 ;
    public final void rule__GameObject__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2683:1: ( rule__GameObject__Group__2__Impl rule__GameObject__Group__3 )
            // InternalGameDsl.g:2684:2: rule__GameObject__Group__2__Impl rule__GameObject__Group__3
            {
            pushFollow(FOLLOW_12);
            rule__GameObject__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__2"


    // $ANTLR start "rule__GameObject__Group__2__Impl"
    // InternalGameDsl.g:2691:1: rule__GameObject__Group__2__Impl : ( '{' ) ;
    public final void rule__GameObject__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2695:1: ( ( '{' ) )
            // InternalGameDsl.g:2696:1: ( '{' )
            {
            // InternalGameDsl.g:2696:1: ( '{' )
            // InternalGameDsl.g:2697:2: '{'
            {
             before(grammarAccess.getGameObjectAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__2__Impl"


    // $ANTLR start "rule__GameObject__Group__3"
    // InternalGameDsl.g:2706:1: rule__GameObject__Group__3 : rule__GameObject__Group__3__Impl rule__GameObject__Group__4 ;
    public final void rule__GameObject__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2710:1: ( rule__GameObject__Group__3__Impl rule__GameObject__Group__4 )
            // InternalGameDsl.g:2711:2: rule__GameObject__Group__3__Impl rule__GameObject__Group__4
            {
            pushFollow(FOLLOW_13);
            rule__GameObject__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__3"


    // $ANTLR start "rule__GameObject__Group__3__Impl"
    // InternalGameDsl.g:2718:1: rule__GameObject__Group__3__Impl : ( 'coordinates' ) ;
    public final void rule__GameObject__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2722:1: ( ( 'coordinates' ) )
            // InternalGameDsl.g:2723:1: ( 'coordinates' )
            {
            // InternalGameDsl.g:2723:1: ( 'coordinates' )
            // InternalGameDsl.g:2724:2: 'coordinates'
            {
             before(grammarAccess.getGameObjectAccess().getCoordinatesKeyword_3()); 
            match(input,23,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getCoordinatesKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__3__Impl"


    // $ANTLR start "rule__GameObject__Group__4"
    // InternalGameDsl.g:2733:1: rule__GameObject__Group__4 : rule__GameObject__Group__4__Impl rule__GameObject__Group__5 ;
    public final void rule__GameObject__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2737:1: ( rule__GameObject__Group__4__Impl rule__GameObject__Group__5 )
            // InternalGameDsl.g:2738:2: rule__GameObject__Group__4__Impl rule__GameObject__Group__5
            {
            pushFollow(FOLLOW_14);
            rule__GameObject__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__4"


    // $ANTLR start "rule__GameObject__Group__4__Impl"
    // InternalGameDsl.g:2745:1: rule__GameObject__Group__4__Impl : ( '(' ) ;
    public final void rule__GameObject__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2749:1: ( ( '(' ) )
            // InternalGameDsl.g:2750:1: ( '(' )
            {
            // InternalGameDsl.g:2750:1: ( '(' )
            // InternalGameDsl.g:2751:2: '('
            {
             before(grammarAccess.getGameObjectAccess().getLeftParenthesisKeyword_4()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getLeftParenthesisKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__4__Impl"


    // $ANTLR start "rule__GameObject__Group__5"
    // InternalGameDsl.g:2760:1: rule__GameObject__Group__5 : rule__GameObject__Group__5__Impl rule__GameObject__Group__6 ;
    public final void rule__GameObject__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2764:1: ( rule__GameObject__Group__5__Impl rule__GameObject__Group__6 )
            // InternalGameDsl.g:2765:2: rule__GameObject__Group__5__Impl rule__GameObject__Group__6
            {
            pushFollow(FOLLOW_15);
            rule__GameObject__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__5"


    // $ANTLR start "rule__GameObject__Group__5__Impl"
    // InternalGameDsl.g:2772:1: rule__GameObject__Group__5__Impl : ( ( rule__GameObject__CoordinatesAssignment_5 ) ) ;
    public final void rule__GameObject__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2776:1: ( ( ( rule__GameObject__CoordinatesAssignment_5 ) ) )
            // InternalGameDsl.g:2777:1: ( ( rule__GameObject__CoordinatesAssignment_5 ) )
            {
            // InternalGameDsl.g:2777:1: ( ( rule__GameObject__CoordinatesAssignment_5 ) )
            // InternalGameDsl.g:2778:2: ( rule__GameObject__CoordinatesAssignment_5 )
            {
             before(grammarAccess.getGameObjectAccess().getCoordinatesAssignment_5()); 
            // InternalGameDsl.g:2779:2: ( rule__GameObject__CoordinatesAssignment_5 )
            // InternalGameDsl.g:2779:3: rule__GameObject__CoordinatesAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__CoordinatesAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getCoordinatesAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__5__Impl"


    // $ANTLR start "rule__GameObject__Group__6"
    // InternalGameDsl.g:2787:1: rule__GameObject__Group__6 : rule__GameObject__Group__6__Impl rule__GameObject__Group__7 ;
    public final void rule__GameObject__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2791:1: ( rule__GameObject__Group__6__Impl rule__GameObject__Group__7 )
            // InternalGameDsl.g:2792:2: rule__GameObject__Group__6__Impl rule__GameObject__Group__7
            {
            pushFollow(FOLLOW_15);
            rule__GameObject__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__6"


    // $ANTLR start "rule__GameObject__Group__6__Impl"
    // InternalGameDsl.g:2799:1: rule__GameObject__Group__6__Impl : ( ( rule__GameObject__Group_6__0 )* ) ;
    public final void rule__GameObject__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2803:1: ( ( ( rule__GameObject__Group_6__0 )* ) )
            // InternalGameDsl.g:2804:1: ( ( rule__GameObject__Group_6__0 )* )
            {
            // InternalGameDsl.g:2804:1: ( ( rule__GameObject__Group_6__0 )* )
            // InternalGameDsl.g:2805:2: ( rule__GameObject__Group_6__0 )*
            {
             before(grammarAccess.getGameObjectAccess().getGroup_6()); 
            // InternalGameDsl.g:2806:2: ( rule__GameObject__Group_6__0 )*
            loop21:
            do {
                int alt21=2;
                int LA21_0 = input.LA(1);

                if ( (LA21_0==19) ) {
                    alt21=1;
                }


                switch (alt21) {
            	case 1 :
            	    // InternalGameDsl.g:2806:3: rule__GameObject__Group_6__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__GameObject__Group_6__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop21;
                }
            } while (true);

             after(grammarAccess.getGameObjectAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__6__Impl"


    // $ANTLR start "rule__GameObject__Group__7"
    // InternalGameDsl.g:2814:1: rule__GameObject__Group__7 : rule__GameObject__Group__7__Impl rule__GameObject__Group__8 ;
    public final void rule__GameObject__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2818:1: ( rule__GameObject__Group__7__Impl rule__GameObject__Group__8 )
            // InternalGameDsl.g:2819:2: rule__GameObject__Group__7__Impl rule__GameObject__Group__8
            {
            pushFollow(FOLLOW_16);
            rule__GameObject__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__7"


    // $ANTLR start "rule__GameObject__Group__7__Impl"
    // InternalGameDsl.g:2826:1: rule__GameObject__Group__7__Impl : ( ')' ) ;
    public final void rule__GameObject__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2830:1: ( ( ')' ) )
            // InternalGameDsl.g:2831:1: ( ')' )
            {
            // InternalGameDsl.g:2831:1: ( ')' )
            // InternalGameDsl.g:2832:2: ')'
            {
             before(grammarAccess.getGameObjectAccess().getRightParenthesisKeyword_7()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getRightParenthesisKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__7__Impl"


    // $ANTLR start "rule__GameObject__Group__8"
    // InternalGameDsl.g:2841:1: rule__GameObject__Group__8 : rule__GameObject__Group__8__Impl rule__GameObject__Group__9 ;
    public final void rule__GameObject__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2845:1: ( rule__GameObject__Group__8__Impl rule__GameObject__Group__9 )
            // InternalGameDsl.g:2846:2: rule__GameObject__Group__8__Impl rule__GameObject__Group__9
            {
            pushFollow(FOLLOW_13);
            rule__GameObject__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__8"


    // $ANTLR start "rule__GameObject__Group__8__Impl"
    // InternalGameDsl.g:2853:1: rule__GameObject__Group__8__Impl : ( 'size' ) ;
    public final void rule__GameObject__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2857:1: ( ( 'size' ) )
            // InternalGameDsl.g:2858:1: ( 'size' )
            {
            // InternalGameDsl.g:2858:1: ( 'size' )
            // InternalGameDsl.g:2859:2: 'size'
            {
             before(grammarAccess.getGameObjectAccess().getSizeKeyword_8()); 
            match(input,26,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getSizeKeyword_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__8__Impl"


    // $ANTLR start "rule__GameObject__Group__9"
    // InternalGameDsl.g:2868:1: rule__GameObject__Group__9 : rule__GameObject__Group__9__Impl rule__GameObject__Group__10 ;
    public final void rule__GameObject__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2872:1: ( rule__GameObject__Group__9__Impl rule__GameObject__Group__10 )
            // InternalGameDsl.g:2873:2: rule__GameObject__Group__9__Impl rule__GameObject__Group__10
            {
            pushFollow(FOLLOW_14);
            rule__GameObject__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__9"


    // $ANTLR start "rule__GameObject__Group__9__Impl"
    // InternalGameDsl.g:2880:1: rule__GameObject__Group__9__Impl : ( '(' ) ;
    public final void rule__GameObject__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2884:1: ( ( '(' ) )
            // InternalGameDsl.g:2885:1: ( '(' )
            {
            // InternalGameDsl.g:2885:1: ( '(' )
            // InternalGameDsl.g:2886:2: '('
            {
             before(grammarAccess.getGameObjectAccess().getLeftParenthesisKeyword_9()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getLeftParenthesisKeyword_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__9__Impl"


    // $ANTLR start "rule__GameObject__Group__10"
    // InternalGameDsl.g:2895:1: rule__GameObject__Group__10 : rule__GameObject__Group__10__Impl rule__GameObject__Group__11 ;
    public final void rule__GameObject__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2899:1: ( rule__GameObject__Group__10__Impl rule__GameObject__Group__11 )
            // InternalGameDsl.g:2900:2: rule__GameObject__Group__10__Impl rule__GameObject__Group__11
            {
            pushFollow(FOLLOW_15);
            rule__GameObject__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__10"


    // $ANTLR start "rule__GameObject__Group__10__Impl"
    // InternalGameDsl.g:2907:1: rule__GameObject__Group__10__Impl : ( ( rule__GameObject__SizeAssignment_10 ) ) ;
    public final void rule__GameObject__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2911:1: ( ( ( rule__GameObject__SizeAssignment_10 ) ) )
            // InternalGameDsl.g:2912:1: ( ( rule__GameObject__SizeAssignment_10 ) )
            {
            // InternalGameDsl.g:2912:1: ( ( rule__GameObject__SizeAssignment_10 ) )
            // InternalGameDsl.g:2913:2: ( rule__GameObject__SizeAssignment_10 )
            {
             before(grammarAccess.getGameObjectAccess().getSizeAssignment_10()); 
            // InternalGameDsl.g:2914:2: ( rule__GameObject__SizeAssignment_10 )
            // InternalGameDsl.g:2914:3: rule__GameObject__SizeAssignment_10
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__SizeAssignment_10();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getSizeAssignment_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__10__Impl"


    // $ANTLR start "rule__GameObject__Group__11"
    // InternalGameDsl.g:2922:1: rule__GameObject__Group__11 : rule__GameObject__Group__11__Impl rule__GameObject__Group__12 ;
    public final void rule__GameObject__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2926:1: ( rule__GameObject__Group__11__Impl rule__GameObject__Group__12 )
            // InternalGameDsl.g:2927:2: rule__GameObject__Group__11__Impl rule__GameObject__Group__12
            {
            pushFollow(FOLLOW_15);
            rule__GameObject__Group__11__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__12();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__11"


    // $ANTLR start "rule__GameObject__Group__11__Impl"
    // InternalGameDsl.g:2934:1: rule__GameObject__Group__11__Impl : ( ( rule__GameObject__Group_11__0 )* ) ;
    public final void rule__GameObject__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2938:1: ( ( ( rule__GameObject__Group_11__0 )* ) )
            // InternalGameDsl.g:2939:1: ( ( rule__GameObject__Group_11__0 )* )
            {
            // InternalGameDsl.g:2939:1: ( ( rule__GameObject__Group_11__0 )* )
            // InternalGameDsl.g:2940:2: ( rule__GameObject__Group_11__0 )*
            {
             before(grammarAccess.getGameObjectAccess().getGroup_11()); 
            // InternalGameDsl.g:2941:2: ( rule__GameObject__Group_11__0 )*
            loop22:
            do {
                int alt22=2;
                int LA22_0 = input.LA(1);

                if ( (LA22_0==19) ) {
                    alt22=1;
                }


                switch (alt22) {
            	case 1 :
            	    // InternalGameDsl.g:2941:3: rule__GameObject__Group_11__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__GameObject__Group_11__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop22;
                }
            } while (true);

             after(grammarAccess.getGameObjectAccess().getGroup_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__11__Impl"


    // $ANTLR start "rule__GameObject__Group__12"
    // InternalGameDsl.g:2949:1: rule__GameObject__Group__12 : rule__GameObject__Group__12__Impl rule__GameObject__Group__13 ;
    public final void rule__GameObject__Group__12() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2953:1: ( rule__GameObject__Group__12__Impl rule__GameObject__Group__13 )
            // InternalGameDsl.g:2954:2: rule__GameObject__Group__12__Impl rule__GameObject__Group__13
            {
            pushFollow(FOLLOW_22);
            rule__GameObject__Group__12__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__13();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__12"


    // $ANTLR start "rule__GameObject__Group__12__Impl"
    // InternalGameDsl.g:2961:1: rule__GameObject__Group__12__Impl : ( ')' ) ;
    public final void rule__GameObject__Group__12__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2965:1: ( ( ')' ) )
            // InternalGameDsl.g:2966:1: ( ')' )
            {
            // InternalGameDsl.g:2966:1: ( ')' )
            // InternalGameDsl.g:2967:2: ')'
            {
             before(grammarAccess.getGameObjectAccess().getRightParenthesisKeyword_12()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getRightParenthesisKeyword_12()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__12__Impl"


    // $ANTLR start "rule__GameObject__Group__13"
    // InternalGameDsl.g:2976:1: rule__GameObject__Group__13 : rule__GameObject__Group__13__Impl rule__GameObject__Group__14 ;
    public final void rule__GameObject__Group__13() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2980:1: ( rule__GameObject__Group__13__Impl rule__GameObject__Group__14 )
            // InternalGameDsl.g:2981:2: rule__GameObject__Group__13__Impl rule__GameObject__Group__14
            {
            pushFollow(FOLLOW_4);
            rule__GameObject__Group__13__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__14();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__13"


    // $ANTLR start "rule__GameObject__Group__13__Impl"
    // InternalGameDsl.g:2988:1: rule__GameObject__Group__13__Impl : ( 'sprite:' ) ;
    public final void rule__GameObject__Group__13__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:2992:1: ( ( 'sprite:' ) )
            // InternalGameDsl.g:2993:1: ( 'sprite:' )
            {
            // InternalGameDsl.g:2993:1: ( 'sprite:' )
            // InternalGameDsl.g:2994:2: 'sprite:'
            {
             before(grammarAccess.getGameObjectAccess().getSpriteKeyword_13()); 
            match(input,34,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getSpriteKeyword_13()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__13__Impl"


    // $ANTLR start "rule__GameObject__Group__14"
    // InternalGameDsl.g:3003:1: rule__GameObject__Group__14 : rule__GameObject__Group__14__Impl rule__GameObject__Group__15 ;
    public final void rule__GameObject__Group__14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3007:1: ( rule__GameObject__Group__14__Impl rule__GameObject__Group__15 )
            // InternalGameDsl.g:3008:2: rule__GameObject__Group__14__Impl rule__GameObject__Group__15
            {
            pushFollow(FOLLOW_23);
            rule__GameObject__Group__14__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__15();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__14"


    // $ANTLR start "rule__GameObject__Group__14__Impl"
    // InternalGameDsl.g:3015:1: rule__GameObject__Group__14__Impl : ( ( rule__GameObject__SpriteAssignment_14 ) ) ;
    public final void rule__GameObject__Group__14__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3019:1: ( ( ( rule__GameObject__SpriteAssignment_14 ) ) )
            // InternalGameDsl.g:3020:1: ( ( rule__GameObject__SpriteAssignment_14 ) )
            {
            // InternalGameDsl.g:3020:1: ( ( rule__GameObject__SpriteAssignment_14 ) )
            // InternalGameDsl.g:3021:2: ( rule__GameObject__SpriteAssignment_14 )
            {
             before(grammarAccess.getGameObjectAccess().getSpriteAssignment_14()); 
            // InternalGameDsl.g:3022:2: ( rule__GameObject__SpriteAssignment_14 )
            // InternalGameDsl.g:3022:3: rule__GameObject__SpriteAssignment_14
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__SpriteAssignment_14();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getSpriteAssignment_14()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__14__Impl"


    // $ANTLR start "rule__GameObject__Group__15"
    // InternalGameDsl.g:3030:1: rule__GameObject__Group__15 : rule__GameObject__Group__15__Impl rule__GameObject__Group__16 ;
    public final void rule__GameObject__Group__15() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3034:1: ( rule__GameObject__Group__15__Impl rule__GameObject__Group__16 )
            // InternalGameDsl.g:3035:2: rule__GameObject__Group__15__Impl rule__GameObject__Group__16
            {
            pushFollow(FOLLOW_23);
            rule__GameObject__Group__15__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__16();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__15"


    // $ANTLR start "rule__GameObject__Group__15__Impl"
    // InternalGameDsl.g:3042:1: rule__GameObject__Group__15__Impl : ( ( rule__GameObject__Group_15__0 )? ) ;
    public final void rule__GameObject__Group__15__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3046:1: ( ( ( rule__GameObject__Group_15__0 )? ) )
            // InternalGameDsl.g:3047:1: ( ( rule__GameObject__Group_15__0 )? )
            {
            // InternalGameDsl.g:3047:1: ( ( rule__GameObject__Group_15__0 )? )
            // InternalGameDsl.g:3048:2: ( rule__GameObject__Group_15__0 )?
            {
             before(grammarAccess.getGameObjectAccess().getGroup_15()); 
            // InternalGameDsl.g:3049:2: ( rule__GameObject__Group_15__0 )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( (LA23_0==37) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalGameDsl.g:3049:3: rule__GameObject__Group_15__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__GameObject__Group_15__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameObjectAccess().getGroup_15()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__15__Impl"


    // $ANTLR start "rule__GameObject__Group__16"
    // InternalGameDsl.g:3057:1: rule__GameObject__Group__16 : rule__GameObject__Group__16__Impl rule__GameObject__Group__17 ;
    public final void rule__GameObject__Group__16() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3061:1: ( rule__GameObject__Group__16__Impl rule__GameObject__Group__17 )
            // InternalGameDsl.g:3062:2: rule__GameObject__Group__16__Impl rule__GameObject__Group__17
            {
            pushFollow(FOLLOW_23);
            rule__GameObject__Group__16__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__17();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__16"


    // $ANTLR start "rule__GameObject__Group__16__Impl"
    // InternalGameDsl.g:3069:1: rule__GameObject__Group__16__Impl : ( ( rule__GameObject__Group_16__0 )? ) ;
    public final void rule__GameObject__Group__16__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3073:1: ( ( ( rule__GameObject__Group_16__0 )? ) )
            // InternalGameDsl.g:3074:1: ( ( rule__GameObject__Group_16__0 )? )
            {
            // InternalGameDsl.g:3074:1: ( ( rule__GameObject__Group_16__0 )? )
            // InternalGameDsl.g:3075:2: ( rule__GameObject__Group_16__0 )?
            {
             before(grammarAccess.getGameObjectAccess().getGroup_16()); 
            // InternalGameDsl.g:3076:2: ( rule__GameObject__Group_16__0 )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==38) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalGameDsl.g:3076:3: rule__GameObject__Group_16__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__GameObject__Group_16__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameObjectAccess().getGroup_16()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__16__Impl"


    // $ANTLR start "rule__GameObject__Group__17"
    // InternalGameDsl.g:3084:1: rule__GameObject__Group__17 : rule__GameObject__Group__17__Impl rule__GameObject__Group__18 ;
    public final void rule__GameObject__Group__17() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3088:1: ( rule__GameObject__Group__17__Impl rule__GameObject__Group__18 )
            // InternalGameDsl.g:3089:2: rule__GameObject__Group__17__Impl rule__GameObject__Group__18
            {
            pushFollow(FOLLOW_23);
            rule__GameObject__Group__17__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__18();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__17"


    // $ANTLR start "rule__GameObject__Group__17__Impl"
    // InternalGameDsl.g:3096:1: rule__GameObject__Group__17__Impl : ( ( rule__GameObject__Group_17__0 )? ) ;
    public final void rule__GameObject__Group__17__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3100:1: ( ( ( rule__GameObject__Group_17__0 )? ) )
            // InternalGameDsl.g:3101:1: ( ( rule__GameObject__Group_17__0 )? )
            {
            // InternalGameDsl.g:3101:1: ( ( rule__GameObject__Group_17__0 )? )
            // InternalGameDsl.g:3102:2: ( rule__GameObject__Group_17__0 )?
            {
             before(grammarAccess.getGameObjectAccess().getGroup_17()); 
            // InternalGameDsl.g:3103:2: ( rule__GameObject__Group_17__0 )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==39) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalGameDsl.g:3103:3: rule__GameObject__Group_17__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__GameObject__Group_17__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameObjectAccess().getGroup_17()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__17__Impl"


    // $ANTLR start "rule__GameObject__Group__18"
    // InternalGameDsl.g:3111:1: rule__GameObject__Group__18 : rule__GameObject__Group__18__Impl rule__GameObject__Group__19 ;
    public final void rule__GameObject__Group__18() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3115:1: ( rule__GameObject__Group__18__Impl rule__GameObject__Group__19 )
            // InternalGameDsl.g:3116:2: rule__GameObject__Group__18__Impl rule__GameObject__Group__19
            {
            pushFollow(FOLLOW_24);
            rule__GameObject__Group__18__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__19();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__18"


    // $ANTLR start "rule__GameObject__Group__18__Impl"
    // InternalGameDsl.g:3123:1: rule__GameObject__Group__18__Impl : ( 'velocity:' ) ;
    public final void rule__GameObject__Group__18__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3127:1: ( ( 'velocity:' ) )
            // InternalGameDsl.g:3128:1: ( 'velocity:' )
            {
            // InternalGameDsl.g:3128:1: ( 'velocity:' )
            // InternalGameDsl.g:3129:2: 'velocity:'
            {
             before(grammarAccess.getGameObjectAccess().getVelocityKeyword_18()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getVelocityKeyword_18()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__18__Impl"


    // $ANTLR start "rule__GameObject__Group__19"
    // InternalGameDsl.g:3138:1: rule__GameObject__Group__19 : rule__GameObject__Group__19__Impl rule__GameObject__Group__20 ;
    public final void rule__GameObject__Group__19() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3142:1: ( rule__GameObject__Group__19__Impl rule__GameObject__Group__20 )
            // InternalGameDsl.g:3143:2: rule__GameObject__Group__19__Impl rule__GameObject__Group__20
            {
            pushFollow(FOLLOW_25);
            rule__GameObject__Group__19__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__20();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__19"


    // $ANTLR start "rule__GameObject__Group__19__Impl"
    // InternalGameDsl.g:3150:1: rule__GameObject__Group__19__Impl : ( ( rule__GameObject__VelocityAssignment_19 ) ) ;
    public final void rule__GameObject__Group__19__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3154:1: ( ( ( rule__GameObject__VelocityAssignment_19 ) ) )
            // InternalGameDsl.g:3155:1: ( ( rule__GameObject__VelocityAssignment_19 ) )
            {
            // InternalGameDsl.g:3155:1: ( ( rule__GameObject__VelocityAssignment_19 ) )
            // InternalGameDsl.g:3156:2: ( rule__GameObject__VelocityAssignment_19 )
            {
             before(grammarAccess.getGameObjectAccess().getVelocityAssignment_19()); 
            // InternalGameDsl.g:3157:2: ( rule__GameObject__VelocityAssignment_19 )
            // InternalGameDsl.g:3157:3: rule__GameObject__VelocityAssignment_19
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__VelocityAssignment_19();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getVelocityAssignment_19()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__19__Impl"


    // $ANTLR start "rule__GameObject__Group__20"
    // InternalGameDsl.g:3165:1: rule__GameObject__Group__20 : rule__GameObject__Group__20__Impl rule__GameObject__Group__21 ;
    public final void rule__GameObject__Group__20() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3169:1: ( rule__GameObject__Group__20__Impl rule__GameObject__Group__21 )
            // InternalGameDsl.g:3170:2: rule__GameObject__Group__20__Impl rule__GameObject__Group__21
            {
            pushFollow(FOLLOW_13);
            rule__GameObject__Group__20__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__21();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__20"


    // $ANTLR start "rule__GameObject__Group__20__Impl"
    // InternalGameDsl.g:3177:1: rule__GameObject__Group__20__Impl : ( 'directionDegrees' ) ;
    public final void rule__GameObject__Group__20__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3181:1: ( ( 'directionDegrees' ) )
            // InternalGameDsl.g:3182:1: ( 'directionDegrees' )
            {
            // InternalGameDsl.g:3182:1: ( 'directionDegrees' )
            // InternalGameDsl.g:3183:2: 'directionDegrees'
            {
             before(grammarAccess.getGameObjectAccess().getDirectionDegreesKeyword_20()); 
            match(input,36,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getDirectionDegreesKeyword_20()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__20__Impl"


    // $ANTLR start "rule__GameObject__Group__21"
    // InternalGameDsl.g:3192:1: rule__GameObject__Group__21 : rule__GameObject__Group__21__Impl rule__GameObject__Group__22 ;
    public final void rule__GameObject__Group__21() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3196:1: ( rule__GameObject__Group__21__Impl rule__GameObject__Group__22 )
            // InternalGameDsl.g:3197:2: rule__GameObject__Group__21__Impl rule__GameObject__Group__22
            {
            pushFollow(FOLLOW_24);
            rule__GameObject__Group__21__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__22();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__21"


    // $ANTLR start "rule__GameObject__Group__21__Impl"
    // InternalGameDsl.g:3204:1: rule__GameObject__Group__21__Impl : ( '(' ) ;
    public final void rule__GameObject__Group__21__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3208:1: ( ( '(' ) )
            // InternalGameDsl.g:3209:1: ( '(' )
            {
            // InternalGameDsl.g:3209:1: ( '(' )
            // InternalGameDsl.g:3210:2: '('
            {
             before(grammarAccess.getGameObjectAccess().getLeftParenthesisKeyword_21()); 
            match(input,24,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getLeftParenthesisKeyword_21()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__21__Impl"


    // $ANTLR start "rule__GameObject__Group__22"
    // InternalGameDsl.g:3219:1: rule__GameObject__Group__22 : rule__GameObject__Group__22__Impl rule__GameObject__Group__23 ;
    public final void rule__GameObject__Group__22() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3223:1: ( rule__GameObject__Group__22__Impl rule__GameObject__Group__23 )
            // InternalGameDsl.g:3224:2: rule__GameObject__Group__22__Impl rule__GameObject__Group__23
            {
            pushFollow(FOLLOW_15);
            rule__GameObject__Group__22__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__23();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__22"


    // $ANTLR start "rule__GameObject__Group__22__Impl"
    // InternalGameDsl.g:3231:1: rule__GameObject__Group__22__Impl : ( ( rule__GameObject__DirectionDegreesAssignment_22 ) ) ;
    public final void rule__GameObject__Group__22__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3235:1: ( ( ( rule__GameObject__DirectionDegreesAssignment_22 ) ) )
            // InternalGameDsl.g:3236:1: ( ( rule__GameObject__DirectionDegreesAssignment_22 ) )
            {
            // InternalGameDsl.g:3236:1: ( ( rule__GameObject__DirectionDegreesAssignment_22 ) )
            // InternalGameDsl.g:3237:2: ( rule__GameObject__DirectionDegreesAssignment_22 )
            {
             before(grammarAccess.getGameObjectAccess().getDirectionDegreesAssignment_22()); 
            // InternalGameDsl.g:3238:2: ( rule__GameObject__DirectionDegreesAssignment_22 )
            // InternalGameDsl.g:3238:3: rule__GameObject__DirectionDegreesAssignment_22
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__DirectionDegreesAssignment_22();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getDirectionDegreesAssignment_22()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__22__Impl"


    // $ANTLR start "rule__GameObject__Group__23"
    // InternalGameDsl.g:3246:1: rule__GameObject__Group__23 : rule__GameObject__Group__23__Impl rule__GameObject__Group__24 ;
    public final void rule__GameObject__Group__23() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3250:1: ( rule__GameObject__Group__23__Impl rule__GameObject__Group__24 )
            // InternalGameDsl.g:3251:2: rule__GameObject__Group__23__Impl rule__GameObject__Group__24
            {
            pushFollow(FOLLOW_15);
            rule__GameObject__Group__23__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__24();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__23"


    // $ANTLR start "rule__GameObject__Group__23__Impl"
    // InternalGameDsl.g:3258:1: rule__GameObject__Group__23__Impl : ( ( rule__GameObject__Group_23__0 )* ) ;
    public final void rule__GameObject__Group__23__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3262:1: ( ( ( rule__GameObject__Group_23__0 )* ) )
            // InternalGameDsl.g:3263:1: ( ( rule__GameObject__Group_23__0 )* )
            {
            // InternalGameDsl.g:3263:1: ( ( rule__GameObject__Group_23__0 )* )
            // InternalGameDsl.g:3264:2: ( rule__GameObject__Group_23__0 )*
            {
             before(grammarAccess.getGameObjectAccess().getGroup_23()); 
            // InternalGameDsl.g:3265:2: ( rule__GameObject__Group_23__0 )*
            loop26:
            do {
                int alt26=2;
                int LA26_0 = input.LA(1);

                if ( (LA26_0==19) ) {
                    alt26=1;
                }


                switch (alt26) {
            	case 1 :
            	    // InternalGameDsl.g:3265:3: rule__GameObject__Group_23__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__GameObject__Group_23__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop26;
                }
            } while (true);

             after(grammarAccess.getGameObjectAccess().getGroup_23()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__23__Impl"


    // $ANTLR start "rule__GameObject__Group__24"
    // InternalGameDsl.g:3273:1: rule__GameObject__Group__24 : rule__GameObject__Group__24__Impl rule__GameObject__Group__25 ;
    public final void rule__GameObject__Group__24() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3277:1: ( rule__GameObject__Group__24__Impl rule__GameObject__Group__25 )
            // InternalGameDsl.g:3278:2: rule__GameObject__Group__24__Impl rule__GameObject__Group__25
            {
            pushFollow(FOLLOW_26);
            rule__GameObject__Group__24__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__25();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__24"


    // $ANTLR start "rule__GameObject__Group__24__Impl"
    // InternalGameDsl.g:3285:1: rule__GameObject__Group__24__Impl : ( ')' ) ;
    public final void rule__GameObject__Group__24__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3289:1: ( ( ')' ) )
            // InternalGameDsl.g:3290:1: ( ')' )
            {
            // InternalGameDsl.g:3290:1: ( ')' )
            // InternalGameDsl.g:3291:2: ')'
            {
             before(grammarAccess.getGameObjectAccess().getRightParenthesisKeyword_24()); 
            match(input,25,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getRightParenthesisKeyword_24()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__24__Impl"


    // $ANTLR start "rule__GameObject__Group__25"
    // InternalGameDsl.g:3300:1: rule__GameObject__Group__25 : rule__GameObject__Group__25__Impl rule__GameObject__Group__26 ;
    public final void rule__GameObject__Group__25() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3304:1: ( rule__GameObject__Group__25__Impl rule__GameObject__Group__26 )
            // InternalGameDsl.g:3305:2: rule__GameObject__Group__25__Impl rule__GameObject__Group__26
            {
            pushFollow(FOLLOW_26);
            rule__GameObject__Group__25__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__26();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__25"


    // $ANTLR start "rule__GameObject__Group__25__Impl"
    // InternalGameDsl.g:3312:1: rule__GameObject__Group__25__Impl : ( ( rule__GameObject__Group_25__0 )? ) ;
    public final void rule__GameObject__Group__25__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3316:1: ( ( ( rule__GameObject__Group_25__0 )? ) )
            // InternalGameDsl.g:3317:1: ( ( rule__GameObject__Group_25__0 )? )
            {
            // InternalGameDsl.g:3317:1: ( ( rule__GameObject__Group_25__0 )? )
            // InternalGameDsl.g:3318:2: ( rule__GameObject__Group_25__0 )?
            {
             before(grammarAccess.getGameObjectAccess().getGroup_25()); 
            // InternalGameDsl.g:3319:2: ( rule__GameObject__Group_25__0 )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==40) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalGameDsl.g:3319:3: rule__GameObject__Group_25__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__GameObject__Group_25__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameObjectAccess().getGroup_25()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__25__Impl"


    // $ANTLR start "rule__GameObject__Group__26"
    // InternalGameDsl.g:3327:1: rule__GameObject__Group__26 : rule__GameObject__Group__26__Impl rule__GameObject__Group__27 ;
    public final void rule__GameObject__Group__26() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3331:1: ( rule__GameObject__Group__26__Impl rule__GameObject__Group__27 )
            // InternalGameDsl.g:3332:2: rule__GameObject__Group__26__Impl rule__GameObject__Group__27
            {
            pushFollow(FOLLOW_26);
            rule__GameObject__Group__26__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__27();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__26"


    // $ANTLR start "rule__GameObject__Group__26__Impl"
    // InternalGameDsl.g:3339:1: rule__GameObject__Group__26__Impl : ( ( rule__GameObject__Group_26__0 )? ) ;
    public final void rule__GameObject__Group__26__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3343:1: ( ( ( rule__GameObject__Group_26__0 )? ) )
            // InternalGameDsl.g:3344:1: ( ( rule__GameObject__Group_26__0 )? )
            {
            // InternalGameDsl.g:3344:1: ( ( rule__GameObject__Group_26__0 )? )
            // InternalGameDsl.g:3345:2: ( rule__GameObject__Group_26__0 )?
            {
             before(grammarAccess.getGameObjectAccess().getGroup_26()); 
            // InternalGameDsl.g:3346:2: ( rule__GameObject__Group_26__0 )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==41) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalGameDsl.g:3346:3: rule__GameObject__Group_26__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__GameObject__Group_26__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameObjectAccess().getGroup_26()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__26__Impl"


    // $ANTLR start "rule__GameObject__Group__27"
    // InternalGameDsl.g:3354:1: rule__GameObject__Group__27 : rule__GameObject__Group__27__Impl rule__GameObject__Group__28 ;
    public final void rule__GameObject__Group__27() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3358:1: ( rule__GameObject__Group__27__Impl rule__GameObject__Group__28 )
            // InternalGameDsl.g:3359:2: rule__GameObject__Group__27__Impl rule__GameObject__Group__28
            {
            pushFollow(FOLLOW_26);
            rule__GameObject__Group__27__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group__28();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__27"


    // $ANTLR start "rule__GameObject__Group__27__Impl"
    // InternalGameDsl.g:3366:1: rule__GameObject__Group__27__Impl : ( ( rule__GameObject__Group_27__0 )? ) ;
    public final void rule__GameObject__Group__27__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3370:1: ( ( ( rule__GameObject__Group_27__0 )? ) )
            // InternalGameDsl.g:3371:1: ( ( rule__GameObject__Group_27__0 )? )
            {
            // InternalGameDsl.g:3371:1: ( ( rule__GameObject__Group_27__0 )? )
            // InternalGameDsl.g:3372:2: ( rule__GameObject__Group_27__0 )?
            {
             before(grammarAccess.getGameObjectAccess().getGroup_27()); 
            // InternalGameDsl.g:3373:2: ( rule__GameObject__Group_27__0 )?
            int alt29=2;
            int LA29_0 = input.LA(1);

            if ( (LA29_0==42) ) {
                alt29=1;
            }
            switch (alt29) {
                case 1 :
                    // InternalGameDsl.g:3373:3: rule__GameObject__Group_27__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__GameObject__Group_27__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getGameObjectAccess().getGroup_27()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__27__Impl"


    // $ANTLR start "rule__GameObject__Group__28"
    // InternalGameDsl.g:3381:1: rule__GameObject__Group__28 : rule__GameObject__Group__28__Impl ;
    public final void rule__GameObject__Group__28() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3385:1: ( rule__GameObject__Group__28__Impl )
            // InternalGameDsl.g:3386:2: rule__GameObject__Group__28__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group__28__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__28"


    // $ANTLR start "rule__GameObject__Group__28__Impl"
    // InternalGameDsl.g:3392:1: rule__GameObject__Group__28__Impl : ( '}' ) ;
    public final void rule__GameObject__Group__28__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3396:1: ( ( '}' ) )
            // InternalGameDsl.g:3397:1: ( '}' )
            {
            // InternalGameDsl.g:3397:1: ( '}' )
            // InternalGameDsl.g:3398:2: '}'
            {
             before(grammarAccess.getGameObjectAccess().getRightCurlyBracketKeyword_28()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getRightCurlyBracketKeyword_28()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group__28__Impl"


    // $ANTLR start "rule__GameObject__Group_6__0"
    // InternalGameDsl.g:3408:1: rule__GameObject__Group_6__0 : rule__GameObject__Group_6__0__Impl rule__GameObject__Group_6__1 ;
    public final void rule__GameObject__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3412:1: ( rule__GameObject__Group_6__0__Impl rule__GameObject__Group_6__1 )
            // InternalGameDsl.g:3413:2: rule__GameObject__Group_6__0__Impl rule__GameObject__Group_6__1
            {
            pushFollow(FOLLOW_14);
            rule__GameObject__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_6__0"


    // $ANTLR start "rule__GameObject__Group_6__0__Impl"
    // InternalGameDsl.g:3420:1: rule__GameObject__Group_6__0__Impl : ( ',' ) ;
    public final void rule__GameObject__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3424:1: ( ( ',' ) )
            // InternalGameDsl.g:3425:1: ( ',' )
            {
            // InternalGameDsl.g:3425:1: ( ',' )
            // InternalGameDsl.g:3426:2: ','
            {
             before(grammarAccess.getGameObjectAccess().getCommaKeyword_6_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getCommaKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_6__0__Impl"


    // $ANTLR start "rule__GameObject__Group_6__1"
    // InternalGameDsl.g:3435:1: rule__GameObject__Group_6__1 : rule__GameObject__Group_6__1__Impl ;
    public final void rule__GameObject__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3439:1: ( rule__GameObject__Group_6__1__Impl )
            // InternalGameDsl.g:3440:2: rule__GameObject__Group_6__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group_6__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_6__1"


    // $ANTLR start "rule__GameObject__Group_6__1__Impl"
    // InternalGameDsl.g:3446:1: rule__GameObject__Group_6__1__Impl : ( ( rule__GameObject__CoordinatesAssignment_6_1 ) ) ;
    public final void rule__GameObject__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3450:1: ( ( ( rule__GameObject__CoordinatesAssignment_6_1 ) ) )
            // InternalGameDsl.g:3451:1: ( ( rule__GameObject__CoordinatesAssignment_6_1 ) )
            {
            // InternalGameDsl.g:3451:1: ( ( rule__GameObject__CoordinatesAssignment_6_1 ) )
            // InternalGameDsl.g:3452:2: ( rule__GameObject__CoordinatesAssignment_6_1 )
            {
             before(grammarAccess.getGameObjectAccess().getCoordinatesAssignment_6_1()); 
            // InternalGameDsl.g:3453:2: ( rule__GameObject__CoordinatesAssignment_6_1 )
            // InternalGameDsl.g:3453:3: rule__GameObject__CoordinatesAssignment_6_1
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__CoordinatesAssignment_6_1();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getCoordinatesAssignment_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_6__1__Impl"


    // $ANTLR start "rule__GameObject__Group_11__0"
    // InternalGameDsl.g:3462:1: rule__GameObject__Group_11__0 : rule__GameObject__Group_11__0__Impl rule__GameObject__Group_11__1 ;
    public final void rule__GameObject__Group_11__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3466:1: ( rule__GameObject__Group_11__0__Impl rule__GameObject__Group_11__1 )
            // InternalGameDsl.g:3467:2: rule__GameObject__Group_11__0__Impl rule__GameObject__Group_11__1
            {
            pushFollow(FOLLOW_14);
            rule__GameObject__Group_11__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_11__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_11__0"


    // $ANTLR start "rule__GameObject__Group_11__0__Impl"
    // InternalGameDsl.g:3474:1: rule__GameObject__Group_11__0__Impl : ( ',' ) ;
    public final void rule__GameObject__Group_11__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3478:1: ( ( ',' ) )
            // InternalGameDsl.g:3479:1: ( ',' )
            {
            // InternalGameDsl.g:3479:1: ( ',' )
            // InternalGameDsl.g:3480:2: ','
            {
             before(grammarAccess.getGameObjectAccess().getCommaKeyword_11_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getCommaKeyword_11_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_11__0__Impl"


    // $ANTLR start "rule__GameObject__Group_11__1"
    // InternalGameDsl.g:3489:1: rule__GameObject__Group_11__1 : rule__GameObject__Group_11__1__Impl ;
    public final void rule__GameObject__Group_11__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3493:1: ( rule__GameObject__Group_11__1__Impl )
            // InternalGameDsl.g:3494:2: rule__GameObject__Group_11__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group_11__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_11__1"


    // $ANTLR start "rule__GameObject__Group_11__1__Impl"
    // InternalGameDsl.g:3500:1: rule__GameObject__Group_11__1__Impl : ( ( rule__GameObject__SizeAssignment_11_1 ) ) ;
    public final void rule__GameObject__Group_11__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3504:1: ( ( ( rule__GameObject__SizeAssignment_11_1 ) ) )
            // InternalGameDsl.g:3505:1: ( ( rule__GameObject__SizeAssignment_11_1 ) )
            {
            // InternalGameDsl.g:3505:1: ( ( rule__GameObject__SizeAssignment_11_1 ) )
            // InternalGameDsl.g:3506:2: ( rule__GameObject__SizeAssignment_11_1 )
            {
             before(grammarAccess.getGameObjectAccess().getSizeAssignment_11_1()); 
            // InternalGameDsl.g:3507:2: ( rule__GameObject__SizeAssignment_11_1 )
            // InternalGameDsl.g:3507:3: rule__GameObject__SizeAssignment_11_1
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__SizeAssignment_11_1();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getSizeAssignment_11_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_11__1__Impl"


    // $ANTLR start "rule__GameObject__Group_15__0"
    // InternalGameDsl.g:3516:1: rule__GameObject__Group_15__0 : rule__GameObject__Group_15__0__Impl rule__GameObject__Group_15__1 ;
    public final void rule__GameObject__Group_15__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3520:1: ( rule__GameObject__Group_15__0__Impl rule__GameObject__Group_15__1 )
            // InternalGameDsl.g:3521:2: rule__GameObject__Group_15__0__Impl rule__GameObject__Group_15__1
            {
            pushFollow(FOLLOW_18);
            rule__GameObject__Group_15__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_15__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_15__0"


    // $ANTLR start "rule__GameObject__Group_15__0__Impl"
    // InternalGameDsl.g:3528:1: rule__GameObject__Group_15__0__Impl : ( 'isTakingDamage:' ) ;
    public final void rule__GameObject__Group_15__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3532:1: ( ( 'isTakingDamage:' ) )
            // InternalGameDsl.g:3533:1: ( 'isTakingDamage:' )
            {
            // InternalGameDsl.g:3533:1: ( 'isTakingDamage:' )
            // InternalGameDsl.g:3534:2: 'isTakingDamage:'
            {
             before(grammarAccess.getGameObjectAccess().getIsTakingDamageKeyword_15_0()); 
            match(input,37,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getIsTakingDamageKeyword_15_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_15__0__Impl"


    // $ANTLR start "rule__GameObject__Group_15__1"
    // InternalGameDsl.g:3543:1: rule__GameObject__Group_15__1 : rule__GameObject__Group_15__1__Impl ;
    public final void rule__GameObject__Group_15__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3547:1: ( rule__GameObject__Group_15__1__Impl )
            // InternalGameDsl.g:3548:2: rule__GameObject__Group_15__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group_15__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_15__1"


    // $ANTLR start "rule__GameObject__Group_15__1__Impl"
    // InternalGameDsl.g:3554:1: rule__GameObject__Group_15__1__Impl : ( ( rule__GameObject__IsTakingDamageAssignment_15_1 ) ) ;
    public final void rule__GameObject__Group_15__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3558:1: ( ( ( rule__GameObject__IsTakingDamageAssignment_15_1 ) ) )
            // InternalGameDsl.g:3559:1: ( ( rule__GameObject__IsTakingDamageAssignment_15_1 ) )
            {
            // InternalGameDsl.g:3559:1: ( ( rule__GameObject__IsTakingDamageAssignment_15_1 ) )
            // InternalGameDsl.g:3560:2: ( rule__GameObject__IsTakingDamageAssignment_15_1 )
            {
             before(grammarAccess.getGameObjectAccess().getIsTakingDamageAssignment_15_1()); 
            // InternalGameDsl.g:3561:2: ( rule__GameObject__IsTakingDamageAssignment_15_1 )
            // InternalGameDsl.g:3561:3: rule__GameObject__IsTakingDamageAssignment_15_1
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__IsTakingDamageAssignment_15_1();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getIsTakingDamageAssignment_15_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_15__1__Impl"


    // $ANTLR start "rule__GameObject__Group_16__0"
    // InternalGameDsl.g:3570:1: rule__GameObject__Group_16__0 : rule__GameObject__Group_16__0__Impl rule__GameObject__Group_16__1 ;
    public final void rule__GameObject__Group_16__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3574:1: ( rule__GameObject__Group_16__0__Impl rule__GameObject__Group_16__1 )
            // InternalGameDsl.g:3575:2: rule__GameObject__Group_16__0__Impl rule__GameObject__Group_16__1
            {
            pushFollow(FOLLOW_24);
            rule__GameObject__Group_16__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_16__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_16__0"


    // $ANTLR start "rule__GameObject__Group_16__0__Impl"
    // InternalGameDsl.g:3582:1: rule__GameObject__Group_16__0__Impl : ( 'amountOfDamage:' ) ;
    public final void rule__GameObject__Group_16__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3586:1: ( ( 'amountOfDamage:' ) )
            // InternalGameDsl.g:3587:1: ( 'amountOfDamage:' )
            {
            // InternalGameDsl.g:3587:1: ( 'amountOfDamage:' )
            // InternalGameDsl.g:3588:2: 'amountOfDamage:'
            {
             before(grammarAccess.getGameObjectAccess().getAmountOfDamageKeyword_16_0()); 
            match(input,38,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getAmountOfDamageKeyword_16_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_16__0__Impl"


    // $ANTLR start "rule__GameObject__Group_16__1"
    // InternalGameDsl.g:3597:1: rule__GameObject__Group_16__1 : rule__GameObject__Group_16__1__Impl ;
    public final void rule__GameObject__Group_16__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3601:1: ( rule__GameObject__Group_16__1__Impl )
            // InternalGameDsl.g:3602:2: rule__GameObject__Group_16__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group_16__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_16__1"


    // $ANTLR start "rule__GameObject__Group_16__1__Impl"
    // InternalGameDsl.g:3608:1: rule__GameObject__Group_16__1__Impl : ( ( rule__GameObject__AmountOfDamageAssignment_16_1 ) ) ;
    public final void rule__GameObject__Group_16__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3612:1: ( ( ( rule__GameObject__AmountOfDamageAssignment_16_1 ) ) )
            // InternalGameDsl.g:3613:1: ( ( rule__GameObject__AmountOfDamageAssignment_16_1 ) )
            {
            // InternalGameDsl.g:3613:1: ( ( rule__GameObject__AmountOfDamageAssignment_16_1 ) )
            // InternalGameDsl.g:3614:2: ( rule__GameObject__AmountOfDamageAssignment_16_1 )
            {
             before(grammarAccess.getGameObjectAccess().getAmountOfDamageAssignment_16_1()); 
            // InternalGameDsl.g:3615:2: ( rule__GameObject__AmountOfDamageAssignment_16_1 )
            // InternalGameDsl.g:3615:3: rule__GameObject__AmountOfDamageAssignment_16_1
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__AmountOfDamageAssignment_16_1();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getAmountOfDamageAssignment_16_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_16__1__Impl"


    // $ANTLR start "rule__GameObject__Group_17__0"
    // InternalGameDsl.g:3624:1: rule__GameObject__Group_17__0 : rule__GameObject__Group_17__0__Impl rule__GameObject__Group_17__1 ;
    public final void rule__GameObject__Group_17__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3628:1: ( rule__GameObject__Group_17__0__Impl rule__GameObject__Group_17__1 )
            // InternalGameDsl.g:3629:2: rule__GameObject__Group_17__0__Impl rule__GameObject__Group_17__1
            {
            pushFollow(FOLLOW_14);
            rule__GameObject__Group_17__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_17__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_17__0"


    // $ANTLR start "rule__GameObject__Group_17__0__Impl"
    // InternalGameDsl.g:3636:1: rule__GameObject__Group_17__0__Impl : ( 'damageDuration:' ) ;
    public final void rule__GameObject__Group_17__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3640:1: ( ( 'damageDuration:' ) )
            // InternalGameDsl.g:3641:1: ( 'damageDuration:' )
            {
            // InternalGameDsl.g:3641:1: ( 'damageDuration:' )
            // InternalGameDsl.g:3642:2: 'damageDuration:'
            {
             before(grammarAccess.getGameObjectAccess().getDamageDurationKeyword_17_0()); 
            match(input,39,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getDamageDurationKeyword_17_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_17__0__Impl"


    // $ANTLR start "rule__GameObject__Group_17__1"
    // InternalGameDsl.g:3651:1: rule__GameObject__Group_17__1 : rule__GameObject__Group_17__1__Impl ;
    public final void rule__GameObject__Group_17__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3655:1: ( rule__GameObject__Group_17__1__Impl )
            // InternalGameDsl.g:3656:2: rule__GameObject__Group_17__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group_17__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_17__1"


    // $ANTLR start "rule__GameObject__Group_17__1__Impl"
    // InternalGameDsl.g:3662:1: rule__GameObject__Group_17__1__Impl : ( ( rule__GameObject__DamageDurationAssignment_17_1 ) ) ;
    public final void rule__GameObject__Group_17__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3666:1: ( ( ( rule__GameObject__DamageDurationAssignment_17_1 ) ) )
            // InternalGameDsl.g:3667:1: ( ( rule__GameObject__DamageDurationAssignment_17_1 ) )
            {
            // InternalGameDsl.g:3667:1: ( ( rule__GameObject__DamageDurationAssignment_17_1 ) )
            // InternalGameDsl.g:3668:2: ( rule__GameObject__DamageDurationAssignment_17_1 )
            {
             before(grammarAccess.getGameObjectAccess().getDamageDurationAssignment_17_1()); 
            // InternalGameDsl.g:3669:2: ( rule__GameObject__DamageDurationAssignment_17_1 )
            // InternalGameDsl.g:3669:3: rule__GameObject__DamageDurationAssignment_17_1
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__DamageDurationAssignment_17_1();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getDamageDurationAssignment_17_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_17__1__Impl"


    // $ANTLR start "rule__GameObject__Group_23__0"
    // InternalGameDsl.g:3678:1: rule__GameObject__Group_23__0 : rule__GameObject__Group_23__0__Impl rule__GameObject__Group_23__1 ;
    public final void rule__GameObject__Group_23__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3682:1: ( rule__GameObject__Group_23__0__Impl rule__GameObject__Group_23__1 )
            // InternalGameDsl.g:3683:2: rule__GameObject__Group_23__0__Impl rule__GameObject__Group_23__1
            {
            pushFollow(FOLLOW_24);
            rule__GameObject__Group_23__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_23__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_23__0"


    // $ANTLR start "rule__GameObject__Group_23__0__Impl"
    // InternalGameDsl.g:3690:1: rule__GameObject__Group_23__0__Impl : ( ',' ) ;
    public final void rule__GameObject__Group_23__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3694:1: ( ( ',' ) )
            // InternalGameDsl.g:3695:1: ( ',' )
            {
            // InternalGameDsl.g:3695:1: ( ',' )
            // InternalGameDsl.g:3696:2: ','
            {
             before(grammarAccess.getGameObjectAccess().getCommaKeyword_23_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getCommaKeyword_23_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_23__0__Impl"


    // $ANTLR start "rule__GameObject__Group_23__1"
    // InternalGameDsl.g:3705:1: rule__GameObject__Group_23__1 : rule__GameObject__Group_23__1__Impl ;
    public final void rule__GameObject__Group_23__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3709:1: ( rule__GameObject__Group_23__1__Impl )
            // InternalGameDsl.g:3710:2: rule__GameObject__Group_23__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group_23__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_23__1"


    // $ANTLR start "rule__GameObject__Group_23__1__Impl"
    // InternalGameDsl.g:3716:1: rule__GameObject__Group_23__1__Impl : ( ( rule__GameObject__DirectionDegreesAssignment_23_1 ) ) ;
    public final void rule__GameObject__Group_23__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3720:1: ( ( ( rule__GameObject__DirectionDegreesAssignment_23_1 ) ) )
            // InternalGameDsl.g:3721:1: ( ( rule__GameObject__DirectionDegreesAssignment_23_1 ) )
            {
            // InternalGameDsl.g:3721:1: ( ( rule__GameObject__DirectionDegreesAssignment_23_1 ) )
            // InternalGameDsl.g:3722:2: ( rule__GameObject__DirectionDegreesAssignment_23_1 )
            {
             before(grammarAccess.getGameObjectAccess().getDirectionDegreesAssignment_23_1()); 
            // InternalGameDsl.g:3723:2: ( rule__GameObject__DirectionDegreesAssignment_23_1 )
            // InternalGameDsl.g:3723:3: rule__GameObject__DirectionDegreesAssignment_23_1
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__DirectionDegreesAssignment_23_1();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getDirectionDegreesAssignment_23_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_23__1__Impl"


    // $ANTLR start "rule__GameObject__Group_25__0"
    // InternalGameDsl.g:3732:1: rule__GameObject__Group_25__0 : rule__GameObject__Group_25__0__Impl rule__GameObject__Group_25__1 ;
    public final void rule__GameObject__Group_25__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3736:1: ( rule__GameObject__Group_25__0__Impl rule__GameObject__Group_25__1 )
            // InternalGameDsl.g:3737:2: rule__GameObject__Group_25__0__Impl rule__GameObject__Group_25__1
            {
            pushFollow(FOLLOW_14);
            rule__GameObject__Group_25__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_25__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_25__0"


    // $ANTLR start "rule__GameObject__Group_25__0__Impl"
    // InternalGameDsl.g:3744:1: rule__GameObject__Group_25__0__Impl : ( 'durability:' ) ;
    public final void rule__GameObject__Group_25__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3748:1: ( ( 'durability:' ) )
            // InternalGameDsl.g:3749:1: ( 'durability:' )
            {
            // InternalGameDsl.g:3749:1: ( 'durability:' )
            // InternalGameDsl.g:3750:2: 'durability:'
            {
             before(grammarAccess.getGameObjectAccess().getDurabilityKeyword_25_0()); 
            match(input,40,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getDurabilityKeyword_25_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_25__0__Impl"


    // $ANTLR start "rule__GameObject__Group_25__1"
    // InternalGameDsl.g:3759:1: rule__GameObject__Group_25__1 : rule__GameObject__Group_25__1__Impl ;
    public final void rule__GameObject__Group_25__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3763:1: ( rule__GameObject__Group_25__1__Impl )
            // InternalGameDsl.g:3764:2: rule__GameObject__Group_25__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group_25__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_25__1"


    // $ANTLR start "rule__GameObject__Group_25__1__Impl"
    // InternalGameDsl.g:3770:1: rule__GameObject__Group_25__1__Impl : ( ( rule__GameObject__DurabilityAssignment_25_1 ) ) ;
    public final void rule__GameObject__Group_25__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3774:1: ( ( ( rule__GameObject__DurabilityAssignment_25_1 ) ) )
            // InternalGameDsl.g:3775:1: ( ( rule__GameObject__DurabilityAssignment_25_1 ) )
            {
            // InternalGameDsl.g:3775:1: ( ( rule__GameObject__DurabilityAssignment_25_1 ) )
            // InternalGameDsl.g:3776:2: ( rule__GameObject__DurabilityAssignment_25_1 )
            {
             before(grammarAccess.getGameObjectAccess().getDurabilityAssignment_25_1()); 
            // InternalGameDsl.g:3777:2: ( rule__GameObject__DurabilityAssignment_25_1 )
            // InternalGameDsl.g:3777:3: rule__GameObject__DurabilityAssignment_25_1
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__DurabilityAssignment_25_1();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getDurabilityAssignment_25_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_25__1__Impl"


    // $ANTLR start "rule__GameObject__Group_26__0"
    // InternalGameDsl.g:3786:1: rule__GameObject__Group_26__0 : rule__GameObject__Group_26__0__Impl rule__GameObject__Group_26__1 ;
    public final void rule__GameObject__Group_26__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3790:1: ( rule__GameObject__Group_26__0__Impl rule__GameObject__Group_26__1 )
            // InternalGameDsl.g:3791:2: rule__GameObject__Group_26__0__Impl rule__GameObject__Group_26__1
            {
            pushFollow(FOLLOW_5);
            rule__GameObject__Group_26__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_26__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26__0"


    // $ANTLR start "rule__GameObject__Group_26__0__Impl"
    // InternalGameDsl.g:3798:1: rule__GameObject__Group_26__0__Impl : ( 'ability' ) ;
    public final void rule__GameObject__Group_26__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3802:1: ( ( 'ability' ) )
            // InternalGameDsl.g:3803:1: ( 'ability' )
            {
            // InternalGameDsl.g:3803:1: ( 'ability' )
            // InternalGameDsl.g:3804:2: 'ability'
            {
             before(grammarAccess.getGameObjectAccess().getAbilityKeyword_26_0()); 
            match(input,41,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getAbilityKeyword_26_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26__0__Impl"


    // $ANTLR start "rule__GameObject__Group_26__1"
    // InternalGameDsl.g:3813:1: rule__GameObject__Group_26__1 : rule__GameObject__Group_26__1__Impl rule__GameObject__Group_26__2 ;
    public final void rule__GameObject__Group_26__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3817:1: ( rule__GameObject__Group_26__1__Impl rule__GameObject__Group_26__2 )
            // InternalGameDsl.g:3818:2: rule__GameObject__Group_26__1__Impl rule__GameObject__Group_26__2
            {
            pushFollow(FOLLOW_27);
            rule__GameObject__Group_26__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_26__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26__1"


    // $ANTLR start "rule__GameObject__Group_26__1__Impl"
    // InternalGameDsl.g:3825:1: rule__GameObject__Group_26__1__Impl : ( '{' ) ;
    public final void rule__GameObject__Group_26__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3829:1: ( ( '{' ) )
            // InternalGameDsl.g:3830:1: ( '{' )
            {
            // InternalGameDsl.g:3830:1: ( '{' )
            // InternalGameDsl.g:3831:2: '{'
            {
             before(grammarAccess.getGameObjectAccess().getLeftCurlyBracketKeyword_26_1()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getLeftCurlyBracketKeyword_26_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26__1__Impl"


    // $ANTLR start "rule__GameObject__Group_26__2"
    // InternalGameDsl.g:3840:1: rule__GameObject__Group_26__2 : rule__GameObject__Group_26__2__Impl rule__GameObject__Group_26__3 ;
    public final void rule__GameObject__Group_26__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3844:1: ( rule__GameObject__Group_26__2__Impl rule__GameObject__Group_26__3 )
            // InternalGameDsl.g:3845:2: rule__GameObject__Group_26__2__Impl rule__GameObject__Group_26__3
            {
            pushFollow(FOLLOW_8);
            rule__GameObject__Group_26__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_26__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26__2"


    // $ANTLR start "rule__GameObject__Group_26__2__Impl"
    // InternalGameDsl.g:3852:1: rule__GameObject__Group_26__2__Impl : ( ( rule__GameObject__AbilityAssignment_26_2 ) ) ;
    public final void rule__GameObject__Group_26__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3856:1: ( ( ( rule__GameObject__AbilityAssignment_26_2 ) ) )
            // InternalGameDsl.g:3857:1: ( ( rule__GameObject__AbilityAssignment_26_2 ) )
            {
            // InternalGameDsl.g:3857:1: ( ( rule__GameObject__AbilityAssignment_26_2 ) )
            // InternalGameDsl.g:3858:2: ( rule__GameObject__AbilityAssignment_26_2 )
            {
             before(grammarAccess.getGameObjectAccess().getAbilityAssignment_26_2()); 
            // InternalGameDsl.g:3859:2: ( rule__GameObject__AbilityAssignment_26_2 )
            // InternalGameDsl.g:3859:3: rule__GameObject__AbilityAssignment_26_2
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__AbilityAssignment_26_2();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getAbilityAssignment_26_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26__2__Impl"


    // $ANTLR start "rule__GameObject__Group_26__3"
    // InternalGameDsl.g:3867:1: rule__GameObject__Group_26__3 : rule__GameObject__Group_26__3__Impl rule__GameObject__Group_26__4 ;
    public final void rule__GameObject__Group_26__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3871:1: ( rule__GameObject__Group_26__3__Impl rule__GameObject__Group_26__4 )
            // InternalGameDsl.g:3872:2: rule__GameObject__Group_26__3__Impl rule__GameObject__Group_26__4
            {
            pushFollow(FOLLOW_8);
            rule__GameObject__Group_26__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_26__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26__3"


    // $ANTLR start "rule__GameObject__Group_26__3__Impl"
    // InternalGameDsl.g:3879:1: rule__GameObject__Group_26__3__Impl : ( ( rule__GameObject__Group_26_3__0 )* ) ;
    public final void rule__GameObject__Group_26__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3883:1: ( ( ( rule__GameObject__Group_26_3__0 )* ) )
            // InternalGameDsl.g:3884:1: ( ( rule__GameObject__Group_26_3__0 )* )
            {
            // InternalGameDsl.g:3884:1: ( ( rule__GameObject__Group_26_3__0 )* )
            // InternalGameDsl.g:3885:2: ( rule__GameObject__Group_26_3__0 )*
            {
             before(grammarAccess.getGameObjectAccess().getGroup_26_3()); 
            // InternalGameDsl.g:3886:2: ( rule__GameObject__Group_26_3__0 )*
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( (LA30_0==19) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // InternalGameDsl.g:3886:3: rule__GameObject__Group_26_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__GameObject__Group_26_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop30;
                }
            } while (true);

             after(grammarAccess.getGameObjectAccess().getGroup_26_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26__3__Impl"


    // $ANTLR start "rule__GameObject__Group_26__4"
    // InternalGameDsl.g:3894:1: rule__GameObject__Group_26__4 : rule__GameObject__Group_26__4__Impl ;
    public final void rule__GameObject__Group_26__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3898:1: ( rule__GameObject__Group_26__4__Impl )
            // InternalGameDsl.g:3899:2: rule__GameObject__Group_26__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group_26__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26__4"


    // $ANTLR start "rule__GameObject__Group_26__4__Impl"
    // InternalGameDsl.g:3905:1: rule__GameObject__Group_26__4__Impl : ( '}' ) ;
    public final void rule__GameObject__Group_26__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3909:1: ( ( '}' ) )
            // InternalGameDsl.g:3910:1: ( '}' )
            {
            // InternalGameDsl.g:3910:1: ( '}' )
            // InternalGameDsl.g:3911:2: '}'
            {
             before(grammarAccess.getGameObjectAccess().getRightCurlyBracketKeyword_26_4()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getRightCurlyBracketKeyword_26_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26__4__Impl"


    // $ANTLR start "rule__GameObject__Group_26_3__0"
    // InternalGameDsl.g:3921:1: rule__GameObject__Group_26_3__0 : rule__GameObject__Group_26_3__0__Impl rule__GameObject__Group_26_3__1 ;
    public final void rule__GameObject__Group_26_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3925:1: ( rule__GameObject__Group_26_3__0__Impl rule__GameObject__Group_26_3__1 )
            // InternalGameDsl.g:3926:2: rule__GameObject__Group_26_3__0__Impl rule__GameObject__Group_26_3__1
            {
            pushFollow(FOLLOW_27);
            rule__GameObject__Group_26_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_26_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26_3__0"


    // $ANTLR start "rule__GameObject__Group_26_3__0__Impl"
    // InternalGameDsl.g:3933:1: rule__GameObject__Group_26_3__0__Impl : ( ',' ) ;
    public final void rule__GameObject__Group_26_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3937:1: ( ( ',' ) )
            // InternalGameDsl.g:3938:1: ( ',' )
            {
            // InternalGameDsl.g:3938:1: ( ',' )
            // InternalGameDsl.g:3939:2: ','
            {
             before(grammarAccess.getGameObjectAccess().getCommaKeyword_26_3_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getCommaKeyword_26_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26_3__0__Impl"


    // $ANTLR start "rule__GameObject__Group_26_3__1"
    // InternalGameDsl.g:3948:1: rule__GameObject__Group_26_3__1 : rule__GameObject__Group_26_3__1__Impl ;
    public final void rule__GameObject__Group_26_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3952:1: ( rule__GameObject__Group_26_3__1__Impl )
            // InternalGameDsl.g:3953:2: rule__GameObject__Group_26_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group_26_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26_3__1"


    // $ANTLR start "rule__GameObject__Group_26_3__1__Impl"
    // InternalGameDsl.g:3959:1: rule__GameObject__Group_26_3__1__Impl : ( ( rule__GameObject__AbilityAssignment_26_3_1 ) ) ;
    public final void rule__GameObject__Group_26_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3963:1: ( ( ( rule__GameObject__AbilityAssignment_26_3_1 ) ) )
            // InternalGameDsl.g:3964:1: ( ( rule__GameObject__AbilityAssignment_26_3_1 ) )
            {
            // InternalGameDsl.g:3964:1: ( ( rule__GameObject__AbilityAssignment_26_3_1 ) )
            // InternalGameDsl.g:3965:2: ( rule__GameObject__AbilityAssignment_26_3_1 )
            {
             before(grammarAccess.getGameObjectAccess().getAbilityAssignment_26_3_1()); 
            // InternalGameDsl.g:3966:2: ( rule__GameObject__AbilityAssignment_26_3_1 )
            // InternalGameDsl.g:3966:3: rule__GameObject__AbilityAssignment_26_3_1
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__AbilityAssignment_26_3_1();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getAbilityAssignment_26_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_26_3__1__Impl"


    // $ANTLR start "rule__GameObject__Group_27__0"
    // InternalGameDsl.g:3975:1: rule__GameObject__Group_27__0 : rule__GameObject__Group_27__0__Impl rule__GameObject__Group_27__1 ;
    public final void rule__GameObject__Group_27__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3979:1: ( rule__GameObject__Group_27__0__Impl rule__GameObject__Group_27__1 )
            // InternalGameDsl.g:3980:2: rule__GameObject__Group_27__0__Impl rule__GameObject__Group_27__1
            {
            pushFollow(FOLLOW_5);
            rule__GameObject__Group_27__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_27__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27__0"


    // $ANTLR start "rule__GameObject__Group_27__0__Impl"
    // InternalGameDsl.g:3987:1: rule__GameObject__Group_27__0__Impl : ( 'action' ) ;
    public final void rule__GameObject__Group_27__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:3991:1: ( ( 'action' ) )
            // InternalGameDsl.g:3992:1: ( 'action' )
            {
            // InternalGameDsl.g:3992:1: ( 'action' )
            // InternalGameDsl.g:3993:2: 'action'
            {
             before(grammarAccess.getGameObjectAccess().getActionKeyword_27_0()); 
            match(input,42,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getActionKeyword_27_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27__0__Impl"


    // $ANTLR start "rule__GameObject__Group_27__1"
    // InternalGameDsl.g:4002:1: rule__GameObject__Group_27__1 : rule__GameObject__Group_27__1__Impl rule__GameObject__Group_27__2 ;
    public final void rule__GameObject__Group_27__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4006:1: ( rule__GameObject__Group_27__1__Impl rule__GameObject__Group_27__2 )
            // InternalGameDsl.g:4007:2: rule__GameObject__Group_27__1__Impl rule__GameObject__Group_27__2
            {
            pushFollow(FOLLOW_28);
            rule__GameObject__Group_27__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_27__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27__1"


    // $ANTLR start "rule__GameObject__Group_27__1__Impl"
    // InternalGameDsl.g:4014:1: rule__GameObject__Group_27__1__Impl : ( '{' ) ;
    public final void rule__GameObject__Group_27__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4018:1: ( ( '{' ) )
            // InternalGameDsl.g:4019:1: ( '{' )
            {
            // InternalGameDsl.g:4019:1: ( '{' )
            // InternalGameDsl.g:4020:2: '{'
            {
             before(grammarAccess.getGameObjectAccess().getLeftCurlyBracketKeyword_27_1()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getLeftCurlyBracketKeyword_27_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27__1__Impl"


    // $ANTLR start "rule__GameObject__Group_27__2"
    // InternalGameDsl.g:4029:1: rule__GameObject__Group_27__2 : rule__GameObject__Group_27__2__Impl rule__GameObject__Group_27__3 ;
    public final void rule__GameObject__Group_27__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4033:1: ( rule__GameObject__Group_27__2__Impl rule__GameObject__Group_27__3 )
            // InternalGameDsl.g:4034:2: rule__GameObject__Group_27__2__Impl rule__GameObject__Group_27__3
            {
            pushFollow(FOLLOW_8);
            rule__GameObject__Group_27__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_27__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27__2"


    // $ANTLR start "rule__GameObject__Group_27__2__Impl"
    // InternalGameDsl.g:4041:1: rule__GameObject__Group_27__2__Impl : ( ( rule__GameObject__ActionAssignment_27_2 ) ) ;
    public final void rule__GameObject__Group_27__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4045:1: ( ( ( rule__GameObject__ActionAssignment_27_2 ) ) )
            // InternalGameDsl.g:4046:1: ( ( rule__GameObject__ActionAssignment_27_2 ) )
            {
            // InternalGameDsl.g:4046:1: ( ( rule__GameObject__ActionAssignment_27_2 ) )
            // InternalGameDsl.g:4047:2: ( rule__GameObject__ActionAssignment_27_2 )
            {
             before(grammarAccess.getGameObjectAccess().getActionAssignment_27_2()); 
            // InternalGameDsl.g:4048:2: ( rule__GameObject__ActionAssignment_27_2 )
            // InternalGameDsl.g:4048:3: rule__GameObject__ActionAssignment_27_2
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__ActionAssignment_27_2();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getActionAssignment_27_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27__2__Impl"


    // $ANTLR start "rule__GameObject__Group_27__3"
    // InternalGameDsl.g:4056:1: rule__GameObject__Group_27__3 : rule__GameObject__Group_27__3__Impl rule__GameObject__Group_27__4 ;
    public final void rule__GameObject__Group_27__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4060:1: ( rule__GameObject__Group_27__3__Impl rule__GameObject__Group_27__4 )
            // InternalGameDsl.g:4061:2: rule__GameObject__Group_27__3__Impl rule__GameObject__Group_27__4
            {
            pushFollow(FOLLOW_8);
            rule__GameObject__Group_27__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_27__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27__3"


    // $ANTLR start "rule__GameObject__Group_27__3__Impl"
    // InternalGameDsl.g:4068:1: rule__GameObject__Group_27__3__Impl : ( ( rule__GameObject__Group_27_3__0 )* ) ;
    public final void rule__GameObject__Group_27__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4072:1: ( ( ( rule__GameObject__Group_27_3__0 )* ) )
            // InternalGameDsl.g:4073:1: ( ( rule__GameObject__Group_27_3__0 )* )
            {
            // InternalGameDsl.g:4073:1: ( ( rule__GameObject__Group_27_3__0 )* )
            // InternalGameDsl.g:4074:2: ( rule__GameObject__Group_27_3__0 )*
            {
             before(grammarAccess.getGameObjectAccess().getGroup_27_3()); 
            // InternalGameDsl.g:4075:2: ( rule__GameObject__Group_27_3__0 )*
            loop31:
            do {
                int alt31=2;
                int LA31_0 = input.LA(1);

                if ( (LA31_0==19) ) {
                    alt31=1;
                }


                switch (alt31) {
            	case 1 :
            	    // InternalGameDsl.g:4075:3: rule__GameObject__Group_27_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__GameObject__Group_27_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop31;
                }
            } while (true);

             after(grammarAccess.getGameObjectAccess().getGroup_27_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27__3__Impl"


    // $ANTLR start "rule__GameObject__Group_27__4"
    // InternalGameDsl.g:4083:1: rule__GameObject__Group_27__4 : rule__GameObject__Group_27__4__Impl ;
    public final void rule__GameObject__Group_27__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4087:1: ( rule__GameObject__Group_27__4__Impl )
            // InternalGameDsl.g:4088:2: rule__GameObject__Group_27__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group_27__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27__4"


    // $ANTLR start "rule__GameObject__Group_27__4__Impl"
    // InternalGameDsl.g:4094:1: rule__GameObject__Group_27__4__Impl : ( '}' ) ;
    public final void rule__GameObject__Group_27__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4098:1: ( ( '}' ) )
            // InternalGameDsl.g:4099:1: ( '}' )
            {
            // InternalGameDsl.g:4099:1: ( '}' )
            // InternalGameDsl.g:4100:2: '}'
            {
             before(grammarAccess.getGameObjectAccess().getRightCurlyBracketKeyword_27_4()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getRightCurlyBracketKeyword_27_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27__4__Impl"


    // $ANTLR start "rule__GameObject__Group_27_3__0"
    // InternalGameDsl.g:4110:1: rule__GameObject__Group_27_3__0 : rule__GameObject__Group_27_3__0__Impl rule__GameObject__Group_27_3__1 ;
    public final void rule__GameObject__Group_27_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4114:1: ( rule__GameObject__Group_27_3__0__Impl rule__GameObject__Group_27_3__1 )
            // InternalGameDsl.g:4115:2: rule__GameObject__Group_27_3__0__Impl rule__GameObject__Group_27_3__1
            {
            pushFollow(FOLLOW_28);
            rule__GameObject__Group_27_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__GameObject__Group_27_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27_3__0"


    // $ANTLR start "rule__GameObject__Group_27_3__0__Impl"
    // InternalGameDsl.g:4122:1: rule__GameObject__Group_27_3__0__Impl : ( ',' ) ;
    public final void rule__GameObject__Group_27_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4126:1: ( ( ',' ) )
            // InternalGameDsl.g:4127:1: ( ',' )
            {
            // InternalGameDsl.g:4127:1: ( ',' )
            // InternalGameDsl.g:4128:2: ','
            {
             before(grammarAccess.getGameObjectAccess().getCommaKeyword_27_3_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getGameObjectAccess().getCommaKeyword_27_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27_3__0__Impl"


    // $ANTLR start "rule__GameObject__Group_27_3__1"
    // InternalGameDsl.g:4137:1: rule__GameObject__Group_27_3__1 : rule__GameObject__Group_27_3__1__Impl ;
    public final void rule__GameObject__Group_27_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4141:1: ( rule__GameObject__Group_27_3__1__Impl )
            // InternalGameDsl.g:4142:2: rule__GameObject__Group_27_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__Group_27_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27_3__1"


    // $ANTLR start "rule__GameObject__Group_27_3__1__Impl"
    // InternalGameDsl.g:4148:1: rule__GameObject__Group_27_3__1__Impl : ( ( rule__GameObject__ActionAssignment_27_3_1 ) ) ;
    public final void rule__GameObject__Group_27_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4152:1: ( ( ( rule__GameObject__ActionAssignment_27_3_1 ) ) )
            // InternalGameDsl.g:4153:1: ( ( rule__GameObject__ActionAssignment_27_3_1 ) )
            {
            // InternalGameDsl.g:4153:1: ( ( rule__GameObject__ActionAssignment_27_3_1 ) )
            // InternalGameDsl.g:4154:2: ( rule__GameObject__ActionAssignment_27_3_1 )
            {
             before(grammarAccess.getGameObjectAccess().getActionAssignment_27_3_1()); 
            // InternalGameDsl.g:4155:2: ( rule__GameObject__ActionAssignment_27_3_1 )
            // InternalGameDsl.g:4155:3: rule__GameObject__ActionAssignment_27_3_1
            {
            pushFollow(FOLLOW_2);
            rule__GameObject__ActionAssignment_27_3_1();

            state._fsp--;


            }

             after(grammarAccess.getGameObjectAccess().getActionAssignment_27_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__Group_27_3__1__Impl"


    // $ANTLR start "rule__Collisions__Group__0"
    // InternalGameDsl.g:4164:1: rule__Collisions__Group__0 : rule__Collisions__Group__0__Impl rule__Collisions__Group__1 ;
    public final void rule__Collisions__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4168:1: ( rule__Collisions__Group__0__Impl rule__Collisions__Group__1 )
            // InternalGameDsl.g:4169:2: rule__Collisions__Group__0__Impl rule__Collisions__Group__1
            {
            pushFollow(FOLLOW_11);
            rule__Collisions__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__0"


    // $ANTLR start "rule__Collisions__Group__0__Impl"
    // InternalGameDsl.g:4176:1: rule__Collisions__Group__0__Impl : ( () ) ;
    public final void rule__Collisions__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4180:1: ( ( () ) )
            // InternalGameDsl.g:4181:1: ( () )
            {
            // InternalGameDsl.g:4181:1: ( () )
            // InternalGameDsl.g:4182:2: ()
            {
             before(grammarAccess.getCollisionsAccess().getCollisionsAction_0()); 
            // InternalGameDsl.g:4183:2: ()
            // InternalGameDsl.g:4183:3: 
            {
            }

             after(grammarAccess.getCollisionsAccess().getCollisionsAction_0()); 

            }


            }

        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__0__Impl"


    // $ANTLR start "rule__Collisions__Group__1"
    // InternalGameDsl.g:4191:1: rule__Collisions__Group__1 : rule__Collisions__Group__1__Impl rule__Collisions__Group__2 ;
    public final void rule__Collisions__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4195:1: ( rule__Collisions__Group__1__Impl rule__Collisions__Group__2 )
            // InternalGameDsl.g:4196:2: rule__Collisions__Group__1__Impl rule__Collisions__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Collisions__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__1"


    // $ANTLR start "rule__Collisions__Group__1__Impl"
    // InternalGameDsl.g:4203:1: rule__Collisions__Group__1__Impl : ( 'Collisions' ) ;
    public final void rule__Collisions__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4207:1: ( ( 'Collisions' ) )
            // InternalGameDsl.g:4208:1: ( 'Collisions' )
            {
            // InternalGameDsl.g:4208:1: ( 'Collisions' )
            // InternalGameDsl.g:4209:2: 'Collisions'
            {
             before(grammarAccess.getCollisionsAccess().getCollisionsKeyword_1()); 
            match(input,43,FOLLOW_2); 
             after(grammarAccess.getCollisionsAccess().getCollisionsKeyword_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__1__Impl"


    // $ANTLR start "rule__Collisions__Group__2"
    // InternalGameDsl.g:4218:1: rule__Collisions__Group__2 : rule__Collisions__Group__2__Impl rule__Collisions__Group__3 ;
    public final void rule__Collisions__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4222:1: ( rule__Collisions__Group__2__Impl rule__Collisions__Group__3 )
            // InternalGameDsl.g:4223:2: rule__Collisions__Group__2__Impl rule__Collisions__Group__3
            {
            pushFollow(FOLLOW_29);
            rule__Collisions__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__2"


    // $ANTLR start "rule__Collisions__Group__2__Impl"
    // InternalGameDsl.g:4230:1: rule__Collisions__Group__2__Impl : ( '{' ) ;
    public final void rule__Collisions__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4234:1: ( ( '{' ) )
            // InternalGameDsl.g:4235:1: ( '{' )
            {
            // InternalGameDsl.g:4235:1: ( '{' )
            // InternalGameDsl.g:4236:2: '{'
            {
             before(grammarAccess.getCollisionsAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getCollisionsAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__2__Impl"


    // $ANTLR start "rule__Collisions__Group__3"
    // InternalGameDsl.g:4245:1: rule__Collisions__Group__3 : rule__Collisions__Group__3__Impl rule__Collisions__Group__4 ;
    public final void rule__Collisions__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4249:1: ( rule__Collisions__Group__3__Impl rule__Collisions__Group__4 )
            // InternalGameDsl.g:4250:2: rule__Collisions__Group__3__Impl rule__Collisions__Group__4
            {
            pushFollow(FOLLOW_29);
            rule__Collisions__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__3"


    // $ANTLR start "rule__Collisions__Group__3__Impl"
    // InternalGameDsl.g:4257:1: rule__Collisions__Group__3__Impl : ( ( rule__Collisions__Group_3__0 )? ) ;
    public final void rule__Collisions__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4261:1: ( ( ( rule__Collisions__Group_3__0 )? ) )
            // InternalGameDsl.g:4262:1: ( ( rule__Collisions__Group_3__0 )? )
            {
            // InternalGameDsl.g:4262:1: ( ( rule__Collisions__Group_3__0 )? )
            // InternalGameDsl.g:4263:2: ( rule__Collisions__Group_3__0 )?
            {
             before(grammarAccess.getCollisionsAccess().getGroup_3()); 
            // InternalGameDsl.g:4264:2: ( rule__Collisions__Group_3__0 )?
            int alt32=2;
            int LA32_0 = input.LA(1);

            if ( (LA32_0==44) ) {
                alt32=1;
            }
            switch (alt32) {
                case 1 :
                    // InternalGameDsl.g:4264:3: rule__Collisions__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Collisions__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCollisionsAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__3__Impl"


    // $ANTLR start "rule__Collisions__Group__4"
    // InternalGameDsl.g:4272:1: rule__Collisions__Group__4 : rule__Collisions__Group__4__Impl rule__Collisions__Group__5 ;
    public final void rule__Collisions__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4276:1: ( rule__Collisions__Group__4__Impl rule__Collisions__Group__5 )
            // InternalGameDsl.g:4277:2: rule__Collisions__Group__4__Impl rule__Collisions__Group__5
            {
            pushFollow(FOLLOW_29);
            rule__Collisions__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__4"


    // $ANTLR start "rule__Collisions__Group__4__Impl"
    // InternalGameDsl.g:4284:1: rule__Collisions__Group__4__Impl : ( ( rule__Collisions__Group_4__0 )? ) ;
    public final void rule__Collisions__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4288:1: ( ( ( rule__Collisions__Group_4__0 )? ) )
            // InternalGameDsl.g:4289:1: ( ( rule__Collisions__Group_4__0 )? )
            {
            // InternalGameDsl.g:4289:1: ( ( rule__Collisions__Group_4__0 )? )
            // InternalGameDsl.g:4290:2: ( rule__Collisions__Group_4__0 )?
            {
             before(grammarAccess.getCollisionsAccess().getGroup_4()); 
            // InternalGameDsl.g:4291:2: ( rule__Collisions__Group_4__0 )?
            int alt33=2;
            int LA33_0 = input.LA(1);

            if ( (LA33_0==45) ) {
                alt33=1;
            }
            switch (alt33) {
                case 1 :
                    // InternalGameDsl.g:4291:3: rule__Collisions__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Collisions__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCollisionsAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__4__Impl"


    // $ANTLR start "rule__Collisions__Group__5"
    // InternalGameDsl.g:4299:1: rule__Collisions__Group__5 : rule__Collisions__Group__5__Impl rule__Collisions__Group__6 ;
    public final void rule__Collisions__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4303:1: ( rule__Collisions__Group__5__Impl rule__Collisions__Group__6 )
            // InternalGameDsl.g:4304:2: rule__Collisions__Group__5__Impl rule__Collisions__Group__6
            {
            pushFollow(FOLLOW_29);
            rule__Collisions__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__5"


    // $ANTLR start "rule__Collisions__Group__5__Impl"
    // InternalGameDsl.g:4311:1: rule__Collisions__Group__5__Impl : ( ( rule__Collisions__Group_5__0 )? ) ;
    public final void rule__Collisions__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4315:1: ( ( ( rule__Collisions__Group_5__0 )? ) )
            // InternalGameDsl.g:4316:1: ( ( rule__Collisions__Group_5__0 )? )
            {
            // InternalGameDsl.g:4316:1: ( ( rule__Collisions__Group_5__0 )? )
            // InternalGameDsl.g:4317:2: ( rule__Collisions__Group_5__0 )?
            {
             before(grammarAccess.getCollisionsAccess().getGroup_5()); 
            // InternalGameDsl.g:4318:2: ( rule__Collisions__Group_5__0 )?
            int alt34=2;
            int LA34_0 = input.LA(1);

            if ( (LA34_0==46) ) {
                alt34=1;
            }
            switch (alt34) {
                case 1 :
                    // InternalGameDsl.g:4318:3: rule__Collisions__Group_5__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Collisions__Group_5__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCollisionsAccess().getGroup_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__5__Impl"


    // $ANTLR start "rule__Collisions__Group__6"
    // InternalGameDsl.g:4326:1: rule__Collisions__Group__6 : rule__Collisions__Group__6__Impl rule__Collisions__Group__7 ;
    public final void rule__Collisions__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4330:1: ( rule__Collisions__Group__6__Impl rule__Collisions__Group__7 )
            // InternalGameDsl.g:4331:2: rule__Collisions__Group__6__Impl rule__Collisions__Group__7
            {
            pushFollow(FOLLOW_29);
            rule__Collisions__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__6"


    // $ANTLR start "rule__Collisions__Group__6__Impl"
    // InternalGameDsl.g:4338:1: rule__Collisions__Group__6__Impl : ( ( rule__Collisions__Group_6__0 )? ) ;
    public final void rule__Collisions__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4342:1: ( ( ( rule__Collisions__Group_6__0 )? ) )
            // InternalGameDsl.g:4343:1: ( ( rule__Collisions__Group_6__0 )? )
            {
            // InternalGameDsl.g:4343:1: ( ( rule__Collisions__Group_6__0 )? )
            // InternalGameDsl.g:4344:2: ( rule__Collisions__Group_6__0 )?
            {
             before(grammarAccess.getCollisionsAccess().getGroup_6()); 
            // InternalGameDsl.g:4345:2: ( rule__Collisions__Group_6__0 )?
            int alt35=2;
            int LA35_0 = input.LA(1);

            if ( (LA35_0==47) ) {
                alt35=1;
            }
            switch (alt35) {
                case 1 :
                    // InternalGameDsl.g:4345:3: rule__Collisions__Group_6__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Collisions__Group_6__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getCollisionsAccess().getGroup_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__6__Impl"


    // $ANTLR start "rule__Collisions__Group__7"
    // InternalGameDsl.g:4353:1: rule__Collisions__Group__7 : rule__Collisions__Group__7__Impl ;
    public final void rule__Collisions__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4357:1: ( rule__Collisions__Group__7__Impl )
            // InternalGameDsl.g:4358:2: rule__Collisions__Group__7__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__Group__7__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__7"


    // $ANTLR start "rule__Collisions__Group__7__Impl"
    // InternalGameDsl.g:4364:1: rule__Collisions__Group__7__Impl : ( '}' ) ;
    public final void rule__Collisions__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4368:1: ( ( '}' ) )
            // InternalGameDsl.g:4369:1: ( '}' )
            {
            // InternalGameDsl.g:4369:1: ( '}' )
            // InternalGameDsl.g:4370:2: '}'
            {
             before(grammarAccess.getCollisionsAccess().getRightCurlyBracketKeyword_7()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getCollisionsAccess().getRightCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group__7__Impl"


    // $ANTLR start "rule__Collisions__Group_3__0"
    // InternalGameDsl.g:4380:1: rule__Collisions__Group_3__0 : rule__Collisions__Group_3__0__Impl rule__Collisions__Group_3__1 ;
    public final void rule__Collisions__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4384:1: ( rule__Collisions__Group_3__0__Impl rule__Collisions__Group_3__1 )
            // InternalGameDsl.g:4385:2: rule__Collisions__Group_3__0__Impl rule__Collisions__Group_3__1
            {
            pushFollow(FOLLOW_4);
            rule__Collisions__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_3__0"


    // $ANTLR start "rule__Collisions__Group_3__0__Impl"
    // InternalGameDsl.g:4392:1: rule__Collisions__Group_3__0__Impl : ( 'hittedSpot:' ) ;
    public final void rule__Collisions__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4396:1: ( ( 'hittedSpot:' ) )
            // InternalGameDsl.g:4397:1: ( 'hittedSpot:' )
            {
            // InternalGameDsl.g:4397:1: ( 'hittedSpot:' )
            // InternalGameDsl.g:4398:2: 'hittedSpot:'
            {
             before(grammarAccess.getCollisionsAccess().getHittedSpotKeyword_3_0()); 
            match(input,44,FOLLOW_2); 
             after(grammarAccess.getCollisionsAccess().getHittedSpotKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_3__0__Impl"


    // $ANTLR start "rule__Collisions__Group_3__1"
    // InternalGameDsl.g:4407:1: rule__Collisions__Group_3__1 : rule__Collisions__Group_3__1__Impl ;
    public final void rule__Collisions__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4411:1: ( rule__Collisions__Group_3__1__Impl )
            // InternalGameDsl.g:4412:2: rule__Collisions__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_3__1"


    // $ANTLR start "rule__Collisions__Group_3__1__Impl"
    // InternalGameDsl.g:4418:1: rule__Collisions__Group_3__1__Impl : ( ( rule__Collisions__HittedSpotAssignment_3_1 ) ) ;
    public final void rule__Collisions__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4422:1: ( ( ( rule__Collisions__HittedSpotAssignment_3_1 ) ) )
            // InternalGameDsl.g:4423:1: ( ( rule__Collisions__HittedSpotAssignment_3_1 ) )
            {
            // InternalGameDsl.g:4423:1: ( ( rule__Collisions__HittedSpotAssignment_3_1 ) )
            // InternalGameDsl.g:4424:2: ( rule__Collisions__HittedSpotAssignment_3_1 )
            {
             before(grammarAccess.getCollisionsAccess().getHittedSpotAssignment_3_1()); 
            // InternalGameDsl.g:4425:2: ( rule__Collisions__HittedSpotAssignment_3_1 )
            // InternalGameDsl.g:4425:3: rule__Collisions__HittedSpotAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__HittedSpotAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getCollisionsAccess().getHittedSpotAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_3__1__Impl"


    // $ANTLR start "rule__Collisions__Group_4__0"
    // InternalGameDsl.g:4434:1: rule__Collisions__Group_4__0 : rule__Collisions__Group_4__0__Impl rule__Collisions__Group_4__1 ;
    public final void rule__Collisions__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4438:1: ( rule__Collisions__Group_4__0__Impl rule__Collisions__Group_4__1 )
            // InternalGameDsl.g:4439:2: rule__Collisions__Group_4__0__Impl rule__Collisions__Group_4__1
            {
            pushFollow(FOLLOW_4);
            rule__Collisions__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_4__0"


    // $ANTLR start "rule__Collisions__Group_4__0__Impl"
    // InternalGameDsl.g:4446:1: rule__Collisions__Group_4__0__Impl : ( 'effect:' ) ;
    public final void rule__Collisions__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4450:1: ( ( 'effect:' ) )
            // InternalGameDsl.g:4451:1: ( 'effect:' )
            {
            // InternalGameDsl.g:4451:1: ( 'effect:' )
            // InternalGameDsl.g:4452:2: 'effect:'
            {
             before(grammarAccess.getCollisionsAccess().getEffectKeyword_4_0()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getCollisionsAccess().getEffectKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_4__0__Impl"


    // $ANTLR start "rule__Collisions__Group_4__1"
    // InternalGameDsl.g:4461:1: rule__Collisions__Group_4__1 : rule__Collisions__Group_4__1__Impl ;
    public final void rule__Collisions__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4465:1: ( rule__Collisions__Group_4__1__Impl )
            // InternalGameDsl.g:4466:2: rule__Collisions__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_4__1"


    // $ANTLR start "rule__Collisions__Group_4__1__Impl"
    // InternalGameDsl.g:4472:1: rule__Collisions__Group_4__1__Impl : ( ( rule__Collisions__EffectAssignment_4_1 ) ) ;
    public final void rule__Collisions__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4476:1: ( ( ( rule__Collisions__EffectAssignment_4_1 ) ) )
            // InternalGameDsl.g:4477:1: ( ( rule__Collisions__EffectAssignment_4_1 ) )
            {
            // InternalGameDsl.g:4477:1: ( ( rule__Collisions__EffectAssignment_4_1 ) )
            // InternalGameDsl.g:4478:2: ( rule__Collisions__EffectAssignment_4_1 )
            {
             before(grammarAccess.getCollisionsAccess().getEffectAssignment_4_1()); 
            // InternalGameDsl.g:4479:2: ( rule__Collisions__EffectAssignment_4_1 )
            // InternalGameDsl.g:4479:3: rule__Collisions__EffectAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__EffectAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getCollisionsAccess().getEffectAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_4__1__Impl"


    // $ANTLR start "rule__Collisions__Group_5__0"
    // InternalGameDsl.g:4488:1: rule__Collisions__Group_5__0 : rule__Collisions__Group_5__0__Impl rule__Collisions__Group_5__1 ;
    public final void rule__Collisions__Group_5__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4492:1: ( rule__Collisions__Group_5__0__Impl rule__Collisions__Group_5__1 )
            // InternalGameDsl.g:4493:2: rule__Collisions__Group_5__0__Impl rule__Collisions__Group_5__1
            {
            pushFollow(FOLLOW_24);
            rule__Collisions__Group_5__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group_5__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_5__0"


    // $ANTLR start "rule__Collisions__Group_5__0__Impl"
    // InternalGameDsl.g:4500:1: rule__Collisions__Group_5__0__Impl : ( 'effectValue:' ) ;
    public final void rule__Collisions__Group_5__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4504:1: ( ( 'effectValue:' ) )
            // InternalGameDsl.g:4505:1: ( 'effectValue:' )
            {
            // InternalGameDsl.g:4505:1: ( 'effectValue:' )
            // InternalGameDsl.g:4506:2: 'effectValue:'
            {
             before(grammarAccess.getCollisionsAccess().getEffectValueKeyword_5_0()); 
            match(input,46,FOLLOW_2); 
             after(grammarAccess.getCollisionsAccess().getEffectValueKeyword_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_5__0__Impl"


    // $ANTLR start "rule__Collisions__Group_5__1"
    // InternalGameDsl.g:4515:1: rule__Collisions__Group_5__1 : rule__Collisions__Group_5__1__Impl ;
    public final void rule__Collisions__Group_5__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4519:1: ( rule__Collisions__Group_5__1__Impl )
            // InternalGameDsl.g:4520:2: rule__Collisions__Group_5__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__Group_5__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_5__1"


    // $ANTLR start "rule__Collisions__Group_5__1__Impl"
    // InternalGameDsl.g:4526:1: rule__Collisions__Group_5__1__Impl : ( ( rule__Collisions__EffectValueAssignment_5_1 ) ) ;
    public final void rule__Collisions__Group_5__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4530:1: ( ( ( rule__Collisions__EffectValueAssignment_5_1 ) ) )
            // InternalGameDsl.g:4531:1: ( ( rule__Collisions__EffectValueAssignment_5_1 ) )
            {
            // InternalGameDsl.g:4531:1: ( ( rule__Collisions__EffectValueAssignment_5_1 ) )
            // InternalGameDsl.g:4532:2: ( rule__Collisions__EffectValueAssignment_5_1 )
            {
             before(grammarAccess.getCollisionsAccess().getEffectValueAssignment_5_1()); 
            // InternalGameDsl.g:4533:2: ( rule__Collisions__EffectValueAssignment_5_1 )
            // InternalGameDsl.g:4533:3: rule__Collisions__EffectValueAssignment_5_1
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__EffectValueAssignment_5_1();

            state._fsp--;


            }

             after(grammarAccess.getCollisionsAccess().getEffectValueAssignment_5_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_5__1__Impl"


    // $ANTLR start "rule__Collisions__Group_6__0"
    // InternalGameDsl.g:4542:1: rule__Collisions__Group_6__0 : rule__Collisions__Group_6__0__Impl rule__Collisions__Group_6__1 ;
    public final void rule__Collisions__Group_6__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4546:1: ( rule__Collisions__Group_6__0__Impl rule__Collisions__Group_6__1 )
            // InternalGameDsl.g:4547:2: rule__Collisions__Group_6__0__Impl rule__Collisions__Group_6__1
            {
            pushFollow(FOLLOW_5);
            rule__Collisions__Group_6__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group_6__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6__0"


    // $ANTLR start "rule__Collisions__Group_6__0__Impl"
    // InternalGameDsl.g:4554:1: rule__Collisions__Group_6__0__Impl : ( 'objID' ) ;
    public final void rule__Collisions__Group_6__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4558:1: ( ( 'objID' ) )
            // InternalGameDsl.g:4559:1: ( 'objID' )
            {
            // InternalGameDsl.g:4559:1: ( 'objID' )
            // InternalGameDsl.g:4560:2: 'objID'
            {
             before(grammarAccess.getCollisionsAccess().getObjIDKeyword_6_0()); 
            match(input,47,FOLLOW_2); 
             after(grammarAccess.getCollisionsAccess().getObjIDKeyword_6_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6__0__Impl"


    // $ANTLR start "rule__Collisions__Group_6__1"
    // InternalGameDsl.g:4569:1: rule__Collisions__Group_6__1 : rule__Collisions__Group_6__1__Impl rule__Collisions__Group_6__2 ;
    public final void rule__Collisions__Group_6__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4573:1: ( rule__Collisions__Group_6__1__Impl rule__Collisions__Group_6__2 )
            // InternalGameDsl.g:4574:2: rule__Collisions__Group_6__1__Impl rule__Collisions__Group_6__2
            {
            pushFollow(FOLLOW_4);
            rule__Collisions__Group_6__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group_6__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6__1"


    // $ANTLR start "rule__Collisions__Group_6__1__Impl"
    // InternalGameDsl.g:4581:1: rule__Collisions__Group_6__1__Impl : ( '{' ) ;
    public final void rule__Collisions__Group_6__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4585:1: ( ( '{' ) )
            // InternalGameDsl.g:4586:1: ( '{' )
            {
            // InternalGameDsl.g:4586:1: ( '{' )
            // InternalGameDsl.g:4587:2: '{'
            {
             before(grammarAccess.getCollisionsAccess().getLeftCurlyBracketKeyword_6_1()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getCollisionsAccess().getLeftCurlyBracketKeyword_6_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6__1__Impl"


    // $ANTLR start "rule__Collisions__Group_6__2"
    // InternalGameDsl.g:4596:1: rule__Collisions__Group_6__2 : rule__Collisions__Group_6__2__Impl rule__Collisions__Group_6__3 ;
    public final void rule__Collisions__Group_6__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4600:1: ( rule__Collisions__Group_6__2__Impl rule__Collisions__Group_6__3 )
            // InternalGameDsl.g:4601:2: rule__Collisions__Group_6__2__Impl rule__Collisions__Group_6__3
            {
            pushFollow(FOLLOW_8);
            rule__Collisions__Group_6__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group_6__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6__2"


    // $ANTLR start "rule__Collisions__Group_6__2__Impl"
    // InternalGameDsl.g:4608:1: rule__Collisions__Group_6__2__Impl : ( ( rule__Collisions__ObjIDAssignment_6_2 ) ) ;
    public final void rule__Collisions__Group_6__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4612:1: ( ( ( rule__Collisions__ObjIDAssignment_6_2 ) ) )
            // InternalGameDsl.g:4613:1: ( ( rule__Collisions__ObjIDAssignment_6_2 ) )
            {
            // InternalGameDsl.g:4613:1: ( ( rule__Collisions__ObjIDAssignment_6_2 ) )
            // InternalGameDsl.g:4614:2: ( rule__Collisions__ObjIDAssignment_6_2 )
            {
             before(grammarAccess.getCollisionsAccess().getObjIDAssignment_6_2()); 
            // InternalGameDsl.g:4615:2: ( rule__Collisions__ObjIDAssignment_6_2 )
            // InternalGameDsl.g:4615:3: rule__Collisions__ObjIDAssignment_6_2
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__ObjIDAssignment_6_2();

            state._fsp--;


            }

             after(grammarAccess.getCollisionsAccess().getObjIDAssignment_6_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6__2__Impl"


    // $ANTLR start "rule__Collisions__Group_6__3"
    // InternalGameDsl.g:4623:1: rule__Collisions__Group_6__3 : rule__Collisions__Group_6__3__Impl rule__Collisions__Group_6__4 ;
    public final void rule__Collisions__Group_6__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4627:1: ( rule__Collisions__Group_6__3__Impl rule__Collisions__Group_6__4 )
            // InternalGameDsl.g:4628:2: rule__Collisions__Group_6__3__Impl rule__Collisions__Group_6__4
            {
            pushFollow(FOLLOW_8);
            rule__Collisions__Group_6__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group_6__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6__3"


    // $ANTLR start "rule__Collisions__Group_6__3__Impl"
    // InternalGameDsl.g:4635:1: rule__Collisions__Group_6__3__Impl : ( ( rule__Collisions__Group_6_3__0 )* ) ;
    public final void rule__Collisions__Group_6__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4639:1: ( ( ( rule__Collisions__Group_6_3__0 )* ) )
            // InternalGameDsl.g:4640:1: ( ( rule__Collisions__Group_6_3__0 )* )
            {
            // InternalGameDsl.g:4640:1: ( ( rule__Collisions__Group_6_3__0 )* )
            // InternalGameDsl.g:4641:2: ( rule__Collisions__Group_6_3__0 )*
            {
             before(grammarAccess.getCollisionsAccess().getGroup_6_3()); 
            // InternalGameDsl.g:4642:2: ( rule__Collisions__Group_6_3__0 )*
            loop36:
            do {
                int alt36=2;
                int LA36_0 = input.LA(1);

                if ( (LA36_0==19) ) {
                    alt36=1;
                }


                switch (alt36) {
            	case 1 :
            	    // InternalGameDsl.g:4642:3: rule__Collisions__Group_6_3__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Collisions__Group_6_3__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop36;
                }
            } while (true);

             after(grammarAccess.getCollisionsAccess().getGroup_6_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6__3__Impl"


    // $ANTLR start "rule__Collisions__Group_6__4"
    // InternalGameDsl.g:4650:1: rule__Collisions__Group_6__4 : rule__Collisions__Group_6__4__Impl ;
    public final void rule__Collisions__Group_6__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4654:1: ( rule__Collisions__Group_6__4__Impl )
            // InternalGameDsl.g:4655:2: rule__Collisions__Group_6__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__Group_6__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6__4"


    // $ANTLR start "rule__Collisions__Group_6__4__Impl"
    // InternalGameDsl.g:4661:1: rule__Collisions__Group_6__4__Impl : ( '}' ) ;
    public final void rule__Collisions__Group_6__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4665:1: ( ( '}' ) )
            // InternalGameDsl.g:4666:1: ( '}' )
            {
            // InternalGameDsl.g:4666:1: ( '}' )
            // InternalGameDsl.g:4667:2: '}'
            {
             before(grammarAccess.getCollisionsAccess().getRightCurlyBracketKeyword_6_4()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getCollisionsAccess().getRightCurlyBracketKeyword_6_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6__4__Impl"


    // $ANTLR start "rule__Collisions__Group_6_3__0"
    // InternalGameDsl.g:4677:1: rule__Collisions__Group_6_3__0 : rule__Collisions__Group_6_3__0__Impl rule__Collisions__Group_6_3__1 ;
    public final void rule__Collisions__Group_6_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4681:1: ( rule__Collisions__Group_6_3__0__Impl rule__Collisions__Group_6_3__1 )
            // InternalGameDsl.g:4682:2: rule__Collisions__Group_6_3__0__Impl rule__Collisions__Group_6_3__1
            {
            pushFollow(FOLLOW_4);
            rule__Collisions__Group_6_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Collisions__Group_6_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6_3__0"


    // $ANTLR start "rule__Collisions__Group_6_3__0__Impl"
    // InternalGameDsl.g:4689:1: rule__Collisions__Group_6_3__0__Impl : ( ',' ) ;
    public final void rule__Collisions__Group_6_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4693:1: ( ( ',' ) )
            // InternalGameDsl.g:4694:1: ( ',' )
            {
            // InternalGameDsl.g:4694:1: ( ',' )
            // InternalGameDsl.g:4695:2: ','
            {
             before(grammarAccess.getCollisionsAccess().getCommaKeyword_6_3_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getCollisionsAccess().getCommaKeyword_6_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6_3__0__Impl"


    // $ANTLR start "rule__Collisions__Group_6_3__1"
    // InternalGameDsl.g:4704:1: rule__Collisions__Group_6_3__1 : rule__Collisions__Group_6_3__1__Impl ;
    public final void rule__Collisions__Group_6_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4708:1: ( rule__Collisions__Group_6_3__1__Impl )
            // InternalGameDsl.g:4709:2: rule__Collisions__Group_6_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__Group_6_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6_3__1"


    // $ANTLR start "rule__Collisions__Group_6_3__1__Impl"
    // InternalGameDsl.g:4715:1: rule__Collisions__Group_6_3__1__Impl : ( ( rule__Collisions__ObjIDAssignment_6_3_1 ) ) ;
    public final void rule__Collisions__Group_6_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4719:1: ( ( ( rule__Collisions__ObjIDAssignment_6_3_1 ) ) )
            // InternalGameDsl.g:4720:1: ( ( rule__Collisions__ObjIDAssignment_6_3_1 ) )
            {
            // InternalGameDsl.g:4720:1: ( ( rule__Collisions__ObjIDAssignment_6_3_1 ) )
            // InternalGameDsl.g:4721:2: ( rule__Collisions__ObjIDAssignment_6_3_1 )
            {
             before(grammarAccess.getCollisionsAccess().getObjIDAssignment_6_3_1()); 
            // InternalGameDsl.g:4722:2: ( rule__Collisions__ObjIDAssignment_6_3_1 )
            // InternalGameDsl.g:4722:3: rule__Collisions__ObjIDAssignment_6_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Collisions__ObjIDAssignment_6_3_1();

            state._fsp--;


            }

             after(grammarAccess.getCollisionsAccess().getObjIDAssignment_6_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__Group_6_3__1__Impl"


    // $ANTLR start "rule__Ability__Group__0"
    // InternalGameDsl.g:4731:1: rule__Ability__Group__0 : rule__Ability__Group__0__Impl rule__Ability__Group__1 ;
    public final void rule__Ability__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4735:1: ( rule__Ability__Group__0__Impl rule__Ability__Group__1 )
            // InternalGameDsl.g:4736:2: rule__Ability__Group__0__Impl rule__Ability__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Ability__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__0"


    // $ANTLR start "rule__Ability__Group__0__Impl"
    // InternalGameDsl.g:4743:1: rule__Ability__Group__0__Impl : ( 'Ability' ) ;
    public final void rule__Ability__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4747:1: ( ( 'Ability' ) )
            // InternalGameDsl.g:4748:1: ( 'Ability' )
            {
            // InternalGameDsl.g:4748:1: ( 'Ability' )
            // InternalGameDsl.g:4749:2: 'Ability'
            {
             before(grammarAccess.getAbilityAccess().getAbilityKeyword_0()); 
            match(input,48,FOLLOW_2); 
             after(grammarAccess.getAbilityAccess().getAbilityKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__0__Impl"


    // $ANTLR start "rule__Ability__Group__1"
    // InternalGameDsl.g:4758:1: rule__Ability__Group__1 : rule__Ability__Group__1__Impl rule__Ability__Group__2 ;
    public final void rule__Ability__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4762:1: ( rule__Ability__Group__1__Impl rule__Ability__Group__2 )
            // InternalGameDsl.g:4763:2: rule__Ability__Group__1__Impl rule__Ability__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Ability__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__1"


    // $ANTLR start "rule__Ability__Group__1__Impl"
    // InternalGameDsl.g:4770:1: rule__Ability__Group__1__Impl : ( ( rule__Ability__NameAssignment_1 ) ) ;
    public final void rule__Ability__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4774:1: ( ( ( rule__Ability__NameAssignment_1 ) ) )
            // InternalGameDsl.g:4775:1: ( ( rule__Ability__NameAssignment_1 ) )
            {
            // InternalGameDsl.g:4775:1: ( ( rule__Ability__NameAssignment_1 ) )
            // InternalGameDsl.g:4776:2: ( rule__Ability__NameAssignment_1 )
            {
             before(grammarAccess.getAbilityAccess().getNameAssignment_1()); 
            // InternalGameDsl.g:4777:2: ( rule__Ability__NameAssignment_1 )
            // InternalGameDsl.g:4777:3: rule__Ability__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Ability__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getAbilityAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__1__Impl"


    // $ANTLR start "rule__Ability__Group__2"
    // InternalGameDsl.g:4785:1: rule__Ability__Group__2 : rule__Ability__Group__2__Impl rule__Ability__Group__3 ;
    public final void rule__Ability__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4789:1: ( rule__Ability__Group__2__Impl rule__Ability__Group__3 )
            // InternalGameDsl.g:4790:2: rule__Ability__Group__2__Impl rule__Ability__Group__3
            {
            pushFollow(FOLLOW_30);
            rule__Ability__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__2"


    // $ANTLR start "rule__Ability__Group__2__Impl"
    // InternalGameDsl.g:4797:1: rule__Ability__Group__2__Impl : ( '{' ) ;
    public final void rule__Ability__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4801:1: ( ( '{' ) )
            // InternalGameDsl.g:4802:1: ( '{' )
            {
            // InternalGameDsl.g:4802:1: ( '{' )
            // InternalGameDsl.g:4803:2: '{'
            {
             before(grammarAccess.getAbilityAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getAbilityAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__2__Impl"


    // $ANTLR start "rule__Ability__Group__3"
    // InternalGameDsl.g:4812:1: rule__Ability__Group__3 : rule__Ability__Group__3__Impl rule__Ability__Group__4 ;
    public final void rule__Ability__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4816:1: ( rule__Ability__Group__3__Impl rule__Ability__Group__4 )
            // InternalGameDsl.g:4817:2: rule__Ability__Group__3__Impl rule__Ability__Group__4
            {
            pushFollow(FOLLOW_30);
            rule__Ability__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__3"


    // $ANTLR start "rule__Ability__Group__3__Impl"
    // InternalGameDsl.g:4824:1: rule__Ability__Group__3__Impl : ( ( rule__Ability__Group_3__0 )? ) ;
    public final void rule__Ability__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4828:1: ( ( ( rule__Ability__Group_3__0 )? ) )
            // InternalGameDsl.g:4829:1: ( ( rule__Ability__Group_3__0 )? )
            {
            // InternalGameDsl.g:4829:1: ( ( rule__Ability__Group_3__0 )? )
            // InternalGameDsl.g:4830:2: ( rule__Ability__Group_3__0 )?
            {
             before(grammarAccess.getAbilityAccess().getGroup_3()); 
            // InternalGameDsl.g:4831:2: ( rule__Ability__Group_3__0 )?
            int alt37=2;
            int LA37_0 = input.LA(1);

            if ( (LA37_0==51) ) {
                alt37=1;
            }
            switch (alt37) {
                case 1 :
                    // InternalGameDsl.g:4831:3: rule__Ability__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Ability__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getAbilityAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__3__Impl"


    // $ANTLR start "rule__Ability__Group__4"
    // InternalGameDsl.g:4839:1: rule__Ability__Group__4 : rule__Ability__Group__4__Impl rule__Ability__Group__5 ;
    public final void rule__Ability__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4843:1: ( rule__Ability__Group__4__Impl rule__Ability__Group__5 )
            // InternalGameDsl.g:4844:2: rule__Ability__Group__4__Impl rule__Ability__Group__5
            {
            pushFollow(FOLLOW_18);
            rule__Ability__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__4"


    // $ANTLR start "rule__Ability__Group__4__Impl"
    // InternalGameDsl.g:4851:1: rule__Ability__Group__4__Impl : ( 'isBeingUsed:' ) ;
    public final void rule__Ability__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4855:1: ( ( 'isBeingUsed:' ) )
            // InternalGameDsl.g:4856:1: ( 'isBeingUsed:' )
            {
            // InternalGameDsl.g:4856:1: ( 'isBeingUsed:' )
            // InternalGameDsl.g:4857:2: 'isBeingUsed:'
            {
             before(grammarAccess.getAbilityAccess().getIsBeingUsedKeyword_4()); 
            match(input,49,FOLLOW_2); 
             after(grammarAccess.getAbilityAccess().getIsBeingUsedKeyword_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__4__Impl"


    // $ANTLR start "rule__Ability__Group__5"
    // InternalGameDsl.g:4866:1: rule__Ability__Group__5 : rule__Ability__Group__5__Impl rule__Ability__Group__6 ;
    public final void rule__Ability__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4870:1: ( rule__Ability__Group__5__Impl rule__Ability__Group__6 )
            // InternalGameDsl.g:4871:2: rule__Ability__Group__5__Impl rule__Ability__Group__6
            {
            pushFollow(FOLLOW_31);
            rule__Ability__Group__5__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group__6();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__5"


    // $ANTLR start "rule__Ability__Group__5__Impl"
    // InternalGameDsl.g:4878:1: rule__Ability__Group__5__Impl : ( ( rule__Ability__IsBeingUsedAssignment_5 ) ) ;
    public final void rule__Ability__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4882:1: ( ( ( rule__Ability__IsBeingUsedAssignment_5 ) ) )
            // InternalGameDsl.g:4883:1: ( ( rule__Ability__IsBeingUsedAssignment_5 ) )
            {
            // InternalGameDsl.g:4883:1: ( ( rule__Ability__IsBeingUsedAssignment_5 ) )
            // InternalGameDsl.g:4884:2: ( rule__Ability__IsBeingUsedAssignment_5 )
            {
             before(grammarAccess.getAbilityAccess().getIsBeingUsedAssignment_5()); 
            // InternalGameDsl.g:4885:2: ( rule__Ability__IsBeingUsedAssignment_5 )
            // InternalGameDsl.g:4885:3: rule__Ability__IsBeingUsedAssignment_5
            {
            pushFollow(FOLLOW_2);
            rule__Ability__IsBeingUsedAssignment_5();

            state._fsp--;


            }

             after(grammarAccess.getAbilityAccess().getIsBeingUsedAssignment_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__5__Impl"


    // $ANTLR start "rule__Ability__Group__6"
    // InternalGameDsl.g:4893:1: rule__Ability__Group__6 : rule__Ability__Group__6__Impl rule__Ability__Group__7 ;
    public final void rule__Ability__Group__6() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4897:1: ( rule__Ability__Group__6__Impl rule__Ability__Group__7 )
            // InternalGameDsl.g:4898:2: rule__Ability__Group__6__Impl rule__Ability__Group__7
            {
            pushFollow(FOLLOW_5);
            rule__Ability__Group__6__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group__7();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__6"


    // $ANTLR start "rule__Ability__Group__6__Impl"
    // InternalGameDsl.g:4905:1: rule__Ability__Group__6__Impl : ( 'effect' ) ;
    public final void rule__Ability__Group__6__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4909:1: ( ( 'effect' ) )
            // InternalGameDsl.g:4910:1: ( 'effect' )
            {
            // InternalGameDsl.g:4910:1: ( 'effect' )
            // InternalGameDsl.g:4911:2: 'effect'
            {
             before(grammarAccess.getAbilityAccess().getEffectKeyword_6()); 
            match(input,50,FOLLOW_2); 
             after(grammarAccess.getAbilityAccess().getEffectKeyword_6()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__6__Impl"


    // $ANTLR start "rule__Ability__Group__7"
    // InternalGameDsl.g:4920:1: rule__Ability__Group__7 : rule__Ability__Group__7__Impl rule__Ability__Group__8 ;
    public final void rule__Ability__Group__7() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4924:1: ( rule__Ability__Group__7__Impl rule__Ability__Group__8 )
            // InternalGameDsl.g:4925:2: rule__Ability__Group__7__Impl rule__Ability__Group__8
            {
            pushFollow(FOLLOW_32);
            rule__Ability__Group__7__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group__8();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__7"


    // $ANTLR start "rule__Ability__Group__7__Impl"
    // InternalGameDsl.g:4932:1: rule__Ability__Group__7__Impl : ( '{' ) ;
    public final void rule__Ability__Group__7__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4936:1: ( ( '{' ) )
            // InternalGameDsl.g:4937:1: ( '{' )
            {
            // InternalGameDsl.g:4937:1: ( '{' )
            // InternalGameDsl.g:4938:2: '{'
            {
             before(grammarAccess.getAbilityAccess().getLeftCurlyBracketKeyword_7()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getAbilityAccess().getLeftCurlyBracketKeyword_7()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__7__Impl"


    // $ANTLR start "rule__Ability__Group__8"
    // InternalGameDsl.g:4947:1: rule__Ability__Group__8 : rule__Ability__Group__8__Impl rule__Ability__Group__9 ;
    public final void rule__Ability__Group__8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4951:1: ( rule__Ability__Group__8__Impl rule__Ability__Group__9 )
            // InternalGameDsl.g:4952:2: rule__Ability__Group__8__Impl rule__Ability__Group__9
            {
            pushFollow(FOLLOW_8);
            rule__Ability__Group__8__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group__9();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__8"


    // $ANTLR start "rule__Ability__Group__8__Impl"
    // InternalGameDsl.g:4959:1: rule__Ability__Group__8__Impl : ( ( rule__Ability__EffectAssignment_8 ) ) ;
    public final void rule__Ability__Group__8__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4963:1: ( ( ( rule__Ability__EffectAssignment_8 ) ) )
            // InternalGameDsl.g:4964:1: ( ( rule__Ability__EffectAssignment_8 ) )
            {
            // InternalGameDsl.g:4964:1: ( ( rule__Ability__EffectAssignment_8 ) )
            // InternalGameDsl.g:4965:2: ( rule__Ability__EffectAssignment_8 )
            {
             before(grammarAccess.getAbilityAccess().getEffectAssignment_8()); 
            // InternalGameDsl.g:4966:2: ( rule__Ability__EffectAssignment_8 )
            // InternalGameDsl.g:4966:3: rule__Ability__EffectAssignment_8
            {
            pushFollow(FOLLOW_2);
            rule__Ability__EffectAssignment_8();

            state._fsp--;


            }

             after(grammarAccess.getAbilityAccess().getEffectAssignment_8()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__8__Impl"


    // $ANTLR start "rule__Ability__Group__9"
    // InternalGameDsl.g:4974:1: rule__Ability__Group__9 : rule__Ability__Group__9__Impl rule__Ability__Group__10 ;
    public final void rule__Ability__Group__9() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4978:1: ( rule__Ability__Group__9__Impl rule__Ability__Group__10 )
            // InternalGameDsl.g:4979:2: rule__Ability__Group__9__Impl rule__Ability__Group__10
            {
            pushFollow(FOLLOW_8);
            rule__Ability__Group__9__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group__10();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__9"


    // $ANTLR start "rule__Ability__Group__9__Impl"
    // InternalGameDsl.g:4986:1: rule__Ability__Group__9__Impl : ( ( rule__Ability__Group_9__0 )* ) ;
    public final void rule__Ability__Group__9__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:4990:1: ( ( ( rule__Ability__Group_9__0 )* ) )
            // InternalGameDsl.g:4991:1: ( ( rule__Ability__Group_9__0 )* )
            {
            // InternalGameDsl.g:4991:1: ( ( rule__Ability__Group_9__0 )* )
            // InternalGameDsl.g:4992:2: ( rule__Ability__Group_9__0 )*
            {
             before(grammarAccess.getAbilityAccess().getGroup_9()); 
            // InternalGameDsl.g:4993:2: ( rule__Ability__Group_9__0 )*
            loop38:
            do {
                int alt38=2;
                int LA38_0 = input.LA(1);

                if ( (LA38_0==19) ) {
                    alt38=1;
                }


                switch (alt38) {
            	case 1 :
            	    // InternalGameDsl.g:4993:3: rule__Ability__Group_9__0
            	    {
            	    pushFollow(FOLLOW_9);
            	    rule__Ability__Group_9__0();

            	    state._fsp--;


            	    }
            	    break;

            	default :
            	    break loop38;
                }
            } while (true);

             after(grammarAccess.getAbilityAccess().getGroup_9()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__9__Impl"


    // $ANTLR start "rule__Ability__Group__10"
    // InternalGameDsl.g:5001:1: rule__Ability__Group__10 : rule__Ability__Group__10__Impl rule__Ability__Group__11 ;
    public final void rule__Ability__Group__10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5005:1: ( rule__Ability__Group__10__Impl rule__Ability__Group__11 )
            // InternalGameDsl.g:5006:2: rule__Ability__Group__10__Impl rule__Ability__Group__11
            {
            pushFollow(FOLLOW_33);
            rule__Ability__Group__10__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group__11();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__10"


    // $ANTLR start "rule__Ability__Group__10__Impl"
    // InternalGameDsl.g:5013:1: rule__Ability__Group__10__Impl : ( '}' ) ;
    public final void rule__Ability__Group__10__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5017:1: ( ( '}' ) )
            // InternalGameDsl.g:5018:1: ( '}' )
            {
            // InternalGameDsl.g:5018:1: ( '}' )
            // InternalGameDsl.g:5019:2: '}'
            {
             before(grammarAccess.getAbilityAccess().getRightCurlyBracketKeyword_10()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getAbilityAccess().getRightCurlyBracketKeyword_10()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__10__Impl"


    // $ANTLR start "rule__Ability__Group__11"
    // InternalGameDsl.g:5028:1: rule__Ability__Group__11 : rule__Ability__Group__11__Impl ;
    public final void rule__Ability__Group__11() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5032:1: ( rule__Ability__Group__11__Impl )
            // InternalGameDsl.g:5033:2: rule__Ability__Group__11__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Ability__Group__11__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__11"


    // $ANTLR start "rule__Ability__Group__11__Impl"
    // InternalGameDsl.g:5039:1: rule__Ability__Group__11__Impl : ( '}' ) ;
    public final void rule__Ability__Group__11__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5043:1: ( ( '}' ) )
            // InternalGameDsl.g:5044:1: ( '}' )
            {
            // InternalGameDsl.g:5044:1: ( '}' )
            // InternalGameDsl.g:5045:2: '}'
            {
             before(grammarAccess.getAbilityAccess().getRightCurlyBracketKeyword_11()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getAbilityAccess().getRightCurlyBracketKeyword_11()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group__11__Impl"


    // $ANTLR start "rule__Ability__Group_3__0"
    // InternalGameDsl.g:5055:1: rule__Ability__Group_3__0 : rule__Ability__Group_3__0__Impl rule__Ability__Group_3__1 ;
    public final void rule__Ability__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5059:1: ( rule__Ability__Group_3__0__Impl rule__Ability__Group_3__1 )
            // InternalGameDsl.g:5060:2: rule__Ability__Group_3__0__Impl rule__Ability__Group_3__1
            {
            pushFollow(FOLLOW_14);
            rule__Ability__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group_3__0"


    // $ANTLR start "rule__Ability__Group_3__0__Impl"
    // InternalGameDsl.g:5067:1: rule__Ability__Group_3__0__Impl : ( 'duration:' ) ;
    public final void rule__Ability__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5071:1: ( ( 'duration:' ) )
            // InternalGameDsl.g:5072:1: ( 'duration:' )
            {
            // InternalGameDsl.g:5072:1: ( 'duration:' )
            // InternalGameDsl.g:5073:2: 'duration:'
            {
             before(grammarAccess.getAbilityAccess().getDurationKeyword_3_0()); 
            match(input,51,FOLLOW_2); 
             after(grammarAccess.getAbilityAccess().getDurationKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group_3__0__Impl"


    // $ANTLR start "rule__Ability__Group_3__1"
    // InternalGameDsl.g:5082:1: rule__Ability__Group_3__1 : rule__Ability__Group_3__1__Impl ;
    public final void rule__Ability__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5086:1: ( rule__Ability__Group_3__1__Impl )
            // InternalGameDsl.g:5087:2: rule__Ability__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Ability__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group_3__1"


    // $ANTLR start "rule__Ability__Group_3__1__Impl"
    // InternalGameDsl.g:5093:1: rule__Ability__Group_3__1__Impl : ( ( rule__Ability__DurationAssignment_3_1 ) ) ;
    public final void rule__Ability__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5097:1: ( ( ( rule__Ability__DurationAssignment_3_1 ) ) )
            // InternalGameDsl.g:5098:1: ( ( rule__Ability__DurationAssignment_3_1 ) )
            {
            // InternalGameDsl.g:5098:1: ( ( rule__Ability__DurationAssignment_3_1 ) )
            // InternalGameDsl.g:5099:2: ( rule__Ability__DurationAssignment_3_1 )
            {
             before(grammarAccess.getAbilityAccess().getDurationAssignment_3_1()); 
            // InternalGameDsl.g:5100:2: ( rule__Ability__DurationAssignment_3_1 )
            // InternalGameDsl.g:5100:3: rule__Ability__DurationAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Ability__DurationAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getAbilityAccess().getDurationAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group_3__1__Impl"


    // $ANTLR start "rule__Ability__Group_9__0"
    // InternalGameDsl.g:5109:1: rule__Ability__Group_9__0 : rule__Ability__Group_9__0__Impl rule__Ability__Group_9__1 ;
    public final void rule__Ability__Group_9__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5113:1: ( rule__Ability__Group_9__0__Impl rule__Ability__Group_9__1 )
            // InternalGameDsl.g:5114:2: rule__Ability__Group_9__0__Impl rule__Ability__Group_9__1
            {
            pushFollow(FOLLOW_32);
            rule__Ability__Group_9__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Ability__Group_9__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group_9__0"


    // $ANTLR start "rule__Ability__Group_9__0__Impl"
    // InternalGameDsl.g:5121:1: rule__Ability__Group_9__0__Impl : ( ',' ) ;
    public final void rule__Ability__Group_9__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5125:1: ( ( ',' ) )
            // InternalGameDsl.g:5126:1: ( ',' )
            {
            // InternalGameDsl.g:5126:1: ( ',' )
            // InternalGameDsl.g:5127:2: ','
            {
             before(grammarAccess.getAbilityAccess().getCommaKeyword_9_0()); 
            match(input,19,FOLLOW_2); 
             after(grammarAccess.getAbilityAccess().getCommaKeyword_9_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group_9__0__Impl"


    // $ANTLR start "rule__Ability__Group_9__1"
    // InternalGameDsl.g:5136:1: rule__Ability__Group_9__1 : rule__Ability__Group_9__1__Impl ;
    public final void rule__Ability__Group_9__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5140:1: ( rule__Ability__Group_9__1__Impl )
            // InternalGameDsl.g:5141:2: rule__Ability__Group_9__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Ability__Group_9__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group_9__1"


    // $ANTLR start "rule__Ability__Group_9__1__Impl"
    // InternalGameDsl.g:5147:1: rule__Ability__Group_9__1__Impl : ( ( rule__Ability__EffectAssignment_9_1 ) ) ;
    public final void rule__Ability__Group_9__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5151:1: ( ( ( rule__Ability__EffectAssignment_9_1 ) ) )
            // InternalGameDsl.g:5152:1: ( ( rule__Ability__EffectAssignment_9_1 ) )
            {
            // InternalGameDsl.g:5152:1: ( ( rule__Ability__EffectAssignment_9_1 ) )
            // InternalGameDsl.g:5153:2: ( rule__Ability__EffectAssignment_9_1 )
            {
             before(grammarAccess.getAbilityAccess().getEffectAssignment_9_1()); 
            // InternalGameDsl.g:5154:2: ( rule__Ability__EffectAssignment_9_1 )
            // InternalGameDsl.g:5154:3: rule__Ability__EffectAssignment_9_1
            {
            pushFollow(FOLLOW_2);
            rule__Ability__EffectAssignment_9_1();

            state._fsp--;


            }

             after(grammarAccess.getAbilityAccess().getEffectAssignment_9_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__Group_9__1__Impl"


    // $ANTLR start "rule__Action__Group__0"
    // InternalGameDsl.g:5163:1: rule__Action__Group__0 : rule__Action__Group__0__Impl rule__Action__Group__1 ;
    public final void rule__Action__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5167:1: ( rule__Action__Group__0__Impl rule__Action__Group__1 )
            // InternalGameDsl.g:5168:2: rule__Action__Group__0__Impl rule__Action__Group__1
            {
            pushFollow(FOLLOW_4);
            rule__Action__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__0"


    // $ANTLR start "rule__Action__Group__0__Impl"
    // InternalGameDsl.g:5175:1: rule__Action__Group__0__Impl : ( 'Action' ) ;
    public final void rule__Action__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5179:1: ( ( 'Action' ) )
            // InternalGameDsl.g:5180:1: ( 'Action' )
            {
            // InternalGameDsl.g:5180:1: ( 'Action' )
            // InternalGameDsl.g:5181:2: 'Action'
            {
             before(grammarAccess.getActionAccess().getActionKeyword_0()); 
            match(input,52,FOLLOW_2); 
             after(grammarAccess.getActionAccess().getActionKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__0__Impl"


    // $ANTLR start "rule__Action__Group__1"
    // InternalGameDsl.g:5190:1: rule__Action__Group__1 : rule__Action__Group__1__Impl rule__Action__Group__2 ;
    public final void rule__Action__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5194:1: ( rule__Action__Group__1__Impl rule__Action__Group__2 )
            // InternalGameDsl.g:5195:2: rule__Action__Group__1__Impl rule__Action__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Action__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__1"


    // $ANTLR start "rule__Action__Group__1__Impl"
    // InternalGameDsl.g:5202:1: rule__Action__Group__1__Impl : ( ( rule__Action__NameAssignment_1 ) ) ;
    public final void rule__Action__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5206:1: ( ( ( rule__Action__NameAssignment_1 ) ) )
            // InternalGameDsl.g:5207:1: ( ( rule__Action__NameAssignment_1 ) )
            {
            // InternalGameDsl.g:5207:1: ( ( rule__Action__NameAssignment_1 ) )
            // InternalGameDsl.g:5208:2: ( rule__Action__NameAssignment_1 )
            {
             before(grammarAccess.getActionAccess().getNameAssignment_1()); 
            // InternalGameDsl.g:5209:2: ( rule__Action__NameAssignment_1 )
            // InternalGameDsl.g:5209:3: rule__Action__NameAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Action__NameAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getActionAccess().getNameAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__1__Impl"


    // $ANTLR start "rule__Action__Group__2"
    // InternalGameDsl.g:5217:1: rule__Action__Group__2 : rule__Action__Group__2__Impl rule__Action__Group__3 ;
    public final void rule__Action__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5221:1: ( rule__Action__Group__2__Impl rule__Action__Group__3 )
            // InternalGameDsl.g:5222:2: rule__Action__Group__2__Impl rule__Action__Group__3
            {
            pushFollow(FOLLOW_34);
            rule__Action__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__2"


    // $ANTLR start "rule__Action__Group__2__Impl"
    // InternalGameDsl.g:5229:1: rule__Action__Group__2__Impl : ( '{' ) ;
    public final void rule__Action__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5233:1: ( ( '{' ) )
            // InternalGameDsl.g:5234:1: ( '{' )
            {
            // InternalGameDsl.g:5234:1: ( '{' )
            // InternalGameDsl.g:5235:2: '{'
            {
             before(grammarAccess.getActionAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getActionAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__2__Impl"


    // $ANTLR start "rule__Action__Group__3"
    // InternalGameDsl.g:5244:1: rule__Action__Group__3 : rule__Action__Group__3__Impl rule__Action__Group__4 ;
    public final void rule__Action__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5248:1: ( rule__Action__Group__3__Impl rule__Action__Group__4 )
            // InternalGameDsl.g:5249:2: rule__Action__Group__3__Impl rule__Action__Group__4
            {
            pushFollow(FOLLOW_4);
            rule__Action__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__3"


    // $ANTLR start "rule__Action__Group__3__Impl"
    // InternalGameDsl.g:5256:1: rule__Action__Group__3__Impl : ( 'effect:' ) ;
    public final void rule__Action__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5260:1: ( ( 'effect:' ) )
            // InternalGameDsl.g:5261:1: ( 'effect:' )
            {
            // InternalGameDsl.g:5261:1: ( 'effect:' )
            // InternalGameDsl.g:5262:2: 'effect:'
            {
             before(grammarAccess.getActionAccess().getEffectKeyword_3()); 
            match(input,45,FOLLOW_2); 
             after(grammarAccess.getActionAccess().getEffectKeyword_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__3__Impl"


    // $ANTLR start "rule__Action__Group__4"
    // InternalGameDsl.g:5271:1: rule__Action__Group__4 : rule__Action__Group__4__Impl rule__Action__Group__5 ;
    public final void rule__Action__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5275:1: ( rule__Action__Group__4__Impl rule__Action__Group__5 )
            // InternalGameDsl.g:5276:2: rule__Action__Group__4__Impl rule__Action__Group__5
            {
            pushFollow(FOLLOW_33);
            rule__Action__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Action__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__4"


    // $ANTLR start "rule__Action__Group__4__Impl"
    // InternalGameDsl.g:5283:1: rule__Action__Group__4__Impl : ( ( rule__Action__EffectAssignment_4 ) ) ;
    public final void rule__Action__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5287:1: ( ( ( rule__Action__EffectAssignment_4 ) ) )
            // InternalGameDsl.g:5288:1: ( ( rule__Action__EffectAssignment_4 ) )
            {
            // InternalGameDsl.g:5288:1: ( ( rule__Action__EffectAssignment_4 ) )
            // InternalGameDsl.g:5289:2: ( rule__Action__EffectAssignment_4 )
            {
             before(grammarAccess.getActionAccess().getEffectAssignment_4()); 
            // InternalGameDsl.g:5290:2: ( rule__Action__EffectAssignment_4 )
            // InternalGameDsl.g:5290:3: rule__Action__EffectAssignment_4
            {
            pushFollow(FOLLOW_2);
            rule__Action__EffectAssignment_4();

            state._fsp--;


            }

             after(grammarAccess.getActionAccess().getEffectAssignment_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__4__Impl"


    // $ANTLR start "rule__Action__Group__5"
    // InternalGameDsl.g:5298:1: rule__Action__Group__5 : rule__Action__Group__5__Impl ;
    public final void rule__Action__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5302:1: ( rule__Action__Group__5__Impl )
            // InternalGameDsl.g:5303:2: rule__Action__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Action__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__5"


    // $ANTLR start "rule__Action__Group__5__Impl"
    // InternalGameDsl.g:5309:1: rule__Action__Group__5__Impl : ( '}' ) ;
    public final void rule__Action__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5313:1: ( ( '}' ) )
            // InternalGameDsl.g:5314:1: ( '}' )
            {
            // InternalGameDsl.g:5314:1: ( '}' )
            // InternalGameDsl.g:5315:2: '}'
            {
             before(grammarAccess.getActionAccess().getRightCurlyBracketKeyword_5()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getActionAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__Group__5__Impl"


    // $ANTLR start "rule__Effect__Group__0"
    // InternalGameDsl.g:5325:1: rule__Effect__Group__0 : rule__Effect__Group__0__Impl rule__Effect__Group__1 ;
    public final void rule__Effect__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5329:1: ( rule__Effect__Group__0__Impl rule__Effect__Group__1 )
            // InternalGameDsl.g:5330:2: rule__Effect__Group__0__Impl rule__Effect__Group__1
            {
            pushFollow(FOLLOW_35);
            rule__Effect__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Effect__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__0"


    // $ANTLR start "rule__Effect__Group__0__Impl"
    // InternalGameDsl.g:5337:1: rule__Effect__Group__0__Impl : ( 'Effect' ) ;
    public final void rule__Effect__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5341:1: ( ( 'Effect' ) )
            // InternalGameDsl.g:5342:1: ( 'Effect' )
            {
            // InternalGameDsl.g:5342:1: ( 'Effect' )
            // InternalGameDsl.g:5343:2: 'Effect'
            {
             before(grammarAccess.getEffectAccess().getEffectKeyword_0()); 
            match(input,53,FOLLOW_2); 
             after(grammarAccess.getEffectAccess().getEffectKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__0__Impl"


    // $ANTLR start "rule__Effect__Group__1"
    // InternalGameDsl.g:5352:1: rule__Effect__Group__1 : rule__Effect__Group__1__Impl rule__Effect__Group__2 ;
    public final void rule__Effect__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5356:1: ( rule__Effect__Group__1__Impl rule__Effect__Group__2 )
            // InternalGameDsl.g:5357:2: rule__Effect__Group__1__Impl rule__Effect__Group__2
            {
            pushFollow(FOLLOW_5);
            rule__Effect__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Effect__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__1"


    // $ANTLR start "rule__Effect__Group__1__Impl"
    // InternalGameDsl.g:5364:1: rule__Effect__Group__1__Impl : ( ( rule__Effect__IdentifierAssignment_1 ) ) ;
    public final void rule__Effect__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5368:1: ( ( ( rule__Effect__IdentifierAssignment_1 ) ) )
            // InternalGameDsl.g:5369:1: ( ( rule__Effect__IdentifierAssignment_1 ) )
            {
            // InternalGameDsl.g:5369:1: ( ( rule__Effect__IdentifierAssignment_1 ) )
            // InternalGameDsl.g:5370:2: ( rule__Effect__IdentifierAssignment_1 )
            {
             before(grammarAccess.getEffectAccess().getIdentifierAssignment_1()); 
            // InternalGameDsl.g:5371:2: ( rule__Effect__IdentifierAssignment_1 )
            // InternalGameDsl.g:5371:3: rule__Effect__IdentifierAssignment_1
            {
            pushFollow(FOLLOW_2);
            rule__Effect__IdentifierAssignment_1();

            state._fsp--;


            }

             after(grammarAccess.getEffectAccess().getIdentifierAssignment_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__1__Impl"


    // $ANTLR start "rule__Effect__Group__2"
    // InternalGameDsl.g:5379:1: rule__Effect__Group__2 : rule__Effect__Group__2__Impl rule__Effect__Group__3 ;
    public final void rule__Effect__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5383:1: ( rule__Effect__Group__2__Impl rule__Effect__Group__3 )
            // InternalGameDsl.g:5384:2: rule__Effect__Group__2__Impl rule__Effect__Group__3
            {
            pushFollow(FOLLOW_36);
            rule__Effect__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Effect__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__2"


    // $ANTLR start "rule__Effect__Group__2__Impl"
    // InternalGameDsl.g:5391:1: rule__Effect__Group__2__Impl : ( '{' ) ;
    public final void rule__Effect__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5395:1: ( ( '{' ) )
            // InternalGameDsl.g:5396:1: ( '{' )
            {
            // InternalGameDsl.g:5396:1: ( '{' )
            // InternalGameDsl.g:5397:2: '{'
            {
             before(grammarAccess.getEffectAccess().getLeftCurlyBracketKeyword_2()); 
            match(input,16,FOLLOW_2); 
             after(grammarAccess.getEffectAccess().getLeftCurlyBracketKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__2__Impl"


    // $ANTLR start "rule__Effect__Group__3"
    // InternalGameDsl.g:5406:1: rule__Effect__Group__3 : rule__Effect__Group__3__Impl rule__Effect__Group__4 ;
    public final void rule__Effect__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5410:1: ( rule__Effect__Group__3__Impl rule__Effect__Group__4 )
            // InternalGameDsl.g:5411:2: rule__Effect__Group__3__Impl rule__Effect__Group__4
            {
            pushFollow(FOLLOW_36);
            rule__Effect__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Effect__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__3"


    // $ANTLR start "rule__Effect__Group__3__Impl"
    // InternalGameDsl.g:5418:1: rule__Effect__Group__3__Impl : ( ( rule__Effect__Group_3__0 )? ) ;
    public final void rule__Effect__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5422:1: ( ( ( rule__Effect__Group_3__0 )? ) )
            // InternalGameDsl.g:5423:1: ( ( rule__Effect__Group_3__0 )? )
            {
            // InternalGameDsl.g:5423:1: ( ( rule__Effect__Group_3__0 )? )
            // InternalGameDsl.g:5424:2: ( rule__Effect__Group_3__0 )?
            {
             before(grammarAccess.getEffectAccess().getGroup_3()); 
            // InternalGameDsl.g:5425:2: ( rule__Effect__Group_3__0 )?
            int alt39=2;
            int LA39_0 = input.LA(1);

            if ( (LA39_0==35) ) {
                alt39=1;
            }
            switch (alt39) {
                case 1 :
                    // InternalGameDsl.g:5425:3: rule__Effect__Group_3__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Effect__Group_3__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEffectAccess().getGroup_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__3__Impl"


    // $ANTLR start "rule__Effect__Group__4"
    // InternalGameDsl.g:5433:1: rule__Effect__Group__4 : rule__Effect__Group__4__Impl rule__Effect__Group__5 ;
    public final void rule__Effect__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5437:1: ( rule__Effect__Group__4__Impl rule__Effect__Group__5 )
            // InternalGameDsl.g:5438:2: rule__Effect__Group__4__Impl rule__Effect__Group__5
            {
            pushFollow(FOLLOW_36);
            rule__Effect__Group__4__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Effect__Group__5();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__4"


    // $ANTLR start "rule__Effect__Group__4__Impl"
    // InternalGameDsl.g:5445:1: rule__Effect__Group__4__Impl : ( ( rule__Effect__Group_4__0 )? ) ;
    public final void rule__Effect__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5449:1: ( ( ( rule__Effect__Group_4__0 )? ) )
            // InternalGameDsl.g:5450:1: ( ( rule__Effect__Group_4__0 )? )
            {
            // InternalGameDsl.g:5450:1: ( ( rule__Effect__Group_4__0 )? )
            // InternalGameDsl.g:5451:2: ( rule__Effect__Group_4__0 )?
            {
             before(grammarAccess.getEffectAccess().getGroup_4()); 
            // InternalGameDsl.g:5452:2: ( rule__Effect__Group_4__0 )?
            int alt40=2;
            int LA40_0 = input.LA(1);

            if ( (LA40_0==54) ) {
                alt40=1;
            }
            switch (alt40) {
                case 1 :
                    // InternalGameDsl.g:5452:3: rule__Effect__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__Effect__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEffectAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__4__Impl"


    // $ANTLR start "rule__Effect__Group__5"
    // InternalGameDsl.g:5460:1: rule__Effect__Group__5 : rule__Effect__Group__5__Impl ;
    public final void rule__Effect__Group__5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5464:1: ( rule__Effect__Group__5__Impl )
            // InternalGameDsl.g:5465:2: rule__Effect__Group__5__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Effect__Group__5__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__5"


    // $ANTLR start "rule__Effect__Group__5__Impl"
    // InternalGameDsl.g:5471:1: rule__Effect__Group__5__Impl : ( '}' ) ;
    public final void rule__Effect__Group__5__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5475:1: ( ( '}' ) )
            // InternalGameDsl.g:5476:1: ( '}' )
            {
            // InternalGameDsl.g:5476:1: ( '}' )
            // InternalGameDsl.g:5477:2: '}'
            {
             before(grammarAccess.getEffectAccess().getRightCurlyBracketKeyword_5()); 
            match(input,17,FOLLOW_2); 
             after(grammarAccess.getEffectAccess().getRightCurlyBracketKeyword_5()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group__5__Impl"


    // $ANTLR start "rule__Effect__Group_3__0"
    // InternalGameDsl.g:5487:1: rule__Effect__Group_3__0 : rule__Effect__Group_3__0__Impl rule__Effect__Group_3__1 ;
    public final void rule__Effect__Group_3__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5491:1: ( rule__Effect__Group_3__0__Impl rule__Effect__Group_3__1 )
            // InternalGameDsl.g:5492:2: rule__Effect__Group_3__0__Impl rule__Effect__Group_3__1
            {
            pushFollow(FOLLOW_24);
            rule__Effect__Group_3__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Effect__Group_3__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group_3__0"


    // $ANTLR start "rule__Effect__Group_3__0__Impl"
    // InternalGameDsl.g:5499:1: rule__Effect__Group_3__0__Impl : ( 'velocity:' ) ;
    public final void rule__Effect__Group_3__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5503:1: ( ( 'velocity:' ) )
            // InternalGameDsl.g:5504:1: ( 'velocity:' )
            {
            // InternalGameDsl.g:5504:1: ( 'velocity:' )
            // InternalGameDsl.g:5505:2: 'velocity:'
            {
             before(grammarAccess.getEffectAccess().getVelocityKeyword_3_0()); 
            match(input,35,FOLLOW_2); 
             after(grammarAccess.getEffectAccess().getVelocityKeyword_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group_3__0__Impl"


    // $ANTLR start "rule__Effect__Group_3__1"
    // InternalGameDsl.g:5514:1: rule__Effect__Group_3__1 : rule__Effect__Group_3__1__Impl ;
    public final void rule__Effect__Group_3__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5518:1: ( rule__Effect__Group_3__1__Impl )
            // InternalGameDsl.g:5519:2: rule__Effect__Group_3__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Effect__Group_3__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group_3__1"


    // $ANTLR start "rule__Effect__Group_3__1__Impl"
    // InternalGameDsl.g:5525:1: rule__Effect__Group_3__1__Impl : ( ( rule__Effect__VelocityAssignment_3_1 ) ) ;
    public final void rule__Effect__Group_3__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5529:1: ( ( ( rule__Effect__VelocityAssignment_3_1 ) ) )
            // InternalGameDsl.g:5530:1: ( ( rule__Effect__VelocityAssignment_3_1 ) )
            {
            // InternalGameDsl.g:5530:1: ( ( rule__Effect__VelocityAssignment_3_1 ) )
            // InternalGameDsl.g:5531:2: ( rule__Effect__VelocityAssignment_3_1 )
            {
             before(grammarAccess.getEffectAccess().getVelocityAssignment_3_1()); 
            // InternalGameDsl.g:5532:2: ( rule__Effect__VelocityAssignment_3_1 )
            // InternalGameDsl.g:5532:3: rule__Effect__VelocityAssignment_3_1
            {
            pushFollow(FOLLOW_2);
            rule__Effect__VelocityAssignment_3_1();

            state._fsp--;


            }

             after(grammarAccess.getEffectAccess().getVelocityAssignment_3_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group_3__1__Impl"


    // $ANTLR start "rule__Effect__Group_4__0"
    // InternalGameDsl.g:5541:1: rule__Effect__Group_4__0 : rule__Effect__Group_4__0__Impl rule__Effect__Group_4__1 ;
    public final void rule__Effect__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5545:1: ( rule__Effect__Group_4__0__Impl rule__Effect__Group_4__1 )
            // InternalGameDsl.g:5546:2: rule__Effect__Group_4__0__Impl rule__Effect__Group_4__1
            {
            pushFollow(FOLLOW_24);
            rule__Effect__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__Effect__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group_4__0"


    // $ANTLR start "rule__Effect__Group_4__0__Impl"
    // InternalGameDsl.g:5553:1: rule__Effect__Group_4__0__Impl : ( 'range:' ) ;
    public final void rule__Effect__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5557:1: ( ( 'range:' ) )
            // InternalGameDsl.g:5558:1: ( 'range:' )
            {
            // InternalGameDsl.g:5558:1: ( 'range:' )
            // InternalGameDsl.g:5559:2: 'range:'
            {
             before(grammarAccess.getEffectAccess().getRangeKeyword_4_0()); 
            match(input,54,FOLLOW_2); 
             after(grammarAccess.getEffectAccess().getRangeKeyword_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group_4__0__Impl"


    // $ANTLR start "rule__Effect__Group_4__1"
    // InternalGameDsl.g:5568:1: rule__Effect__Group_4__1 : rule__Effect__Group_4__1__Impl ;
    public final void rule__Effect__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5572:1: ( rule__Effect__Group_4__1__Impl )
            // InternalGameDsl.g:5573:2: rule__Effect__Group_4__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__Effect__Group_4__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group_4__1"


    // $ANTLR start "rule__Effect__Group_4__1__Impl"
    // InternalGameDsl.g:5579:1: rule__Effect__Group_4__1__Impl : ( ( rule__Effect__RangeAssignment_4_1 ) ) ;
    public final void rule__Effect__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5583:1: ( ( ( rule__Effect__RangeAssignment_4_1 ) ) )
            // InternalGameDsl.g:5584:1: ( ( rule__Effect__RangeAssignment_4_1 ) )
            {
            // InternalGameDsl.g:5584:1: ( ( rule__Effect__RangeAssignment_4_1 ) )
            // InternalGameDsl.g:5585:2: ( rule__Effect__RangeAssignment_4_1 )
            {
             before(grammarAccess.getEffectAccess().getRangeAssignment_4_1()); 
            // InternalGameDsl.g:5586:2: ( rule__Effect__RangeAssignment_4_1 )
            // InternalGameDsl.g:5586:3: rule__Effect__RangeAssignment_4_1
            {
            pushFollow(FOLLOW_2);
            rule__Effect__RangeAssignment_4_1();

            state._fsp--;


            }

             after(grammarAccess.getEffectAccess().getRangeAssignment_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__Group_4__1__Impl"


    // $ANTLR start "rule__EInt__Group__0"
    // InternalGameDsl.g:5595:1: rule__EInt__Group__0 : rule__EInt__Group__0__Impl rule__EInt__Group__1 ;
    public final void rule__EInt__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5599:1: ( rule__EInt__Group__0__Impl rule__EInt__Group__1 )
            // InternalGameDsl.g:5600:2: rule__EInt__Group__0__Impl rule__EInt__Group__1
            {
            pushFollow(FOLLOW_14);
            rule__EInt__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EInt__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__0"


    // $ANTLR start "rule__EInt__Group__0__Impl"
    // InternalGameDsl.g:5607:1: rule__EInt__Group__0__Impl : ( ( '-' )? ) ;
    public final void rule__EInt__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5611:1: ( ( ( '-' )? ) )
            // InternalGameDsl.g:5612:1: ( ( '-' )? )
            {
            // InternalGameDsl.g:5612:1: ( ( '-' )? )
            // InternalGameDsl.g:5613:2: ( '-' )?
            {
             before(grammarAccess.getEIntAccess().getHyphenMinusKeyword_0()); 
            // InternalGameDsl.g:5614:2: ( '-' )?
            int alt41=2;
            int LA41_0 = input.LA(1);

            if ( (LA41_0==55) ) {
                alt41=1;
            }
            switch (alt41) {
                case 1 :
                    // InternalGameDsl.g:5614:3: '-'
                    {
                    match(input,55,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEIntAccess().getHyphenMinusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__0__Impl"


    // $ANTLR start "rule__EInt__Group__1"
    // InternalGameDsl.g:5622:1: rule__EInt__Group__1 : rule__EInt__Group__1__Impl ;
    public final void rule__EInt__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5626:1: ( rule__EInt__Group__1__Impl )
            // InternalGameDsl.g:5627:2: rule__EInt__Group__1__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EInt__Group__1__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__1"


    // $ANTLR start "rule__EInt__Group__1__Impl"
    // InternalGameDsl.g:5633:1: rule__EInt__Group__1__Impl : ( RULE_INT ) ;
    public final void rule__EInt__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5637:1: ( ( RULE_INT ) )
            // InternalGameDsl.g:5638:1: ( RULE_INT )
            {
            // InternalGameDsl.g:5638:1: ( RULE_INT )
            // InternalGameDsl.g:5639:2: RULE_INT
            {
             before(grammarAccess.getEIntAccess().getINTTerminalRuleCall_1()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEIntAccess().getINTTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EInt__Group__1__Impl"


    // $ANTLR start "rule__EFloat__Group__0"
    // InternalGameDsl.g:5649:1: rule__EFloat__Group__0 : rule__EFloat__Group__0__Impl rule__EFloat__Group__1 ;
    public final void rule__EFloat__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5653:1: ( rule__EFloat__Group__0__Impl rule__EFloat__Group__1 )
            // InternalGameDsl.g:5654:2: rule__EFloat__Group__0__Impl rule__EFloat__Group__1
            {
            pushFollow(FOLLOW_24);
            rule__EFloat__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__0"


    // $ANTLR start "rule__EFloat__Group__0__Impl"
    // InternalGameDsl.g:5661:1: rule__EFloat__Group__0__Impl : ( ( '-' )? ) ;
    public final void rule__EFloat__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5665:1: ( ( ( '-' )? ) )
            // InternalGameDsl.g:5666:1: ( ( '-' )? )
            {
            // InternalGameDsl.g:5666:1: ( ( '-' )? )
            // InternalGameDsl.g:5667:2: ( '-' )?
            {
             before(grammarAccess.getEFloatAccess().getHyphenMinusKeyword_0()); 
            // InternalGameDsl.g:5668:2: ( '-' )?
            int alt42=2;
            int LA42_0 = input.LA(1);

            if ( (LA42_0==55) ) {
                alt42=1;
            }
            switch (alt42) {
                case 1 :
                    // InternalGameDsl.g:5668:3: '-'
                    {
                    match(input,55,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEFloatAccess().getHyphenMinusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__0__Impl"


    // $ANTLR start "rule__EFloat__Group__1"
    // InternalGameDsl.g:5676:1: rule__EFloat__Group__1 : rule__EFloat__Group__1__Impl rule__EFloat__Group__2 ;
    public final void rule__EFloat__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5680:1: ( rule__EFloat__Group__1__Impl rule__EFloat__Group__2 )
            // InternalGameDsl.g:5681:2: rule__EFloat__Group__1__Impl rule__EFloat__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__EFloat__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__1"


    // $ANTLR start "rule__EFloat__Group__1__Impl"
    // InternalGameDsl.g:5688:1: rule__EFloat__Group__1__Impl : ( ( RULE_INT )? ) ;
    public final void rule__EFloat__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5692:1: ( ( ( RULE_INT )? ) )
            // InternalGameDsl.g:5693:1: ( ( RULE_INT )? )
            {
            // InternalGameDsl.g:5693:1: ( ( RULE_INT )? )
            // InternalGameDsl.g:5694:2: ( RULE_INT )?
            {
             before(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_1()); 
            // InternalGameDsl.g:5695:2: ( RULE_INT )?
            int alt43=2;
            int LA43_0 = input.LA(1);

            if ( (LA43_0==RULE_INT) ) {
                alt43=1;
            }
            switch (alt43) {
                case 1 :
                    // InternalGameDsl.g:5695:3: RULE_INT
                    {
                    match(input,RULE_INT,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__1__Impl"


    // $ANTLR start "rule__EFloat__Group__2"
    // InternalGameDsl.g:5703:1: rule__EFloat__Group__2 : rule__EFloat__Group__2__Impl rule__EFloat__Group__3 ;
    public final void rule__EFloat__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5707:1: ( rule__EFloat__Group__2__Impl rule__EFloat__Group__3 )
            // InternalGameDsl.g:5708:2: rule__EFloat__Group__2__Impl rule__EFloat__Group__3
            {
            pushFollow(FOLLOW_37);
            rule__EFloat__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__2"


    // $ANTLR start "rule__EFloat__Group__2__Impl"
    // InternalGameDsl.g:5715:1: rule__EFloat__Group__2__Impl : ( '.' ) ;
    public final void rule__EFloat__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5719:1: ( ( '.' ) )
            // InternalGameDsl.g:5720:1: ( '.' )
            {
            // InternalGameDsl.g:5720:1: ( '.' )
            // InternalGameDsl.g:5721:2: '.'
            {
             before(grammarAccess.getEFloatAccess().getFullStopKeyword_2()); 
            match(input,56,FOLLOW_2); 
             after(grammarAccess.getEFloatAccess().getFullStopKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__2__Impl"


    // $ANTLR start "rule__EFloat__Group__3"
    // InternalGameDsl.g:5730:1: rule__EFloat__Group__3 : rule__EFloat__Group__3__Impl rule__EFloat__Group__4 ;
    public final void rule__EFloat__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5734:1: ( rule__EFloat__Group__3__Impl rule__EFloat__Group__4 )
            // InternalGameDsl.g:5735:2: rule__EFloat__Group__3__Impl rule__EFloat__Group__4
            {
            pushFollow(FOLLOW_38);
            rule__EFloat__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__3"


    // $ANTLR start "rule__EFloat__Group__3__Impl"
    // InternalGameDsl.g:5742:1: rule__EFloat__Group__3__Impl : ( RULE_INT ) ;
    public final void rule__EFloat__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5746:1: ( ( RULE_INT ) )
            // InternalGameDsl.g:5747:1: ( RULE_INT )
            {
            // InternalGameDsl.g:5747:1: ( RULE_INT )
            // InternalGameDsl.g:5748:2: RULE_INT
            {
             before(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_3()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__3__Impl"


    // $ANTLR start "rule__EFloat__Group__4"
    // InternalGameDsl.g:5757:1: rule__EFloat__Group__4 : rule__EFloat__Group__4__Impl ;
    public final void rule__EFloat__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5761:1: ( rule__EFloat__Group__4__Impl )
            // InternalGameDsl.g:5762:2: rule__EFloat__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EFloat__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__4"


    // $ANTLR start "rule__EFloat__Group__4__Impl"
    // InternalGameDsl.g:5768:1: rule__EFloat__Group__4__Impl : ( ( rule__EFloat__Group_4__0 )? ) ;
    public final void rule__EFloat__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5772:1: ( ( ( rule__EFloat__Group_4__0 )? ) )
            // InternalGameDsl.g:5773:1: ( ( rule__EFloat__Group_4__0 )? )
            {
            // InternalGameDsl.g:5773:1: ( ( rule__EFloat__Group_4__0 )? )
            // InternalGameDsl.g:5774:2: ( rule__EFloat__Group_4__0 )?
            {
             before(grammarAccess.getEFloatAccess().getGroup_4()); 
            // InternalGameDsl.g:5775:2: ( rule__EFloat__Group_4__0 )?
            int alt44=2;
            int LA44_0 = input.LA(1);

            if ( ((LA44_0>=13 && LA44_0<=14)) ) {
                alt44=1;
            }
            switch (alt44) {
                case 1 :
                    // InternalGameDsl.g:5775:3: rule__EFloat__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__EFloat__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEFloatAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group__4__Impl"


    // $ANTLR start "rule__EFloat__Group_4__0"
    // InternalGameDsl.g:5784:1: rule__EFloat__Group_4__0 : rule__EFloat__Group_4__0__Impl rule__EFloat__Group_4__1 ;
    public final void rule__EFloat__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5788:1: ( rule__EFloat__Group_4__0__Impl rule__EFloat__Group_4__1 )
            // InternalGameDsl.g:5789:2: rule__EFloat__Group_4__0__Impl rule__EFloat__Group_4__1
            {
            pushFollow(FOLLOW_14);
            rule__EFloat__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__0"


    // $ANTLR start "rule__EFloat__Group_4__0__Impl"
    // InternalGameDsl.g:5796:1: rule__EFloat__Group_4__0__Impl : ( ( rule__EFloat__Alternatives_4_0 ) ) ;
    public final void rule__EFloat__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5800:1: ( ( ( rule__EFloat__Alternatives_4_0 ) ) )
            // InternalGameDsl.g:5801:1: ( ( rule__EFloat__Alternatives_4_0 ) )
            {
            // InternalGameDsl.g:5801:1: ( ( rule__EFloat__Alternatives_4_0 ) )
            // InternalGameDsl.g:5802:2: ( rule__EFloat__Alternatives_4_0 )
            {
             before(grammarAccess.getEFloatAccess().getAlternatives_4_0()); 
            // InternalGameDsl.g:5803:2: ( rule__EFloat__Alternatives_4_0 )
            // InternalGameDsl.g:5803:3: rule__EFloat__Alternatives_4_0
            {
            pushFollow(FOLLOW_2);
            rule__EFloat__Alternatives_4_0();

            state._fsp--;


            }

             after(grammarAccess.getEFloatAccess().getAlternatives_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__0__Impl"


    // $ANTLR start "rule__EFloat__Group_4__1"
    // InternalGameDsl.g:5811:1: rule__EFloat__Group_4__1 : rule__EFloat__Group_4__1__Impl rule__EFloat__Group_4__2 ;
    public final void rule__EFloat__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5815:1: ( rule__EFloat__Group_4__1__Impl rule__EFloat__Group_4__2 )
            // InternalGameDsl.g:5816:2: rule__EFloat__Group_4__1__Impl rule__EFloat__Group_4__2
            {
            pushFollow(FOLLOW_14);
            rule__EFloat__Group_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EFloat__Group_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__1"


    // $ANTLR start "rule__EFloat__Group_4__1__Impl"
    // InternalGameDsl.g:5823:1: rule__EFloat__Group_4__1__Impl : ( ( '-' )? ) ;
    public final void rule__EFloat__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5827:1: ( ( ( '-' )? ) )
            // InternalGameDsl.g:5828:1: ( ( '-' )? )
            {
            // InternalGameDsl.g:5828:1: ( ( '-' )? )
            // InternalGameDsl.g:5829:2: ( '-' )?
            {
             before(grammarAccess.getEFloatAccess().getHyphenMinusKeyword_4_1()); 
            // InternalGameDsl.g:5830:2: ( '-' )?
            int alt45=2;
            int LA45_0 = input.LA(1);

            if ( (LA45_0==55) ) {
                alt45=1;
            }
            switch (alt45) {
                case 1 :
                    // InternalGameDsl.g:5830:3: '-'
                    {
                    match(input,55,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEFloatAccess().getHyphenMinusKeyword_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__1__Impl"


    // $ANTLR start "rule__EFloat__Group_4__2"
    // InternalGameDsl.g:5838:1: rule__EFloat__Group_4__2 : rule__EFloat__Group_4__2__Impl ;
    public final void rule__EFloat__Group_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5842:1: ( rule__EFloat__Group_4__2__Impl )
            // InternalGameDsl.g:5843:2: rule__EFloat__Group_4__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EFloat__Group_4__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__2"


    // $ANTLR start "rule__EFloat__Group_4__2__Impl"
    // InternalGameDsl.g:5849:1: rule__EFloat__Group_4__2__Impl : ( RULE_INT ) ;
    public final void rule__EFloat__Group_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5853:1: ( ( RULE_INT ) )
            // InternalGameDsl.g:5854:1: ( RULE_INT )
            {
            // InternalGameDsl.g:5854:1: ( RULE_INT )
            // InternalGameDsl.g:5855:2: RULE_INT
            {
             before(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_4_2()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEFloatAccess().getINTTerminalRuleCall_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EFloat__Group_4__2__Impl"


    // $ANTLR start "rule__EDouble__Group__0"
    // InternalGameDsl.g:5865:1: rule__EDouble__Group__0 : rule__EDouble__Group__0__Impl rule__EDouble__Group__1 ;
    public final void rule__EDouble__Group__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5869:1: ( rule__EDouble__Group__0__Impl rule__EDouble__Group__1 )
            // InternalGameDsl.g:5870:2: rule__EDouble__Group__0__Impl rule__EDouble__Group__1
            {
            pushFollow(FOLLOW_24);
            rule__EDouble__Group__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EDouble__Group__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group__0"


    // $ANTLR start "rule__EDouble__Group__0__Impl"
    // InternalGameDsl.g:5877:1: rule__EDouble__Group__0__Impl : ( ( '-' )? ) ;
    public final void rule__EDouble__Group__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5881:1: ( ( ( '-' )? ) )
            // InternalGameDsl.g:5882:1: ( ( '-' )? )
            {
            // InternalGameDsl.g:5882:1: ( ( '-' )? )
            // InternalGameDsl.g:5883:2: ( '-' )?
            {
             before(grammarAccess.getEDoubleAccess().getHyphenMinusKeyword_0()); 
            // InternalGameDsl.g:5884:2: ( '-' )?
            int alt46=2;
            int LA46_0 = input.LA(1);

            if ( (LA46_0==55) ) {
                alt46=1;
            }
            switch (alt46) {
                case 1 :
                    // InternalGameDsl.g:5884:3: '-'
                    {
                    match(input,55,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEDoubleAccess().getHyphenMinusKeyword_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group__0__Impl"


    // $ANTLR start "rule__EDouble__Group__1"
    // InternalGameDsl.g:5892:1: rule__EDouble__Group__1 : rule__EDouble__Group__1__Impl rule__EDouble__Group__2 ;
    public final void rule__EDouble__Group__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5896:1: ( rule__EDouble__Group__1__Impl rule__EDouble__Group__2 )
            // InternalGameDsl.g:5897:2: rule__EDouble__Group__1__Impl rule__EDouble__Group__2
            {
            pushFollow(FOLLOW_24);
            rule__EDouble__Group__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EDouble__Group__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group__1"


    // $ANTLR start "rule__EDouble__Group__1__Impl"
    // InternalGameDsl.g:5904:1: rule__EDouble__Group__1__Impl : ( ( RULE_INT )? ) ;
    public final void rule__EDouble__Group__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5908:1: ( ( ( RULE_INT )? ) )
            // InternalGameDsl.g:5909:1: ( ( RULE_INT )? )
            {
            // InternalGameDsl.g:5909:1: ( ( RULE_INT )? )
            // InternalGameDsl.g:5910:2: ( RULE_INT )?
            {
             before(grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_1()); 
            // InternalGameDsl.g:5911:2: ( RULE_INT )?
            int alt47=2;
            int LA47_0 = input.LA(1);

            if ( (LA47_0==RULE_INT) ) {
                alt47=1;
            }
            switch (alt47) {
                case 1 :
                    // InternalGameDsl.g:5911:3: RULE_INT
                    {
                    match(input,RULE_INT,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group__1__Impl"


    // $ANTLR start "rule__EDouble__Group__2"
    // InternalGameDsl.g:5919:1: rule__EDouble__Group__2 : rule__EDouble__Group__2__Impl rule__EDouble__Group__3 ;
    public final void rule__EDouble__Group__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5923:1: ( rule__EDouble__Group__2__Impl rule__EDouble__Group__3 )
            // InternalGameDsl.g:5924:2: rule__EDouble__Group__2__Impl rule__EDouble__Group__3
            {
            pushFollow(FOLLOW_37);
            rule__EDouble__Group__2__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EDouble__Group__3();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group__2"


    // $ANTLR start "rule__EDouble__Group__2__Impl"
    // InternalGameDsl.g:5931:1: rule__EDouble__Group__2__Impl : ( '.' ) ;
    public final void rule__EDouble__Group__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5935:1: ( ( '.' ) )
            // InternalGameDsl.g:5936:1: ( '.' )
            {
            // InternalGameDsl.g:5936:1: ( '.' )
            // InternalGameDsl.g:5937:2: '.'
            {
             before(grammarAccess.getEDoubleAccess().getFullStopKeyword_2()); 
            match(input,56,FOLLOW_2); 
             after(grammarAccess.getEDoubleAccess().getFullStopKeyword_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group__2__Impl"


    // $ANTLR start "rule__EDouble__Group__3"
    // InternalGameDsl.g:5946:1: rule__EDouble__Group__3 : rule__EDouble__Group__3__Impl rule__EDouble__Group__4 ;
    public final void rule__EDouble__Group__3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5950:1: ( rule__EDouble__Group__3__Impl rule__EDouble__Group__4 )
            // InternalGameDsl.g:5951:2: rule__EDouble__Group__3__Impl rule__EDouble__Group__4
            {
            pushFollow(FOLLOW_38);
            rule__EDouble__Group__3__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EDouble__Group__4();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group__3"


    // $ANTLR start "rule__EDouble__Group__3__Impl"
    // InternalGameDsl.g:5958:1: rule__EDouble__Group__3__Impl : ( RULE_INT ) ;
    public final void rule__EDouble__Group__3__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5962:1: ( ( RULE_INT ) )
            // InternalGameDsl.g:5963:1: ( RULE_INT )
            {
            // InternalGameDsl.g:5963:1: ( RULE_INT )
            // InternalGameDsl.g:5964:2: RULE_INT
            {
             before(grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_3()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_3()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group__3__Impl"


    // $ANTLR start "rule__EDouble__Group__4"
    // InternalGameDsl.g:5973:1: rule__EDouble__Group__4 : rule__EDouble__Group__4__Impl ;
    public final void rule__EDouble__Group__4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5977:1: ( rule__EDouble__Group__4__Impl )
            // InternalGameDsl.g:5978:2: rule__EDouble__Group__4__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EDouble__Group__4__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group__4"


    // $ANTLR start "rule__EDouble__Group__4__Impl"
    // InternalGameDsl.g:5984:1: rule__EDouble__Group__4__Impl : ( ( rule__EDouble__Group_4__0 )? ) ;
    public final void rule__EDouble__Group__4__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:5988:1: ( ( ( rule__EDouble__Group_4__0 )? ) )
            // InternalGameDsl.g:5989:1: ( ( rule__EDouble__Group_4__0 )? )
            {
            // InternalGameDsl.g:5989:1: ( ( rule__EDouble__Group_4__0 )? )
            // InternalGameDsl.g:5990:2: ( rule__EDouble__Group_4__0 )?
            {
             before(grammarAccess.getEDoubleAccess().getGroup_4()); 
            // InternalGameDsl.g:5991:2: ( rule__EDouble__Group_4__0 )?
            int alt48=2;
            int LA48_0 = input.LA(1);

            if ( ((LA48_0>=13 && LA48_0<=14)) ) {
                alt48=1;
            }
            switch (alt48) {
                case 1 :
                    // InternalGameDsl.g:5991:3: rule__EDouble__Group_4__0
                    {
                    pushFollow(FOLLOW_2);
                    rule__EDouble__Group_4__0();

                    state._fsp--;


                    }
                    break;

            }

             after(grammarAccess.getEDoubleAccess().getGroup_4()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group__4__Impl"


    // $ANTLR start "rule__EDouble__Group_4__0"
    // InternalGameDsl.g:6000:1: rule__EDouble__Group_4__0 : rule__EDouble__Group_4__0__Impl rule__EDouble__Group_4__1 ;
    public final void rule__EDouble__Group_4__0() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6004:1: ( rule__EDouble__Group_4__0__Impl rule__EDouble__Group_4__1 )
            // InternalGameDsl.g:6005:2: rule__EDouble__Group_4__0__Impl rule__EDouble__Group_4__1
            {
            pushFollow(FOLLOW_14);
            rule__EDouble__Group_4__0__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EDouble__Group_4__1();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group_4__0"


    // $ANTLR start "rule__EDouble__Group_4__0__Impl"
    // InternalGameDsl.g:6012:1: rule__EDouble__Group_4__0__Impl : ( ( rule__EDouble__Alternatives_4_0 ) ) ;
    public final void rule__EDouble__Group_4__0__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6016:1: ( ( ( rule__EDouble__Alternatives_4_0 ) ) )
            // InternalGameDsl.g:6017:1: ( ( rule__EDouble__Alternatives_4_0 ) )
            {
            // InternalGameDsl.g:6017:1: ( ( rule__EDouble__Alternatives_4_0 ) )
            // InternalGameDsl.g:6018:2: ( rule__EDouble__Alternatives_4_0 )
            {
             before(grammarAccess.getEDoubleAccess().getAlternatives_4_0()); 
            // InternalGameDsl.g:6019:2: ( rule__EDouble__Alternatives_4_0 )
            // InternalGameDsl.g:6019:3: rule__EDouble__Alternatives_4_0
            {
            pushFollow(FOLLOW_2);
            rule__EDouble__Alternatives_4_0();

            state._fsp--;


            }

             after(grammarAccess.getEDoubleAccess().getAlternatives_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group_4__0__Impl"


    // $ANTLR start "rule__EDouble__Group_4__1"
    // InternalGameDsl.g:6027:1: rule__EDouble__Group_4__1 : rule__EDouble__Group_4__1__Impl rule__EDouble__Group_4__2 ;
    public final void rule__EDouble__Group_4__1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6031:1: ( rule__EDouble__Group_4__1__Impl rule__EDouble__Group_4__2 )
            // InternalGameDsl.g:6032:2: rule__EDouble__Group_4__1__Impl rule__EDouble__Group_4__2
            {
            pushFollow(FOLLOW_14);
            rule__EDouble__Group_4__1__Impl();

            state._fsp--;

            pushFollow(FOLLOW_2);
            rule__EDouble__Group_4__2();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group_4__1"


    // $ANTLR start "rule__EDouble__Group_4__1__Impl"
    // InternalGameDsl.g:6039:1: rule__EDouble__Group_4__1__Impl : ( ( '-' )? ) ;
    public final void rule__EDouble__Group_4__1__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6043:1: ( ( ( '-' )? ) )
            // InternalGameDsl.g:6044:1: ( ( '-' )? )
            {
            // InternalGameDsl.g:6044:1: ( ( '-' )? )
            // InternalGameDsl.g:6045:2: ( '-' )?
            {
             before(grammarAccess.getEDoubleAccess().getHyphenMinusKeyword_4_1()); 
            // InternalGameDsl.g:6046:2: ( '-' )?
            int alt49=2;
            int LA49_0 = input.LA(1);

            if ( (LA49_0==55) ) {
                alt49=1;
            }
            switch (alt49) {
                case 1 :
                    // InternalGameDsl.g:6046:3: '-'
                    {
                    match(input,55,FOLLOW_2); 

                    }
                    break;

            }

             after(grammarAccess.getEDoubleAccess().getHyphenMinusKeyword_4_1()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group_4__1__Impl"


    // $ANTLR start "rule__EDouble__Group_4__2"
    // InternalGameDsl.g:6054:1: rule__EDouble__Group_4__2 : rule__EDouble__Group_4__2__Impl ;
    public final void rule__EDouble__Group_4__2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6058:1: ( rule__EDouble__Group_4__2__Impl )
            // InternalGameDsl.g:6059:2: rule__EDouble__Group_4__2__Impl
            {
            pushFollow(FOLLOW_2);
            rule__EDouble__Group_4__2__Impl();

            state._fsp--;


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group_4__2"


    // $ANTLR start "rule__EDouble__Group_4__2__Impl"
    // InternalGameDsl.g:6065:1: rule__EDouble__Group_4__2__Impl : ( RULE_INT ) ;
    public final void rule__EDouble__Group_4__2__Impl() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6069:1: ( ( RULE_INT ) )
            // InternalGameDsl.g:6070:1: ( RULE_INT )
            {
            // InternalGameDsl.g:6070:1: ( RULE_INT )
            // InternalGameDsl.g:6071:2: RULE_INT
            {
             before(grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_4_2()); 
            match(input,RULE_INT,FOLLOW_2); 
             after(grammarAccess.getEDoubleAccess().getINTTerminalRuleCall_4_2()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__EDouble__Group_4__2__Impl"


    // $ANTLR start "rule__Game__NameAssignment_2"
    // InternalGameDsl.g:6081:1: rule__Game__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__Game__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6085:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6086:2: ( ruleEString )
            {
            // InternalGameDsl.g:6086:2: ( ruleEString )
            // InternalGameDsl.g:6087:3: ruleEString
            {
             before(grammarAccess.getGameAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getGameAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__NameAssignment_2"


    // $ANTLR start "rule__Game__DescriptionAssignment_3"
    // InternalGameDsl.g:6096:1: rule__Game__DescriptionAssignment_3 : ( ruleEString ) ;
    public final void rule__Game__DescriptionAssignment_3() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6100:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6101:2: ( ruleEString )
            {
            // InternalGameDsl.g:6101:2: ( ruleEString )
            // InternalGameDsl.g:6102:3: ruleEString
            {
             before(grammarAccess.getGameAccess().getDescriptionEStringParserRuleCall_3_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getGameAccess().getDescriptionEStringParserRuleCall_3_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__DescriptionAssignment_3"


    // $ANTLR start "rule__Game__BackgroundAssignment_5_2"
    // InternalGameDsl.g:6111:1: rule__Game__BackgroundAssignment_5_2 : ( ruleBackground ) ;
    public final void rule__Game__BackgroundAssignment_5_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6115:1: ( ( ruleBackground ) )
            // InternalGameDsl.g:6116:2: ( ruleBackground )
            {
            // InternalGameDsl.g:6116:2: ( ruleBackground )
            // InternalGameDsl.g:6117:3: ruleBackground
            {
             before(grammarAccess.getGameAccess().getBackgroundBackgroundParserRuleCall_5_2_0()); 
            pushFollow(FOLLOW_2);
            ruleBackground();

            state._fsp--;

             after(grammarAccess.getGameAccess().getBackgroundBackgroundParserRuleCall_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__BackgroundAssignment_5_2"


    // $ANTLR start "rule__Game__BackgroundAssignment_5_3_1"
    // InternalGameDsl.g:6126:1: rule__Game__BackgroundAssignment_5_3_1 : ( ruleBackground ) ;
    public final void rule__Game__BackgroundAssignment_5_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6130:1: ( ( ruleBackground ) )
            // InternalGameDsl.g:6131:2: ( ruleBackground )
            {
            // InternalGameDsl.g:6131:2: ( ruleBackground )
            // InternalGameDsl.g:6132:3: ruleBackground
            {
             before(grammarAccess.getGameAccess().getBackgroundBackgroundParserRuleCall_5_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleBackground();

            state._fsp--;

             after(grammarAccess.getGameAccess().getBackgroundBackgroundParserRuleCall_5_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__BackgroundAssignment_5_3_1"


    // $ANTLR start "rule__Game__ObjectTypeAssignment_6_2"
    // InternalGameDsl.g:6141:1: rule__Game__ObjectTypeAssignment_6_2 : ( ruleObjectType ) ;
    public final void rule__Game__ObjectTypeAssignment_6_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6145:1: ( ( ruleObjectType ) )
            // InternalGameDsl.g:6146:2: ( ruleObjectType )
            {
            // InternalGameDsl.g:6146:2: ( ruleObjectType )
            // InternalGameDsl.g:6147:3: ruleObjectType
            {
             before(grammarAccess.getGameAccess().getObjectTypeObjectTypeParserRuleCall_6_2_0()); 
            pushFollow(FOLLOW_2);
            ruleObjectType();

            state._fsp--;

             after(grammarAccess.getGameAccess().getObjectTypeObjectTypeParserRuleCall_6_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__ObjectTypeAssignment_6_2"


    // $ANTLR start "rule__Game__ObjectTypeAssignment_6_3_1"
    // InternalGameDsl.g:6156:1: rule__Game__ObjectTypeAssignment_6_3_1 : ( ruleObjectType ) ;
    public final void rule__Game__ObjectTypeAssignment_6_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6160:1: ( ( ruleObjectType ) )
            // InternalGameDsl.g:6161:2: ( ruleObjectType )
            {
            // InternalGameDsl.g:6161:2: ( ruleObjectType )
            // InternalGameDsl.g:6162:3: ruleObjectType
            {
             before(grammarAccess.getGameAccess().getObjectTypeObjectTypeParserRuleCall_6_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleObjectType();

            state._fsp--;

             after(grammarAccess.getGameAccess().getObjectTypeObjectTypeParserRuleCall_6_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__ObjectTypeAssignment_6_3_1"


    // $ANTLR start "rule__Game__CollisionsAssignment_7_2"
    // InternalGameDsl.g:6171:1: rule__Game__CollisionsAssignment_7_2 : ( ruleCollisions ) ;
    public final void rule__Game__CollisionsAssignment_7_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6175:1: ( ( ruleCollisions ) )
            // InternalGameDsl.g:6176:2: ( ruleCollisions )
            {
            // InternalGameDsl.g:6176:2: ( ruleCollisions )
            // InternalGameDsl.g:6177:3: ruleCollisions
            {
             before(grammarAccess.getGameAccess().getCollisionsCollisionsParserRuleCall_7_2_0()); 
            pushFollow(FOLLOW_2);
            ruleCollisions();

            state._fsp--;

             after(grammarAccess.getGameAccess().getCollisionsCollisionsParserRuleCall_7_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__CollisionsAssignment_7_2"


    // $ANTLR start "rule__Game__CollisionsAssignment_7_3_1"
    // InternalGameDsl.g:6186:1: rule__Game__CollisionsAssignment_7_3_1 : ( ruleCollisions ) ;
    public final void rule__Game__CollisionsAssignment_7_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6190:1: ( ( ruleCollisions ) )
            // InternalGameDsl.g:6191:2: ( ruleCollisions )
            {
            // InternalGameDsl.g:6191:2: ( ruleCollisions )
            // InternalGameDsl.g:6192:3: ruleCollisions
            {
             before(grammarAccess.getGameAccess().getCollisionsCollisionsParserRuleCall_7_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleCollisions();

            state._fsp--;

             after(grammarAccess.getGameAccess().getCollisionsCollisionsParserRuleCall_7_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Game__CollisionsAssignment_7_3_1"


    // $ANTLR start "rule__Background__IdentifierAssignment_1"
    // InternalGameDsl.g:6201:1: rule__Background__IdentifierAssignment_1 : ( ruleEString ) ;
    public final void rule__Background__IdentifierAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6205:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6206:2: ( ruleEString )
            {
            // InternalGameDsl.g:6206:2: ( ruleEString )
            // InternalGameDsl.g:6207:3: ruleEString
            {
             before(grammarAccess.getBackgroundAccess().getIdentifierEStringParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getBackgroundAccess().getIdentifierEStringParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__IdentifierAssignment_1"


    // $ANTLR start "rule__Background__CoordinatesAssignment_5"
    // InternalGameDsl.g:6216:1: rule__Background__CoordinatesAssignment_5 : ( ruleEInt ) ;
    public final void rule__Background__CoordinatesAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6220:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6221:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6221:2: ( ruleEInt )
            // InternalGameDsl.g:6222:3: ruleEInt
            {
             before(grammarAccess.getBackgroundAccess().getCoordinatesEIntParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getBackgroundAccess().getCoordinatesEIntParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__CoordinatesAssignment_5"


    // $ANTLR start "rule__Background__CoordinatesAssignment_6_1"
    // InternalGameDsl.g:6231:1: rule__Background__CoordinatesAssignment_6_1 : ( ruleEInt ) ;
    public final void rule__Background__CoordinatesAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6235:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6236:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6236:2: ( ruleEInt )
            // InternalGameDsl.g:6237:3: ruleEInt
            {
             before(grammarAccess.getBackgroundAccess().getCoordinatesEIntParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getBackgroundAccess().getCoordinatesEIntParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__CoordinatesAssignment_6_1"


    // $ANTLR start "rule__Background__SizeAssignment_10"
    // InternalGameDsl.g:6246:1: rule__Background__SizeAssignment_10 : ( ruleEInt ) ;
    public final void rule__Background__SizeAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6250:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6251:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6251:2: ( ruleEInt )
            // InternalGameDsl.g:6252:3: ruleEInt
            {
             before(grammarAccess.getBackgroundAccess().getSizeEIntParserRuleCall_10_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getBackgroundAccess().getSizeEIntParserRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__SizeAssignment_10"


    // $ANTLR start "rule__Background__SizeAssignment_11_1"
    // InternalGameDsl.g:6261:1: rule__Background__SizeAssignment_11_1 : ( ruleEInt ) ;
    public final void rule__Background__SizeAssignment_11_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6265:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6266:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6266:2: ( ruleEInt )
            // InternalGameDsl.g:6267:3: ruleEInt
            {
             before(grammarAccess.getBackgroundAccess().getSizeEIntParserRuleCall_11_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getBackgroundAccess().getSizeEIntParserRuleCall_11_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__SizeAssignment_11_1"


    // $ANTLR start "rule__Background__BackgroundSpeedAssignment_13_1"
    // InternalGameDsl.g:6276:1: rule__Background__BackgroundSpeedAssignment_13_1 : ( ruleEInt ) ;
    public final void rule__Background__BackgroundSpeedAssignment_13_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6280:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6281:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6281:2: ( ruleEInt )
            // InternalGameDsl.g:6282:3: ruleEInt
            {
             before(grammarAccess.getBackgroundAccess().getBackgroundSpeedEIntParserRuleCall_13_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getBackgroundAccess().getBackgroundSpeedEIntParserRuleCall_13_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__BackgroundSpeedAssignment_13_1"


    // $ANTLR start "rule__Background__BackgroundMovingAssignment_14_1"
    // InternalGameDsl.g:6291:1: rule__Background__BackgroundMovingAssignment_14_1 : ( ruleEBoolean ) ;
    public final void rule__Background__BackgroundMovingAssignment_14_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6295:1: ( ( ruleEBoolean ) )
            // InternalGameDsl.g:6296:2: ( ruleEBoolean )
            {
            // InternalGameDsl.g:6296:2: ( ruleEBoolean )
            // InternalGameDsl.g:6297:3: ruleEBoolean
            {
             before(grammarAccess.getBackgroundAccess().getBackgroundMovingEBooleanParserRuleCall_14_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEBoolean();

            state._fsp--;

             after(grammarAccess.getBackgroundAccess().getBackgroundMovingEBooleanParserRuleCall_14_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Background__BackgroundMovingAssignment_14_1"


    // $ANTLR start "rule__ObjectType__NameAssignment_2"
    // InternalGameDsl.g:6306:1: rule__ObjectType__NameAssignment_2 : ( ruleEString ) ;
    public final void rule__ObjectType__NameAssignment_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6310:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6311:2: ( ruleEString )
            {
            // InternalGameDsl.g:6311:2: ( ruleEString )
            // InternalGameDsl.g:6312:3: ruleEString
            {
             before(grammarAccess.getObjectTypeAccess().getNameEStringParserRuleCall_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getObjectTypeAccess().getNameEStringParserRuleCall_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__NameAssignment_2"


    // $ANTLR start "rule__ObjectType__InteractionAssignment_4_1"
    // InternalGameDsl.g:6321:1: rule__ObjectType__InteractionAssignment_4_1 : ( ruleEString ) ;
    public final void rule__ObjectType__InteractionAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6325:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6326:2: ( ruleEString )
            {
            // InternalGameDsl.g:6326:2: ( ruleEString )
            // InternalGameDsl.g:6327:3: ruleEString
            {
             before(grammarAccess.getObjectTypeAccess().getInteractionEStringParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getObjectTypeAccess().getInteractionEStringParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__InteractionAssignment_4_1"


    // $ANTLR start "rule__ObjectType__CharacteristicAssignment_5_2"
    // InternalGameDsl.g:6336:1: rule__ObjectType__CharacteristicAssignment_5_2 : ( ruleAnySimpleType ) ;
    public final void rule__ObjectType__CharacteristicAssignment_5_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6340:1: ( ( ruleAnySimpleType ) )
            // InternalGameDsl.g:6341:2: ( ruleAnySimpleType )
            {
            // InternalGameDsl.g:6341:2: ( ruleAnySimpleType )
            // InternalGameDsl.g:6342:3: ruleAnySimpleType
            {
             before(grammarAccess.getObjectTypeAccess().getCharacteristicAnySimpleTypeParserRuleCall_5_2_0()); 
            pushFollow(FOLLOW_2);
            ruleAnySimpleType();

            state._fsp--;

             after(grammarAccess.getObjectTypeAccess().getCharacteristicAnySimpleTypeParserRuleCall_5_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__CharacteristicAssignment_5_2"


    // $ANTLR start "rule__ObjectType__CharacteristicAssignment_5_3_1"
    // InternalGameDsl.g:6351:1: rule__ObjectType__CharacteristicAssignment_5_3_1 : ( ruleAnySimpleType ) ;
    public final void rule__ObjectType__CharacteristicAssignment_5_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6355:1: ( ( ruleAnySimpleType ) )
            // InternalGameDsl.g:6356:2: ( ruleAnySimpleType )
            {
            // InternalGameDsl.g:6356:2: ( ruleAnySimpleType )
            // InternalGameDsl.g:6357:3: ruleAnySimpleType
            {
             before(grammarAccess.getObjectTypeAccess().getCharacteristicAnySimpleTypeParserRuleCall_5_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleAnySimpleType();

            state._fsp--;

             after(grammarAccess.getObjectTypeAccess().getCharacteristicAnySimpleTypeParserRuleCall_5_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__CharacteristicAssignment_5_3_1"


    // $ANTLR start "rule__ObjectType__GameobjectAssignment_6_2"
    // InternalGameDsl.g:6366:1: rule__ObjectType__GameobjectAssignment_6_2 : ( ruleGameObject ) ;
    public final void rule__ObjectType__GameobjectAssignment_6_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6370:1: ( ( ruleGameObject ) )
            // InternalGameDsl.g:6371:2: ( ruleGameObject )
            {
            // InternalGameDsl.g:6371:2: ( ruleGameObject )
            // InternalGameDsl.g:6372:3: ruleGameObject
            {
             before(grammarAccess.getObjectTypeAccess().getGameobjectGameObjectParserRuleCall_6_2_0()); 
            pushFollow(FOLLOW_2);
            ruleGameObject();

            state._fsp--;

             after(grammarAccess.getObjectTypeAccess().getGameobjectGameObjectParserRuleCall_6_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__GameobjectAssignment_6_2"


    // $ANTLR start "rule__ObjectType__GameobjectAssignment_6_3_1"
    // InternalGameDsl.g:6381:1: rule__ObjectType__GameobjectAssignment_6_3_1 : ( ruleGameObject ) ;
    public final void rule__ObjectType__GameobjectAssignment_6_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6385:1: ( ( ruleGameObject ) )
            // InternalGameDsl.g:6386:2: ( ruleGameObject )
            {
            // InternalGameDsl.g:6386:2: ( ruleGameObject )
            // InternalGameDsl.g:6387:3: ruleGameObject
            {
             before(grammarAccess.getObjectTypeAccess().getGameobjectGameObjectParserRuleCall_6_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleGameObject();

            state._fsp--;

             after(grammarAccess.getObjectTypeAccess().getGameobjectGameObjectParserRuleCall_6_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__ObjectType__GameobjectAssignment_6_3_1"


    // $ANTLR start "rule__GameObject__IdentifierAssignment_1"
    // InternalGameDsl.g:6396:1: rule__GameObject__IdentifierAssignment_1 : ( ruleEString ) ;
    public final void rule__GameObject__IdentifierAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6400:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6401:2: ( ruleEString )
            {
            // InternalGameDsl.g:6401:2: ( ruleEString )
            // InternalGameDsl.g:6402:3: ruleEString
            {
             before(grammarAccess.getGameObjectAccess().getIdentifierEStringParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getIdentifierEStringParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__IdentifierAssignment_1"


    // $ANTLR start "rule__GameObject__CoordinatesAssignment_5"
    // InternalGameDsl.g:6411:1: rule__GameObject__CoordinatesAssignment_5 : ( ruleEInt ) ;
    public final void rule__GameObject__CoordinatesAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6415:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6416:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6416:2: ( ruleEInt )
            // InternalGameDsl.g:6417:3: ruleEInt
            {
             before(grammarAccess.getGameObjectAccess().getCoordinatesEIntParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getCoordinatesEIntParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__CoordinatesAssignment_5"


    // $ANTLR start "rule__GameObject__CoordinatesAssignment_6_1"
    // InternalGameDsl.g:6426:1: rule__GameObject__CoordinatesAssignment_6_1 : ( ruleEInt ) ;
    public final void rule__GameObject__CoordinatesAssignment_6_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6430:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6431:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6431:2: ( ruleEInt )
            // InternalGameDsl.g:6432:3: ruleEInt
            {
             before(grammarAccess.getGameObjectAccess().getCoordinatesEIntParserRuleCall_6_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getCoordinatesEIntParserRuleCall_6_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__CoordinatesAssignment_6_1"


    // $ANTLR start "rule__GameObject__SizeAssignment_10"
    // InternalGameDsl.g:6441:1: rule__GameObject__SizeAssignment_10 : ( ruleEInt ) ;
    public final void rule__GameObject__SizeAssignment_10() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6445:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6446:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6446:2: ( ruleEInt )
            // InternalGameDsl.g:6447:3: ruleEInt
            {
             before(grammarAccess.getGameObjectAccess().getSizeEIntParserRuleCall_10_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getSizeEIntParserRuleCall_10_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__SizeAssignment_10"


    // $ANTLR start "rule__GameObject__SizeAssignment_11_1"
    // InternalGameDsl.g:6456:1: rule__GameObject__SizeAssignment_11_1 : ( ruleEInt ) ;
    public final void rule__GameObject__SizeAssignment_11_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6460:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6461:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6461:2: ( ruleEInt )
            // InternalGameDsl.g:6462:3: ruleEInt
            {
             before(grammarAccess.getGameObjectAccess().getSizeEIntParserRuleCall_11_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getSizeEIntParserRuleCall_11_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__SizeAssignment_11_1"


    // $ANTLR start "rule__GameObject__SpriteAssignment_14"
    // InternalGameDsl.g:6471:1: rule__GameObject__SpriteAssignment_14 : ( ruleEString ) ;
    public final void rule__GameObject__SpriteAssignment_14() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6475:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6476:2: ( ruleEString )
            {
            // InternalGameDsl.g:6476:2: ( ruleEString )
            // InternalGameDsl.g:6477:3: ruleEString
            {
             before(grammarAccess.getGameObjectAccess().getSpriteEStringParserRuleCall_14_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getSpriteEStringParserRuleCall_14_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__SpriteAssignment_14"


    // $ANTLR start "rule__GameObject__IsTakingDamageAssignment_15_1"
    // InternalGameDsl.g:6486:1: rule__GameObject__IsTakingDamageAssignment_15_1 : ( ruleEBoolean ) ;
    public final void rule__GameObject__IsTakingDamageAssignment_15_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6490:1: ( ( ruleEBoolean ) )
            // InternalGameDsl.g:6491:2: ( ruleEBoolean )
            {
            // InternalGameDsl.g:6491:2: ( ruleEBoolean )
            // InternalGameDsl.g:6492:3: ruleEBoolean
            {
             before(grammarAccess.getGameObjectAccess().getIsTakingDamageEBooleanParserRuleCall_15_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEBoolean();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getIsTakingDamageEBooleanParserRuleCall_15_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__IsTakingDamageAssignment_15_1"


    // $ANTLR start "rule__GameObject__AmountOfDamageAssignment_16_1"
    // InternalGameDsl.g:6501:1: rule__GameObject__AmountOfDamageAssignment_16_1 : ( ruleEFloat ) ;
    public final void rule__GameObject__AmountOfDamageAssignment_16_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6505:1: ( ( ruleEFloat ) )
            // InternalGameDsl.g:6506:2: ( ruleEFloat )
            {
            // InternalGameDsl.g:6506:2: ( ruleEFloat )
            // InternalGameDsl.g:6507:3: ruleEFloat
            {
             before(grammarAccess.getGameObjectAccess().getAmountOfDamageEFloatParserRuleCall_16_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEFloat();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getAmountOfDamageEFloatParserRuleCall_16_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__AmountOfDamageAssignment_16_1"


    // $ANTLR start "rule__GameObject__DamageDurationAssignment_17_1"
    // InternalGameDsl.g:6516:1: rule__GameObject__DamageDurationAssignment_17_1 : ( ruleEInt ) ;
    public final void rule__GameObject__DamageDurationAssignment_17_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6520:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6521:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6521:2: ( ruleEInt )
            // InternalGameDsl.g:6522:3: ruleEInt
            {
             before(grammarAccess.getGameObjectAccess().getDamageDurationEIntParserRuleCall_17_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getDamageDurationEIntParserRuleCall_17_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__DamageDurationAssignment_17_1"


    // $ANTLR start "rule__GameObject__VelocityAssignment_19"
    // InternalGameDsl.g:6531:1: rule__GameObject__VelocityAssignment_19 : ( ruleEFloat ) ;
    public final void rule__GameObject__VelocityAssignment_19() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6535:1: ( ( ruleEFloat ) )
            // InternalGameDsl.g:6536:2: ( ruleEFloat )
            {
            // InternalGameDsl.g:6536:2: ( ruleEFloat )
            // InternalGameDsl.g:6537:3: ruleEFloat
            {
             before(grammarAccess.getGameObjectAccess().getVelocityEFloatParserRuleCall_19_0()); 
            pushFollow(FOLLOW_2);
            ruleEFloat();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getVelocityEFloatParserRuleCall_19_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__VelocityAssignment_19"


    // $ANTLR start "rule__GameObject__DirectionDegreesAssignment_22"
    // InternalGameDsl.g:6546:1: rule__GameObject__DirectionDegreesAssignment_22 : ( ruleEDouble ) ;
    public final void rule__GameObject__DirectionDegreesAssignment_22() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6550:1: ( ( ruleEDouble ) )
            // InternalGameDsl.g:6551:2: ( ruleEDouble )
            {
            // InternalGameDsl.g:6551:2: ( ruleEDouble )
            // InternalGameDsl.g:6552:3: ruleEDouble
            {
             before(grammarAccess.getGameObjectAccess().getDirectionDegreesEDoubleParserRuleCall_22_0()); 
            pushFollow(FOLLOW_2);
            ruleEDouble();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getDirectionDegreesEDoubleParserRuleCall_22_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__DirectionDegreesAssignment_22"


    // $ANTLR start "rule__GameObject__DirectionDegreesAssignment_23_1"
    // InternalGameDsl.g:6561:1: rule__GameObject__DirectionDegreesAssignment_23_1 : ( ruleEDouble ) ;
    public final void rule__GameObject__DirectionDegreesAssignment_23_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6565:1: ( ( ruleEDouble ) )
            // InternalGameDsl.g:6566:2: ( ruleEDouble )
            {
            // InternalGameDsl.g:6566:2: ( ruleEDouble )
            // InternalGameDsl.g:6567:3: ruleEDouble
            {
             before(grammarAccess.getGameObjectAccess().getDirectionDegreesEDoubleParserRuleCall_23_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEDouble();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getDirectionDegreesEDoubleParserRuleCall_23_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__DirectionDegreesAssignment_23_1"


    // $ANTLR start "rule__GameObject__DurabilityAssignment_25_1"
    // InternalGameDsl.g:6576:1: rule__GameObject__DurabilityAssignment_25_1 : ( ruleEInt ) ;
    public final void rule__GameObject__DurabilityAssignment_25_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6580:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6581:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6581:2: ( ruleEInt )
            // InternalGameDsl.g:6582:3: ruleEInt
            {
             before(grammarAccess.getGameObjectAccess().getDurabilityEIntParserRuleCall_25_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getDurabilityEIntParserRuleCall_25_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__DurabilityAssignment_25_1"


    // $ANTLR start "rule__GameObject__AbilityAssignment_26_2"
    // InternalGameDsl.g:6591:1: rule__GameObject__AbilityAssignment_26_2 : ( ruleAbility ) ;
    public final void rule__GameObject__AbilityAssignment_26_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6595:1: ( ( ruleAbility ) )
            // InternalGameDsl.g:6596:2: ( ruleAbility )
            {
            // InternalGameDsl.g:6596:2: ( ruleAbility )
            // InternalGameDsl.g:6597:3: ruleAbility
            {
             before(grammarAccess.getGameObjectAccess().getAbilityAbilityParserRuleCall_26_2_0()); 
            pushFollow(FOLLOW_2);
            ruleAbility();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getAbilityAbilityParserRuleCall_26_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__AbilityAssignment_26_2"


    // $ANTLR start "rule__GameObject__AbilityAssignment_26_3_1"
    // InternalGameDsl.g:6606:1: rule__GameObject__AbilityAssignment_26_3_1 : ( ruleAbility ) ;
    public final void rule__GameObject__AbilityAssignment_26_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6610:1: ( ( ruleAbility ) )
            // InternalGameDsl.g:6611:2: ( ruleAbility )
            {
            // InternalGameDsl.g:6611:2: ( ruleAbility )
            // InternalGameDsl.g:6612:3: ruleAbility
            {
             before(grammarAccess.getGameObjectAccess().getAbilityAbilityParserRuleCall_26_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleAbility();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getAbilityAbilityParserRuleCall_26_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__AbilityAssignment_26_3_1"


    // $ANTLR start "rule__GameObject__ActionAssignment_27_2"
    // InternalGameDsl.g:6621:1: rule__GameObject__ActionAssignment_27_2 : ( ruleAction ) ;
    public final void rule__GameObject__ActionAssignment_27_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6625:1: ( ( ruleAction ) )
            // InternalGameDsl.g:6626:2: ( ruleAction )
            {
            // InternalGameDsl.g:6626:2: ( ruleAction )
            // InternalGameDsl.g:6627:3: ruleAction
            {
             before(grammarAccess.getGameObjectAccess().getActionActionParserRuleCall_27_2_0()); 
            pushFollow(FOLLOW_2);
            ruleAction();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getActionActionParserRuleCall_27_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__ActionAssignment_27_2"


    // $ANTLR start "rule__GameObject__ActionAssignment_27_3_1"
    // InternalGameDsl.g:6636:1: rule__GameObject__ActionAssignment_27_3_1 : ( ruleAction ) ;
    public final void rule__GameObject__ActionAssignment_27_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6640:1: ( ( ruleAction ) )
            // InternalGameDsl.g:6641:2: ( ruleAction )
            {
            // InternalGameDsl.g:6641:2: ( ruleAction )
            // InternalGameDsl.g:6642:3: ruleAction
            {
             before(grammarAccess.getGameObjectAccess().getActionActionParserRuleCall_27_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleAction();

            state._fsp--;

             after(grammarAccess.getGameObjectAccess().getActionActionParserRuleCall_27_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__GameObject__ActionAssignment_27_3_1"


    // $ANTLR start "rule__Collisions__HittedSpotAssignment_3_1"
    // InternalGameDsl.g:6651:1: rule__Collisions__HittedSpotAssignment_3_1 : ( ruleEString ) ;
    public final void rule__Collisions__HittedSpotAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6655:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6656:2: ( ruleEString )
            {
            // InternalGameDsl.g:6656:2: ( ruleEString )
            // InternalGameDsl.g:6657:3: ruleEString
            {
             before(grammarAccess.getCollisionsAccess().getHittedSpotEStringParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getCollisionsAccess().getHittedSpotEStringParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__HittedSpotAssignment_3_1"


    // $ANTLR start "rule__Collisions__EffectAssignment_4_1"
    // InternalGameDsl.g:6666:1: rule__Collisions__EffectAssignment_4_1 : ( ruleEString ) ;
    public final void rule__Collisions__EffectAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6670:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6671:2: ( ruleEString )
            {
            // InternalGameDsl.g:6671:2: ( ruleEString )
            // InternalGameDsl.g:6672:3: ruleEString
            {
             before(grammarAccess.getCollisionsAccess().getEffectEStringParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getCollisionsAccess().getEffectEStringParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__EffectAssignment_4_1"


    // $ANTLR start "rule__Collisions__EffectValueAssignment_5_1"
    // InternalGameDsl.g:6681:1: rule__Collisions__EffectValueAssignment_5_1 : ( ruleEFloat ) ;
    public final void rule__Collisions__EffectValueAssignment_5_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6685:1: ( ( ruleEFloat ) )
            // InternalGameDsl.g:6686:2: ( ruleEFloat )
            {
            // InternalGameDsl.g:6686:2: ( ruleEFloat )
            // InternalGameDsl.g:6687:3: ruleEFloat
            {
             before(grammarAccess.getCollisionsAccess().getEffectValueEFloatParserRuleCall_5_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEFloat();

            state._fsp--;

             after(grammarAccess.getCollisionsAccess().getEffectValueEFloatParserRuleCall_5_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__EffectValueAssignment_5_1"


    // $ANTLR start "rule__Collisions__ObjIDAssignment_6_2"
    // InternalGameDsl.g:6696:1: rule__Collisions__ObjIDAssignment_6_2 : ( ruleEString ) ;
    public final void rule__Collisions__ObjIDAssignment_6_2() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6700:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6701:2: ( ruleEString )
            {
            // InternalGameDsl.g:6701:2: ( ruleEString )
            // InternalGameDsl.g:6702:3: ruleEString
            {
             before(grammarAccess.getCollisionsAccess().getObjIDEStringParserRuleCall_6_2_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getCollisionsAccess().getObjIDEStringParserRuleCall_6_2_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__ObjIDAssignment_6_2"


    // $ANTLR start "rule__Collisions__ObjIDAssignment_6_3_1"
    // InternalGameDsl.g:6711:1: rule__Collisions__ObjIDAssignment_6_3_1 : ( ruleEString ) ;
    public final void rule__Collisions__ObjIDAssignment_6_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6715:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6716:2: ( ruleEString )
            {
            // InternalGameDsl.g:6716:2: ( ruleEString )
            // InternalGameDsl.g:6717:3: ruleEString
            {
             before(grammarAccess.getCollisionsAccess().getObjIDEStringParserRuleCall_6_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getCollisionsAccess().getObjIDEStringParserRuleCall_6_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Collisions__ObjIDAssignment_6_3_1"


    // $ANTLR start "rule__Ability__NameAssignment_1"
    // InternalGameDsl.g:6726:1: rule__Ability__NameAssignment_1 : ( ruleEString ) ;
    public final void rule__Ability__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6730:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6731:2: ( ruleEString )
            {
            // InternalGameDsl.g:6731:2: ( ruleEString )
            // InternalGameDsl.g:6732:3: ruleEString
            {
             before(grammarAccess.getAbilityAccess().getNameEStringParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getAbilityAccess().getNameEStringParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__NameAssignment_1"


    // $ANTLR start "rule__Ability__DurationAssignment_3_1"
    // InternalGameDsl.g:6741:1: rule__Ability__DurationAssignment_3_1 : ( ruleEInt ) ;
    public final void rule__Ability__DurationAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6745:1: ( ( ruleEInt ) )
            // InternalGameDsl.g:6746:2: ( ruleEInt )
            {
            // InternalGameDsl.g:6746:2: ( ruleEInt )
            // InternalGameDsl.g:6747:3: ruleEInt
            {
             before(grammarAccess.getAbilityAccess().getDurationEIntParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEInt();

            state._fsp--;

             after(grammarAccess.getAbilityAccess().getDurationEIntParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__DurationAssignment_3_1"


    // $ANTLR start "rule__Ability__IsBeingUsedAssignment_5"
    // InternalGameDsl.g:6756:1: rule__Ability__IsBeingUsedAssignment_5 : ( ruleEBoolean ) ;
    public final void rule__Ability__IsBeingUsedAssignment_5() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6760:1: ( ( ruleEBoolean ) )
            // InternalGameDsl.g:6761:2: ( ruleEBoolean )
            {
            // InternalGameDsl.g:6761:2: ( ruleEBoolean )
            // InternalGameDsl.g:6762:3: ruleEBoolean
            {
             before(grammarAccess.getAbilityAccess().getIsBeingUsedEBooleanParserRuleCall_5_0()); 
            pushFollow(FOLLOW_2);
            ruleEBoolean();

            state._fsp--;

             after(grammarAccess.getAbilityAccess().getIsBeingUsedEBooleanParserRuleCall_5_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__IsBeingUsedAssignment_5"


    // $ANTLR start "rule__Ability__EffectAssignment_8"
    // InternalGameDsl.g:6771:1: rule__Ability__EffectAssignment_8 : ( ruleEffect ) ;
    public final void rule__Ability__EffectAssignment_8() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6775:1: ( ( ruleEffect ) )
            // InternalGameDsl.g:6776:2: ( ruleEffect )
            {
            // InternalGameDsl.g:6776:2: ( ruleEffect )
            // InternalGameDsl.g:6777:3: ruleEffect
            {
             before(grammarAccess.getAbilityAccess().getEffectEffectParserRuleCall_8_0()); 
            pushFollow(FOLLOW_2);
            ruleEffect();

            state._fsp--;

             after(grammarAccess.getAbilityAccess().getEffectEffectParserRuleCall_8_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__EffectAssignment_8"


    // $ANTLR start "rule__Ability__EffectAssignment_9_1"
    // InternalGameDsl.g:6786:1: rule__Ability__EffectAssignment_9_1 : ( ruleEffect ) ;
    public final void rule__Ability__EffectAssignment_9_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6790:1: ( ( ruleEffect ) )
            // InternalGameDsl.g:6791:2: ( ruleEffect )
            {
            // InternalGameDsl.g:6791:2: ( ruleEffect )
            // InternalGameDsl.g:6792:3: ruleEffect
            {
             before(grammarAccess.getAbilityAccess().getEffectEffectParserRuleCall_9_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEffect();

            state._fsp--;

             after(grammarAccess.getAbilityAccess().getEffectEffectParserRuleCall_9_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Ability__EffectAssignment_9_1"


    // $ANTLR start "rule__Action__NameAssignment_1"
    // InternalGameDsl.g:6801:1: rule__Action__NameAssignment_1 : ( ruleEString ) ;
    public final void rule__Action__NameAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6805:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6806:2: ( ruleEString )
            {
            // InternalGameDsl.g:6806:2: ( ruleEString )
            // InternalGameDsl.g:6807:3: ruleEString
            {
             before(grammarAccess.getActionAccess().getNameEStringParserRuleCall_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getActionAccess().getNameEStringParserRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__NameAssignment_1"


    // $ANTLR start "rule__Action__EffectAssignment_4"
    // InternalGameDsl.g:6816:1: rule__Action__EffectAssignment_4 : ( ruleEString ) ;
    public final void rule__Action__EffectAssignment_4() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6820:1: ( ( ruleEString ) )
            // InternalGameDsl.g:6821:2: ( ruleEString )
            {
            // InternalGameDsl.g:6821:2: ( ruleEString )
            // InternalGameDsl.g:6822:3: ruleEString
            {
             before(grammarAccess.getActionAccess().getEffectEStringParserRuleCall_4_0()); 
            pushFollow(FOLLOW_2);
            ruleEString();

            state._fsp--;

             after(grammarAccess.getActionAccess().getEffectEStringParserRuleCall_4_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Action__EffectAssignment_4"


    // $ANTLR start "rule__Effect__IdentifierAssignment_1"
    // InternalGameDsl.g:6831:1: rule__Effect__IdentifierAssignment_1 : ( RULE_ID ) ;
    public final void rule__Effect__IdentifierAssignment_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6835:1: ( ( RULE_ID ) )
            // InternalGameDsl.g:6836:2: ( RULE_ID )
            {
            // InternalGameDsl.g:6836:2: ( RULE_ID )
            // InternalGameDsl.g:6837:3: RULE_ID
            {
             before(grammarAccess.getEffectAccess().getIdentifierIDTerminalRuleCall_1_0()); 
            match(input,RULE_ID,FOLLOW_2); 
             after(grammarAccess.getEffectAccess().getIdentifierIDTerminalRuleCall_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__IdentifierAssignment_1"


    // $ANTLR start "rule__Effect__VelocityAssignment_3_1"
    // InternalGameDsl.g:6846:1: rule__Effect__VelocityAssignment_3_1 : ( ruleEFloat ) ;
    public final void rule__Effect__VelocityAssignment_3_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6850:1: ( ( ruleEFloat ) )
            // InternalGameDsl.g:6851:2: ( ruleEFloat )
            {
            // InternalGameDsl.g:6851:2: ( ruleEFloat )
            // InternalGameDsl.g:6852:3: ruleEFloat
            {
             before(grammarAccess.getEffectAccess().getVelocityEFloatParserRuleCall_3_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEFloat();

            state._fsp--;

             after(grammarAccess.getEffectAccess().getVelocityEFloatParserRuleCall_3_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__VelocityAssignment_3_1"


    // $ANTLR start "rule__Effect__RangeAssignment_4_1"
    // InternalGameDsl.g:6861:1: rule__Effect__RangeAssignment_4_1 : ( ruleEFloat ) ;
    public final void rule__Effect__RangeAssignment_4_1() throws RecognitionException {

        		int stackSize = keepStackSize();
        	
        try {
            // InternalGameDsl.g:6865:1: ( ( ruleEFloat ) )
            // InternalGameDsl.g:6866:2: ( ruleEFloat )
            {
            // InternalGameDsl.g:6866:2: ( ruleEFloat )
            // InternalGameDsl.g:6867:3: ruleEFloat
            {
             before(grammarAccess.getEffectAccess().getRangeEFloatParserRuleCall_4_1_0()); 
            pushFollow(FOLLOW_2);
            ruleEFloat();

            state._fsp--;

             after(grammarAccess.getEffectAccess().getRangeEFloatParserRuleCall_4_1_0()); 

            }


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {

            	restoreStackSize(stackSize);

        }
        return ;
    }
    // $ANTLR end "rule__Effect__RangeAssignment_4_1"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000030L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000360000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x00000000000A0000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000080000000000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0080000000000040L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000002080000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000018020000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000000001800L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x00000001C0020000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0180000000001850L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x000000E800000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0180000000000040L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000070000020000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000F00000020000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x000A000000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0004000000000000L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000200000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x0040000800020000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0000000000000040L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000006000L});

}